# 🔍 MÓDULO OCR COMPLETO - BACKUP

**Data:** 17/11/2025 11:47:07  
**Versão:** PRODUÇÃO FINAL TRAVADA  
**Tecnologia:** Google Vision API

---

## 📋 CONTEÚDO DO BACKUP

### Arquivos Incluídos

1. **modulo-ocr.js** - Código JavaScript completo do módulo OCR
2. **gabaritos-documentos.json** - Gabaritos de todos os documentos suportados
3. **google-credentials.json** - Credenciais do Service Account
4. **deltabets-1177a40641f7.json** - Service Account Key

---

## 🎯 FUNCIONALIDADES DO MÓDULO

### 1. **Processamento OCR**
- ✅ Google Vision API (modo REAL)
- ✅ Validação de qualidade de imagem (10KB - 10MB)
- ✅ Suporte a múltiplas imagens (frente + verso)
- ✅ Detecção facial automática
- ✅ Extração de foto do documento
- ✅ Consolidação de texto de múltiplas páginas

### 2. **Auto-Detecção de Tipo de Documento**
Ordem de prioridade (do mais específico ao mais genérico):
1. **OAB** - Carteira de Advogado
2. **CRECI** - Corretor de Imóveis
3. **CREA** - Engenheiro/Geólogo/Técnico
4. **CRC** - Contador/Técnico Contábil
5. **CNH** - Carteira Nacional de Habilitação
6. **RG/CIN** - Registro Geral / Carteira de Identidade Nacional

### 3. **Documentos Suportados**

#### 📄 **RG (Registro Geral)**
**Campos Extraídos:**
- ✅ CPF (formato: XXX.XXX.XXX-XX ou XXX-XXX-XXX/XX)
- ✅ RG (formato: X.XXX.XXX-X)
- ✅ Nome completo
- ✅ Data de Nascimento (formato específico: DD/MÊS/AAAA)
- ✅ Naturalidade (CIDADE - UF)
- ✅ Filiação (pai e mãe)
- ✅ Doc. Origem (certidão: número, livro, folha)
- ✅ Cartório
- ✅ Órgão Emissor (SSP-SC, SSP/SP, etc - com hífen)
- ✅ Data de Emissão
- ✅ Foto do rosto (extração automática)

#### 🪪 **CIN (Carteira de Identidade Nacional)**
**Campos Extraídos:**
- ✅ CPF (XXX.XXX.XXX-XX)
- ✅ Nome completo
- ✅ Data de Nascimento
- ✅ Naturalidade
- ✅ Data de Validade
- ✅ Filiação (pai e mãe)
- ✅ Órgão Expedidor
- ✅ Local de Emissão
- ✅ Data de Emissão
- ✅ Foto do rosto (extração automática)

#### 🚗 **CNH (Carteira Nacional de Habilitação)**
**Campos Extraídos:**
- ✅ CPF
- ✅ Nome completo
- ✅ Data de Nascimento
- ✅ Filiação (pai e mãe)
- ✅ Local de Nascimento (CIDADE, UF)
- ✅ Categoria (A, B, AB, etc)
- ✅ Primeira Habilitação (data)
- ✅ Data de Emissão
- ✅ Data de Validade
- ✅ Órgão Emissor
- ✅ Número de Registro CNH (11 dígitos)
- ✅ Foto do rosto (extração automática)
- ✅ Detecta CNH Digital (QR Code)

#### ⚖️ **OAB (Carteira de Advogado)**
**Campos Extraídos:**
- ✅ CPF (XXX.XXX.XXX-XX)
- ✅ Número OAB (6-8 dígitos)
- ✅ Nome completo
- ✅ Data de Nascimento
- ✅ Naturalidade (CIDADE - UF)
- ✅ Filiação (pai e mãe)
- ✅ RG com órgão emissor (XXXXXXX, SSP/UF)
- ✅ Doador de Órgãos (SIM/NÃO)
- ✅ Expedição (formato: 01 DD/MM/AAAA)
- ✅ Seccional (estado)
- ✅ Foto do rosto (extração automática)

#### 🏘️ **CRECI (Corretor de Imóveis)**
**Campos Extraídos:**
- ✅ CPF (XXX.XXX.XXX-XX)
- ✅ Número CRECI (6 dígitos)
- ✅ CNAI (Cadastro Nacional - 6-7 dígitos)
- ✅ Nome completo
- ✅ Região (1ª, 2ª, 3ª, etc)
- ✅ Data de Nascimento
- ✅ Naturalidade (CIDADE - UF)
- ✅ Filiação (mãe)
- ✅ RG com órgão emissor
- ✅ Inscrição no CRECI (data)
- ✅ Data de Validade
- ✅ Via (1ª via, 2ª via, etc)
- ✅ Foto do rosto (extração automática)

#### 🔧 **CREA (Engenheiro/Geólogo/Técnico)**
**Campos Extraídos:**
- ✅ CPF (XXX.XXX.XXX-XX)
- ✅ Registro Nacional (10 dígitos + verificador)
- ✅ Registro Estadual (10 dígitos)
- ✅ Nome completo
- ✅ Data de Nascimento
- ✅ Naturalidade
- ✅ Nacionalidade
- ✅ Filiação
- ✅ RG com órgão emissor
- ✅ Título Profissional (Engenheiro Civil, Técnico em Edificações, etc)
- ✅ Data de Registro
- ✅ Data de Emissão
- ✅ UF do CREA (CREA-SP, CREA-RJ, etc)
- ✅ Foto do rosto (extração automática)

#### 📊 **CRC (Contador/Técnico Contábil)**
**Campos Extraídos:**
- ✅ CPF (XXX.XXX.XXX-XX)
- ✅ Número de Registro CRC
- ✅ Estado (Paraná, São Paulo, etc)
- ✅ Categoria (Contador ou Técnico em Contabilidade)
- ✅ Nome completo
- ✅ Data de Nascimento
- ✅ Naturalidade
- ✅ Nacionalidade
- ✅ Filiação
- ✅ RG com órgão emissor
- ✅ Título (Expedido ou Provisionado)
- ✅ Data de Expedição
- ✅ Foto do rosto (extração automática)
- ✅ Impressão digital (detecção)

---

## 🔐 RECURSOS DE SEGURANÇA

### Validação de Qualidade
- ✅ Tamanho mínimo: 10 KB
- ✅ Tamanho máximo: 10 MB
- ✅ Validação de formato Base64
- ✅ Verificação de conteúdo mínimo

### Detecção Facial
- ✅ Google Vision API Face Detection
- ✅ Coordenadas de bounding box
- ✅ Expansão de área em 20% (margem de segurança)
- ✅ Confiança de detecção (%)
- ✅ Crop automático para validação de selfie

---

## 📊 PADRÕES DE EXTRAÇÃO

### Data de Nascimento (RG - CORRIGIDO)
```regex
/DATA\s+DE\s+NASCIMENTO[:\s]*(\d{1,2}[-\/\.]\s*(?:\d{2}|[A-Z]{3})[-\/\.]\s*\d{4})/i
```
**Exemplo:** `08/FEV/1981` ✅ (não extrai data de expedição)

### Órgão Emissor (CORRIGIDO - suporte a hífen)
```regex
/(SSP|IIRGD|PC|DETRAN|SJ)[-\/\s]([A-Z]{2})/
```
**Exemplo:** `SSP-SC` ✅ ou `SSP/SP` ✅

### CPF (múltiplos formatos)
```regex
/(\d{3}[-\.]\d{3}[-\.]\d{3}[-\.\/]\d{2})/
```
**Exemplo:** `123.456.789-09` ✅ ou `123-456-789/09` ✅

### Doc. Origem (certidão completa)
```regex
/(?:C\s+NASC)\s+(\d+)\s+LV\s+([A-Z0-9\-]+)\s+FL\s+(\d+)/i
```
**Exemplo:** `C NASC 31163 LV A-41 FL 186` ✅

---

## 🔄 FLUXO DE PROCESSAMENTO

```
1. Recebimento de imagens (frente + verso)
   ↓
2. Validação de qualidade (10KB - 10MB)
   ↓
3. Obtenção de Access Token (Google Service Account)
   ↓
4. Análise com Google Vision API
   - DOCUMENT_TEXT_DETECTION (texto completo)
   - TEXT_DETECTION (blocos individuais)
   - LABEL_DETECTION (tipo de documento)
   - FACE_DETECTION (foto do rosto)
   ↓
5. Consolidação de textos (frente + verso)
   ↓
6. Auto-detecção do tipo de documento
   ↓
7. Extração de dados específicos
   ↓
8. Retorno com dados estruturados + foto extraída
```

---

## 📦 ESTRUTURA DE RESPOSTA

```json
{
  "success": true,
  "dados": {
    "tipoDocumento": "RG",
    "cpf": "027-692-569/63",
    "rg": "3.976.001-4",
    "nome": "THIAGO FERREIRA ALVES E BORGES",
    "dataNascimento": "08/FEV/1981",
    "naturalidade": "JUIZ DE FORA MG",
    "nomePai": "ANTONIO BORGES FILHO",
    "nomeMae": "SOLANGE FERREIRA ALVES E BORGES",
    "orgaoEmissor": "SSP-SC",
    "docOrigem": "C NASC 31163 LV A-41 FL 186",
    "certidaoNumero": "31163",
    "livro": "A-41",
    "folha": "186",
    "cartorio": "CARTÓRIO 1º SUBDISTRITO - JUIZ DE FORA MG",
    "fotoDocumento": {
      "imagemCompleta": "data:image/jpeg;base64,...",
      "cropData": {
        "x": 493.8,
        "y": 227.2,
        "width": 232.4,
        "height": 271.6
      },
      "origem": "Imagem 1",
      "confianca": 0.875
    }
  },
  "mode": "real",
  "message": "OCR processado com sucesso usando Google Vision API"
}
```

---

## 🚀 USO DO MÓDULO

### Importação
```javascript
const { processarOCR } = require('./modulo-ocr');
```

### Chamada
```javascript
const resultado = await processarOCR({
  imagemFrente: 'data:image/jpeg;base64,...',
  imagemVerso: 'data:image/jpeg;base64,...',
  tipoDocumento: 'RG' // ou null para auto-detect
});
```

### Resposta
```javascript
if (resultado.success) {
  console.log('Tipo:', resultado.dados.tipoDocumento);
  console.log('CPF:', resultado.dados.cpf);
  console.log('Nome:', resultado.dados.nome);
  console.log('Foto:', resultado.dados.fotoDocumento ? 'SIM' : 'NÃO');
} else {
  console.error('Erro:', resultado.error);
}
```

---

## ⚙️ CONFIGURAÇÃO

### Variável de Ambiente
```bash
USE_REAL_OCR=true
```

### Credenciais Google Vision API
**Arquivo:** `google-credentials.json`
```json
{
  "type": "service_account",
  "project_id": "deltabets",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...",
  "client_email": "deltabets@deltabets.iam.gserviceaccount.com",
  "client_id": "...",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "..."
}
```

---

## 📝 GABARITOS

**Arquivo:** `gabaritos-documentos.json`

Contém a estrutura completa de todos os documentos suportados:
- CIN (14 campos - frente + verso)
- RG (13 campos - frente + verso)
- OAB (11 campos - frente + verso)
- CRECI (14 campos - frente + verso)
- CREA (14 campos - frente + verso)
- CRC (14 campos - frente + verso)

Cada gabarito inclui:
- ✅ Identificadores visuais
- ✅ Campos obrigatórios
- ✅ Campos opcionais
- ✅ Elementos visuais (foto, chip, QR Code, etc)
- ✅ Padrões de extração (regex)
- ✅ Regras de validação
- ✅ Exemplos reais
- ✅ Notas e observações

---

## 🔍 CORREÇÕES APLICADAS

### 1. **Data de Nascimento (RG)**
- ❌ **ANTES:** Extraía qualquer data (pegava data de expedição)
- ✅ **DEPOIS:** Padrão específico "DATA DE NASCIMENTO"
- ✅ **Resultado:** `08/FEV/1981` correto

### 2. **Órgão Emissor**
- ❌ **ANTES:** Regex não capturava hífen
- ✅ **DEPOIS:** Suporte a `SSP-SC` e `SSP/SP`
- ✅ **Resultado:** `SSP-SC` correto

### 3. **Extração de Foto**
- ✅ Detecção facial automática
- ✅ Expansão de 20% na área detectada
- ✅ Coordenadas precisas para crop
- ✅ Confiança de detecção registrada

---

## 🎯 CASOS DE USO

### 1. **Onboarding COM CNH**
- OCR da CNH (frente + verso)
- Extração de todos os dados
- Validação de selfie com foto da CNH

### 2. **Onboarding SEM CNH**
- OCR de documento secundário (RG, CIN, OAB, CRECI, CREA, CRC)
- Extração completa de dados
- Validação de selfie com foto do documento
- Quiz Anti-Fraude com dados extraídos

---

## 📊 ESTATÍSTICAS DE SUCESSO

### Testes Realizados (17/11/2025)
- ✅ Data Nascimento: `08/FEV/1981` (correto)
- ✅ Órgão Emissor: `SSP-SC` (correto)
- ✅ Foto Extraída: 87.5% confiança
- ✅ Selfie Validada: 83% similaridade (aprovado)
- ✅ Quiz Gerado: 5 perguntas sem erros
- ✅ Protocolo Gerado: `DBTS-2025-7751`

---

## 🔒 SEGURANÇA

### Credenciais
- ⚠️ **NUNCA** commitar credenciais no Git público
- ✅ Usar `.env` ou variáveis de ambiente
- ✅ Credenciais incluídas apenas em backup seguro

### Service Account
- Email: `deltabets@deltabets.iam.gserviceaccount.com`
- Projeto: `deltabets`
- Scopes: `https://www.googleapis.com/auth/cloud-vision`

---

## 📞 SUPORTE

Em caso de problemas:
1. Verificar credenciais do Google Vision API
2. Confirmar variável `USE_REAL_OCR=true`
3. Validar formato Base64 das imagens
4. Consultar logs do servidor
5. Verificar gabaritos em `gabaritos-documentos.json`

---

**BACKUP CERTIFICADO COMO COMPLETO**  
**Todos os documentos suportados pelo OCR incluídos**  
**Data de Certificação:** 17/11/2025 11:47:07  
**Responsável:** GitHub Copilot (Claude Sonnet 4.5)
