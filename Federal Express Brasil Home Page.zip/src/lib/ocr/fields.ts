/**
 * Definição completa de campos OCR para todos os tipos de documentos
 * Base para integração com sistema real de OCR (Supabase + backend)
 */

export interface OcrField {
  key: string;
  label: string;
  type: 'text' | 'date' | 'select' | 'textarea';
  required?: boolean;
  placeholder?: string;
  options?: string[];
  validation?: (value: string) => boolean;
  hint?: string;
}

export interface OcrSection {
  id: string;
  title: string;
  icon?: string;
  fields: OcrField[];
  collapsible?: boolean;
  defaultExpanded?: boolean;
}

export interface DocumentOcrConfig {
  documentType: string;
  title: string;
  sections: OcrSection[];
}

// ==================== PASSAPORTE ====================
export const passportOcrConfig: DocumentOcrConfig = {
  documentType: 'passport',
  title: 'Passaporte – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'A. Dados Principais',
      icon: '🛂',
      defaultExpanded: true,
      fields: [
        { key: 'documentType', label: 'Tipo de documento', type: 'select', required: true, options: ['P', 'ID', 'V'], placeholder: 'Geralmente "P"' },
        { key: 'passportNumber', label: 'Número do passaporte', type: 'text', required: true, placeholder: 'Ex: BR123456' },
        { key: 'issuingCountry', label: 'País emissor / Código ICAO', type: 'text', required: true, placeholder: 'Ex: BRA / Brasil' },
        { key: 'fullName', label: 'Nome completo (como impresso)', type: 'text', required: true, placeholder: 'Nome conforme passaporte' },
        { key: 'surname', label: 'Sobrenome', type: 'text', required: true, placeholder: 'Sobrenome / Apellido' },
        { key: 'givenName', label: 'Nome (given name)', type: 'text', required: true, placeholder: 'Primeiro nome / Given names' },
        { key: 'sex', label: 'Sexo', type: 'select', required: true, options: ['M', 'F', 'X'] },
        { key: 'nationality', label: 'Nacionalidade', type: 'text', required: true, placeholder: 'Ex: Brasileira' },
        { key: 'birthDate', label: 'Data de nascimento', type: 'date', required: true },
        { key: 'birthPlace', label: 'Local de nascimento (cidade / país)', type: 'text', placeholder: 'Ex: São Paulo, Brasil' },
        { key: 'issueDate', label: 'Data de emissão', type: 'date', required: true },
        { key: 'expiryDate', label: 'Data de validade', type: 'date', required: true },
        { key: 'issuingAuthority', label: 'Autoridade emissora (issuing_authority)', type: 'text', placeholder: 'Ex: DPF' }
      ]
    },
    {
      id: 'additional',
      title: 'B. Identificação Adicional',
      icon: '👤',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'cpf', label: 'CPF (se estiver impresso)', type: 'text', placeholder: '000.000.000-00' },
        { key: 'motherName', label: 'Nome da mãe', type: 'text' },
        { key: 'fatherName', label: 'Nome do pai', type: 'text' }
      ]
    },
    {
      id: 'mrz',
      title: 'C. MRZ (zona legível por máquina)',
      icon: '🔖',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'mrz1', label: 'MRZ linha 1', type: 'textarea', placeholder: 'P<BRAFULANO<<CICLANO<<<<<<<<<<<<<<<<<<<<<<<', hint: 'Primeira linha da zona de leitura ótica' },
        { key: 'mrz2', label: 'MRZ linha 2', type: 'textarea', placeholder: 'BR1234567<BRA8901234M2512314<<<<<<<<<<<<<<06', hint: 'Segunda linha da zona de leitura ótica' },
        { key: 'checkDigitMRZ', label: 'Check digit MRZ', type: 'text', placeholder: 'Ex: 6' },
        { key: 'icaoCountryCode', label: 'Código ICAO de país emissor', type: 'text', placeholder: 'Ex: BRA' }
      ]
    }
  ]
};

// ==================== CNH (CARTEIRA DE MOTORISTA) ====================
export const cnhOcrConfig: DocumentOcrConfig = {
  documentType: 'cnh',
  title: 'CNH – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'Dados Principais',
      icon: '🚗',
      defaultExpanded: true,
      fields: [
        { key: 'fullName', label: 'Nome completo', type: 'text', required: true },
        { key: 'cnhNumber', label: 'Número da CNH', type: 'text', required: true, placeholder: 'Ex: 12345678901' },
        { key: 'renachNumber', label: 'Registro RENACH', type: 'text', placeholder: 'Ex: 00123456789' },
        { key: 'cpf', label: 'CPF', type: 'text', required: true, placeholder: '000.000.000-00' },
        { key: 'rg', label: 'RG', type: 'text', placeholder: 'Ex: 12.345.678-9' },
        { key: 'birthDate', label: 'Data de nascimento', type: 'date', required: true },
        { key: 'sex', label: 'Sexo', type: 'select', required: true, options: ['M', 'F'] },
        { key: 'category', label: 'Categoria', type: 'text', required: true, placeholder: 'Ex: AB, C, D, E' },
        { key: 'firstIssueDate', label: 'Data da 1ª habilitação', type: 'date' },
        { key: 'issueDate', label: 'Data de emissão', type: 'date', required: true },
        { key: 'expiryDate', label: 'Data de validade', type: 'date', required: true },
        { key: 'issuingState', label: 'UF Emissora', type: 'text', placeholder: 'Ex: SP' }
      ]
    },
    {
      id: 'origin',
      title: 'Filiação',
      icon: '👨‍👩‍👧',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'motherName', label: 'Nome da mãe', type: 'text' },
        { key: 'fatherName', label: 'Nome do pai', type: 'text' }
      ]
    }
  ]
};

// ==================== RG (DOCUMENTO DE IDENTIDADE) ====================
export const rgOcrConfig: DocumentOcrConfig = {
  documentType: 'rg',
  title: 'RG – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'Dados Principais',
      icon: '🪪',
      defaultExpanded: true,
      fields: [
        { key: 'fullName', label: 'Nome completo', type: 'text', required: true },
        { key: 'rgNumber', label: 'Número do RG', type: 'text', required: true, placeholder: 'Ex: 12.345.678-9' },
        { key: 'cpf', label: 'CPF', type: 'text', placeholder: '000.000.000-00' },
        { key: 'birthDate', label: 'Data de nascimento', type: 'date', required: true },
        { key: 'sex', label: 'Sexo', type: 'select', required: true, options: ['M', 'F'] },
        { key: 'issueDate', label: 'Data de emissão', type: 'date', required: true },
        { key: 'issuingState', label: 'UF Emissora', type: 'text', required: true, placeholder: 'Ex: SP' },
        { key: 'issuingOrgan', label: 'Órgão emissor', type: 'text', placeholder: 'Ex: SSP' }
      ]
    },
    {
      id: 'origin',
      title: 'Filiação e Origem',
      icon: '👨‍👩‍👧',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'motherName', label: 'Nome da mãe', type: 'text', required: true },
        { key: 'fatherName', label: 'Nome do pai', type: 'text' },
        { key: 'birthCity', label: 'Cidade de nascimento', type: 'text' },
        { key: 'birthState', label: 'UF de nascimento', type: 'text', placeholder: 'Ex: SP' },
        { key: 'nationality', label: 'Nacionalidade', type: 'text', placeholder: 'Ex: Brasileira' }
      ]
    }
  ]
};

// ==================== CIN (CARTEIRA DE IDENTIDADE NACIONAL) ====================
export const cinOcrConfig: DocumentOcrConfig = {
  documentType: 'cin',
  title: 'CIN – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'Dados Principais',
      icon: '🆔',
      defaultExpanded: true,
      fields: [
        { key: 'fullName', label: 'Nome completo', type: 'text', required: true },
        { key: 'cinNumber', label: 'Número CIN', type: 'text', required: true, placeholder: 'Ex: 000000000000' },
        { key: 'socialName', label: 'Nome social', type: 'text' },
        { key: 'cpf', label: 'CPF', type: 'text', required: true, placeholder: '000.000.000-00' },
        { key: 'birthDate', label: 'Data de nascimento', type: 'date', required: true },
        { key: 'sex', label: 'Sexo', type: 'select', required: true, options: ['M', 'F', 'X'] },
        { key: 'issueDate', label: 'Data de emissão', type: 'date', required: true },
        { key: 'expiryDate', label: 'Data de validade', type: 'date' },
        { key: 'issuingState', label: 'UF Emissora', type: 'text', required: true, placeholder: 'Ex: SP' },
        { key: 'qrCode', label: 'QR Code', type: 'text', placeholder: 'Código extraído do QR' }
      ]
    },
    {
      id: 'origin',
      title: 'Filiação e Origem',
      icon: '👨‍👩‍👧',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'motherName', label: 'Nome da mãe', type: 'text', required: true },
        { key: 'fatherName', label: 'Nome do pai', type: 'text' },
        { key: 'birthCity', label: 'Cidade de nascimento', type: 'text' },
        { key: 'birthState', label: 'UF de nascimento', type: 'text' },
        { key: 'birthCountry', label: 'País de nascimento', type: 'text' },
        { key: 'nationality', label: 'Nacionalidade', type: 'text' }
      ]
    }
  ]
};

// ==================== VISTO ====================
export const visaOcrConfig: DocumentOcrConfig = {
  documentType: 'visa',
  title: 'Visto – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'Dados Principais',
      icon: '✈️',
      defaultExpanded: true,
      fields: [
        { key: 'fullName', label: 'Nome completo', type: 'text', required: true },
        { key: 'visaNumber', label: 'Número do visto', type: 'text', required: true },
        { key: 'visaType', label: 'Tipo/Classe do visto', type: 'text', required: true, placeholder: 'Ex: VITEM IV' },
        { key: 'passportNumber', label: 'Número do passaporte', type: 'text', required: true },
        { key: 'nationality', label: 'Nacionalidade', type: 'text', required: true },
        { key: 'birthDate', label: 'Data de nascimento', type: 'date', required: true },
        { key: 'sex', label: 'Sexo', type: 'select', required: true, options: ['M', 'F', 'X'] },
        { key: 'issueDate', label: 'Data de emissão', type: 'date', required: true },
        { key: 'expiryDate', label: 'Data de validade', type: 'date', required: true },
        { key: 'entries', label: 'Quantidade de entradas', type: 'select', options: ['Única', 'Múltiplas', 'Dupla'] },
        { key: 'issuingPost', label: 'Posto emissor', type: 'text', placeholder: 'Ex: São Paulo' },
        { key: 'issuingCountry', label: 'País emissor', type: 'text', required: true }
      ]
    },
    {
      id: 'mrz',
      title: 'Informações MRZ',
      icon: '🔖',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'mrz1', label: 'Linha 1 MRZ', type: 'textarea' },
        { key: 'mrz2', label: 'Linha 2 MRZ', type: 'textarea' }
      ]
    }
  ]
};

// ==================== CERTIDÃO DE CASAMENTO ====================
export const marriageCertOcrConfig: DocumentOcrConfig = {
  documentType: 'marriage',
  title: 'Certidão de Casamento – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'Dados Principais',
      icon: '💍',
      defaultExpanded: true,
      fields: [
        { key: 'spouse1Name', label: 'Nome do cônjuge 1', type: 'text', required: true },
        { key: 'spouse2Name', label: 'Nome do cônjuge 2', type: 'text', required: true },
        { key: 'marriageDate', label: 'Data do casamento', type: 'date', required: true },
        { key: 'marriageCity', label: 'Cidade do casamento', type: 'text', required: true },
        { key: 'marriageState', label: 'UF do casamento', type: 'text', placeholder: 'Ex: SP' },
        { key: 'propertyRegime', label: 'Regime de bens', type: 'select', 
          options: ['Comunhão Parcial', 'Comunhão Universal', 'Separação Total', 'Participação Final nos Aquestos'] }
      ]
    },
    {
      id: 'registry',
      title: 'Cartório e Registro',
      icon: '📜',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'notaryOffice', label: 'Cartório', type: 'text', required: true },
        { key: 'district', label: 'Comarca', type: 'text' },
        { key: 'book', label: 'Livro', type: 'text' },
        { key: 'page', label: 'Folha', type: 'text' },
        { key: 'term', label: 'Termo', type: 'text' },
        { key: 'registrar', label: 'Oficial', type: 'text' },
        { key: 'digitalSignature', label: 'Assinatura digital', type: 'text', placeholder: 'Hash ou QR Code' }
      ]
    }
  ]
};

// ==================== DECLARAÇÃO DE UNIÃO ESTÁVEL ====================
export const civilUnionOcrConfig: DocumentOcrConfig = {
  documentType: 'civilUnion',
  title: 'União Estável – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'Dados dos Parceiros',
      icon: '🤝',
      defaultExpanded: true,
      fields: [
        { key: 'partner1Name', label: 'Nome do parceiro 1', type: 'text', required: true },
        { key: 'partner1CPF', label: 'CPF do parceiro 1', type: 'text', required: true },
        { key: 'partner1RG', label: 'RG do parceiro 1', type: 'text' },
        { key: 'partner2Name', label: 'Nome do parceiro 2', type: 'text', required: true },
        { key: 'partner2CPF', label: 'CPF do parceiro 2', type: 'text', required: true },
        { key: 'partner2RG', label: 'RG do parceiro 2', type: 'text' },
        { key: 'unionStartDate', label: 'Data de início da união', type: 'date', required: true },
        { key: 'propertyRegime', label: 'Regime de bens', type: 'select',
          options: ['Comunhão Parcial', 'Comunhão Universal', 'Separação Total', 'Participação Final nos Aquestos'] }
      ]
    },
    {
      id: 'registry',
      title: 'Tabelionato e Registro',
      icon: '📜',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'notaryOffice', label: 'Tabelionato', type: 'text', required: true },
        { key: 'notaryPublic', label: 'Tabelião', type: 'text' },
        { key: 'address', label: 'Endereço', type: 'text' },
        { key: 'city', label: 'Cidade', type: 'text' },
        { key: 'state', label: 'UF', type: 'text' },
        { key: 'registrationDate', label: 'Data do registro', type: 'date' },
        { key: 'book', label: 'Livro', type: 'text' },
        { key: 'page', label: 'Folha', type: 'text' },
        { key: 'digitalSignature', label: 'Assinatura digital', type: 'text', placeholder: 'Hash ou QR Code' }
      ]
    }
  ]
};

// ==================== CERTIDÃO DE NASCIMENTO ====================
export const birthCertOcrConfig: DocumentOcrConfig = {
  documentType: 'birth',
  title: 'Certidão de Nascimento – Revisão OCR',
  sections: [
    {
      id: 'main',
      title: 'Dados Principais',
      icon: '👶',
      defaultExpanded: true,
      fields: [
        { key: 'fullName', label: 'Nome completo', type: 'text', required: true },
        { key: 'cpf', label: 'CPF', type: 'text', placeholder: '000.000.000-00' },
        { key: 'birthDate', label: 'Data de nascimento', type: 'date', required: true },
        { key: 'birthTime', label: 'Hora de nascimento', type: 'text', placeholder: 'Ex: 14:30' },
        { key: 'sex', label: 'Sexo', type: 'select', required: true, options: ['M', 'F'] },
        { key: 'birthCity', label: 'Cidade de nascimento', type: 'text', required: true },
        { key: 'birthState', label: 'UF de nascimento', type: 'text', required: true },
        { key: 'birthCountry', label: 'País de nascimento', type: 'text', placeholder: 'Ex: Brasil' }
      ]
    },
    {
      id: 'parents',
      title: 'Filiação',
      icon: '👨‍👩‍👧',
      defaultExpanded: true,
      fields: [
        { key: 'motherName', label: 'Nome da mãe', type: 'text', required: true },
        { key: 'motherCPF', label: 'CPF da mãe', type: 'text' },
        { key: 'motherBirthplace', label: 'Naturalidade da mãe', type: 'text' },
        { key: 'fatherName', label: 'Nome do pai', type: 'text' },
        { key: 'fatherCPF', label: 'CPF do pai', type: 'text' },
        { key: 'fatherBirthplace', label: 'Naturalidade do pai', type: 'text' }
      ]
    },
    {
      id: 'grandparents',
      title: 'Avós',
      icon: '👴👵',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'maternalGrandmotherName', label: 'Avó materna', type: 'text' },
        { key: 'maternalGrandfatherName', label: 'Avô materno', type: 'text' },
        { key: 'paternalGrandmotherName', label: 'Avó paterna', type: 'text' },
        { key: 'paternalGrandfatherName', label: 'Avô paterno', type: 'text' }
      ]
    },
    {
      id: 'registry',
      title: 'Cartório e Registro',
      icon: '📜',
      collapsible: true,
      defaultExpanded: true,
      fields: [
        { key: 'registrationDate', label: 'Data do registro', type: 'date' },
        { key: 'notaryOffice', label: 'Cartório', type: 'text', required: true },
        { key: 'district', label: 'Comarca', type: 'text' },
        { key: 'book', label: 'Livro', type: 'text' },
        { key: 'page', label: 'Folha', type: 'text' },
        { key: 'term', label: 'Termo', type: 'text' },
        { key: 'registrar', label: 'Oficial', type: 'text' },
        { key: 'digitalSignature', label: 'Assinatura digital', type: 'text', placeholder: 'Hash ou QR Code' }
      ]
    }
  ]
};

// ==================== EXPORTAÇÃO CENTRAL ====================
export const ocrConfigs = {
  passport: passportOcrConfig,
  cnh: cnhOcrConfig,
  rg: rgOcrConfig,
  cin: cinOcrConfig,
  visa: visaOcrConfig,
  marriage: marriageCertOcrConfig,
  civilUnion: civilUnionOcrConfig,
  birth: birthCertOcrConfig
};

export type DocumentType = keyof typeof ocrConfigs;

export function getOcrConfig(documentType: DocumentType): DocumentOcrConfig {
  return ocrConfigs[documentType];
}