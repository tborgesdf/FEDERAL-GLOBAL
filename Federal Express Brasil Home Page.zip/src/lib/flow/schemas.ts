import { z } from "zod";

// Civil Status Step
export const CivilStatusSchema = z.object({
  civilStatus: z.enum(['single', 'married', 'stable_union'], {
    required_error: "Selecione seu estado civil"
  })
});

export type CivilStatusData = z.infer<typeof CivilStatusSchema>;

// Socials Step
export const SocialsSchema = z.object({
  hasSocials: z.boolean(),
  handles: z.array(z.object({
    platform: z.string(),
    handle: z.string().min(1, "Handle não pode estar vazio")
  })).optional()
}).refine(
  (data) => {
    if (data.hasSocials) {
      return data.handles && data.handles.length > 0;
    }
    return true;
  },
  {
    message: "Se você possui redes sociais, preencha pelo menos uma",
    path: ["handles"]
  }
);

export type SocialsData = z.infer<typeof SocialsSchema>;

// Passport Step
export const PassportSchema = z.object({
  file: z.instanceof(File, { message: "Envie o documento do passaporte" }),
  ocrData: z.object({
    number: z.string().min(1),
    fullName: z.string().min(1),
    birthDate: z.string().min(1),
    issueDate: z.string().min(1),
    expiryDate: z.string().min(1),
    nationality: z.string().min(1),
    mrz: z.string().min(1)
  }).nullable()
});

export type PassportData = z.infer<typeof PassportSchema>;

// Previous Visa Step (conditional - renewal only)
export const PreviousVisaSchema = z.object({
  file: z.instanceof(File, { message: "Envie o documento do visto anterior" }),
  ocrData: z.object({
    number: z.string().min(1),
    type: z.string().min(1),
    issueDate: z.string().min(1),
    expiryDate: z.string().min(1)
  }).nullable()
});

export type PreviousVisaData = z.infer<typeof PreviousVisaSchema>;

// Brazilian ID Step
export const BrazilianIDSchema = z.object({
  type: z.enum(['rg', 'cnh', 'cnh-digital']),
  frontFile: z.instanceof(File).nullable(),
  backFile: z.instanceof(File).nullable(),
  pdfFile: z.instanceof(File).nullable(),
  ocrData: z.object({
    number: z.string().min(1),
    fullName: z.string().min(1),
    cpf: z.string().min(1),
    birthDate: z.string().min(1),
    issuer: z.string().min(1),
    state: z.string().min(1)
  }).nullable()
}).refine(
  (data) => {
    if (data.type === 'cnh-digital') {
      return data.pdfFile !== null;
    } else {
      return data.frontFile !== null && data.backFile !== null;
    }
  },
  {
    message: "Envie todos os documentos necessários",
    path: ["frontFile"]
  }
);

export type BrazilianIDData = z.infer<typeof BrazilianIDSchema>;

// Marriage Certificate Step (conditional)
export const MarriageCertSchema = z.object({
  file: z.instanceof(File, { message: "Envie a certidão de casamento/união" }),
  ocrData: z.object({
    spouseName: z.string().min(1),
    marriageDate: z.string().min(1),
    registryOffice: z.string().min(1),
    state: z.string().min(1),
    book: z.string().optional(),
    page: z.string().optional(),
    term: z.string().optional()
  }).nullable()
});

export type MarriageCertData = z.infer<typeof MarriageCertSchema>;

// Selfie Step
export const SelfieSchema = z.object({
  file: z.instanceof(File, { message: "Capture uma selfie" }),
  quality: z.object({
    lighting: z.enum(['good', 'poor', 'neutral']),
    face: z.enum(['centered', 'off-center', 'not-detected']),
    eyes: z.enum(['open', 'closed', 'unclear']),
    blur: z.enum(['sharp', 'blurry'])
  }).nullable(),
  isApproved: z.boolean()
}).refine(
  (data) => data.isApproved === true,
  {
    message: "A selfie precisa ser aprovada. Tente novamente com melhor iluminação e enquadramento.",
    path: ["isApproved"]
  }
);

export type SelfieData = z.infer<typeof SelfieSchema>;

// Questionnaire Step
export const QuestionnaireSchema = z.object({
  extractedData: z.object({
    fullName: z.string().optional(),
    cpf: z.string().optional(),
    birthDate: z.string().optional(),
    passportNumber: z.string().optional(),
    nationality: z.string().optional()
  }),
  birthCity: z.string().min(2, "Informe a cidade de nascimento"),
  birthCountry: z.string().min(2, "Informe o país de nascimento"),
  fatherName: z.string().min(3, "Informe o nome completo do pai"),
  motherName: z.string().min(3, "Informe o nome completo da mãe"),
  occupation: z.string().min(2, "Informe sua ocupação"),
  employer: z.string().min(2, "Informe o nome do empregador"),
  travelPurpose: z.string().min(3, "Informe o propósito da viagem"),
  stayDuration: z.string().min(2, "Informe a duração da estadia"),
  usContact: z.string().min(3, "Informe o contato nos EUA"),
  usAddress: z.string().min(5, "Informe o endereço nos EUA"),
  hasBeenDeported: z.boolean(),
  hasCriminalRecord: z.boolean(),
  hasInfectiousDisease: z.boolean(),
  hasDrugHistory: z.boolean(),
  hasBeenDeniedVisa: z.boolean()
});

export type QuestionnaireData = z.infer<typeof QuestionnaireSchema>;

// Helper to get schema by step ID
export function getSchemaForStep(stepId: string): z.ZodSchema | null {
  switch (stepId) {
    case 'civil-status':
      return CivilStatusSchema;
    case 'socials':
      return SocialsSchema;
    case 'passport':
      return PassportSchema;
    case 'previous-visa':
      return PreviousVisaSchema;
    case 'br-id':
      return BrazilianIDSchema;
    case 'marriage-cert':
      return MarriageCertSchema;
    case 'selfie':
      return SelfieSchema;
    case 'questionnaire':
      return QuestionnaireSchema;
    default:
      return null;
  }
}
