export type StepId =
  | 'civil-status'
  | 'socials'
  | 'passport'
  | 'previous-visa'
  | 'br-id'
  | 'marriage-cert'
  | 'selfie'
  | 'questionnaire';

export interface Step {
  id: StepId;
  label: string;
  shortLabel?: string;
  isConditional?: boolean;
  condition?: (context: FlowContext) => boolean;
}

export interface FlowContext {
  visaType: 'first' | 'renewal';
  civilStatus: 'single' | 'married' | 'stable_union';
}

export const ALL_STEPS: Step[] = [
  {
    id: 'civil-status',
    label: 'Estado Civil',
    shortLabel: 'Civil'
  },
  {
    id: 'socials',
    label: 'Redes Sociais',
    shortLabel: 'Redes'
  },
  {
    id: 'passport',
    label: 'Passaporte',
    shortLabel: 'Pass.'
  },
  {
    id: 'previous-visa',
    label: 'Visto Anterior',
    shortLabel: 'Visto',
    isConditional: true,
    condition: (ctx) => ctx.visaType === 'renewal'
  },
  {
    id: 'br-id',
    label: 'RG/CNH',
    shortLabel: 'Doc.'
  },
  {
    id: 'marriage-cert',
    label: 'Certidão',
    shortLabel: 'Cert.',
    isConditional: true,
    condition: (ctx) => ctx.civilStatus === 'married' || ctx.civilStatus === 'stable_union'
  },
  {
    id: 'selfie',
    label: 'Selfie',
    shortLabel: 'Foto'
  },
  {
    id: 'questionnaire',
    label: 'Revisão DS-160',
    shortLabel: 'DS-160'
  }
];

/**
 * Get the sequence of steps based on context
 */
export function getStepSequence(context: FlowContext): StepId[] {
  return ALL_STEPS
    .filter(step => !step.condition || step.condition(context))
    .map(step => step.id);
}

/**
 * Get the next step in the sequence
 */
export function getNextStep(currentStep: StepId, context: FlowContext): StepId | null {
  const sequence = getStepSequence(context);
  const currentIndex = sequence.indexOf(currentStep);
  
  if (currentIndex === -1 || currentIndex >= sequence.length - 1) {
    return null;
  }
  
  return sequence[currentIndex + 1];
}

/**
 * Get the previous step in the sequence
 */
export function getPreviousStep(currentStep: StepId, context: FlowContext): StepId | null {
  const sequence = getStepSequence(context);
  const currentIndex = sequence.indexOf(currentStep);
  
  if (currentIndex <= 0) {
    return null;
  }
  
  return sequence[currentIndex - 1];
}

/**
 * Check if a step is accessible based on completed steps
 */
export function isStepAccessible(
  targetStep: StepId,
  currentStep: StepId,
  lastCompletedStep: StepId | null,
  context: FlowContext
): boolean {
  const sequence = getStepSequence(context);
  const targetIndex = sequence.indexOf(targetStep);
  const currentIndex = sequence.indexOf(currentStep);
  const lastCompletedIndex = lastCompletedStep ? sequence.indexOf(lastCompletedStep) : -1;
  
  // Can always access current step
  if (targetStep === currentStep) return true;
  
  // Can access any completed step
  if (lastCompletedIndex >= 0 && targetIndex <= lastCompletedIndex) return true;
  
  // Can't access future steps
  return false;
}

/**
 * Get step metadata
 */
export function getStep(stepId: StepId): Step | undefined {
  return ALL_STEPS.find(s => s.id === stepId);
}

/**
 * Calculate progress percentage
 */
export function calculateProgress(currentStep: StepId, context: FlowContext): number {
  const sequence = getStepSequence(context);
  const currentIndex = sequence.indexOf(currentStep);
  
  if (currentIndex === -1) return 0;
  
  return Math.round(((currentIndex + 1) / sequence.length) * 100);
}
