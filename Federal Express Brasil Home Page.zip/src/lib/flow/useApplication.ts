import { useState, useEffect } from "react";
import { createClient } from "../supabase/client";
import { StepId, FlowContext } from "./steps";

interface VisaApplication {
  id: string;
  user_id: string;
  visa_type: 'first' | 'renewal';
  civil_status: 'single' | 'married' | 'stable_union';
  current_step: StepId;
  last_completed_step: StepId | null;
  draft: Record<string, any>;
  draft_updated_at: string | null;
  status: string;
  created_at: string;
}

export function useApplication() {
  const [application, setApplication] = useState<VisaApplication | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const supabase = createClient();

  useEffect(() => {
    loadApplication();
  }, []);

  const loadApplication = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error("User not authenticated");
      }

      const { data, error: dbError } = await supabase
        .from('visa_applications')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'in_progress')
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (dbError) throw dbError;

      setApplication(data);
    } catch (err: any) {
      console.error("Error loading application:", err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const getContext = (): FlowContext | null => {
    if (!application) return null;

    return {
      visaType: application.visa_type,
      civilStatus: application.civil_status
    };
  };

  const saveDraft = async (step: StepId, payload: any): Promise<void> => {
    if (!application) throw new Error("No active application");

    try {
      const draft = {
        ...(application.draft || {}),
        [step]: payload
      };

      const { error } = await supabase
        .from('visa_applications')
        .update({
          draft,
          draft_updated_at: new Date().toISOString()
        })
        .eq('id', application.id);

      if (error) throw error;

      // Update local state
      setApplication(prev => prev ? {
        ...prev,
        draft,
        draft_updated_at: new Date().toISOString()
      } : null);

      // Save checkpoint
      await supabase.from('flow_checkpoints').insert({
        application_id: application.id,
        step,
        payload
      });
    } catch (err: any) {
      console.error("Error saving draft:", err);
      throw err;
    }
  };

  const completeStep = async (currentStep: StepId, nextStep: StepId | null, payload: any): Promise<void> => {
    if (!application) throw new Error("No active application");

    try {
      const draft = {
        ...(application.draft || {}),
        [currentStep]: payload
      };

      const updateData: any = {
        draft,
        last_completed_step: currentStep,
        draft_updated_at: new Date().toISOString()
      };

      // If there's a next step, update current_step
      if (nextStep) {
        updateData.current_step = nextStep;
      } else {
        // No next step means we're done
        updateData.status = 'completed';
      }

      const { error } = await supabase
        .from('visa_applications')
        .update(updateData)
        .eq('id', application.id);

      if (error) throw error;

      // Update local state
      setApplication(prev => prev ? {
        ...prev,
        ...updateData
      } : null);

      // Save checkpoint
      await supabase.from('flow_checkpoints').insert({
        application_id: application.id,
        step: currentStep,
        payload
      });
    } catch (err: any) {
      console.error("Error completing step:", err);
      throw err;
    }
  };

  const updateCivilStatus = async (civilStatus: 'single' | 'married' | 'stable_union'): Promise<void> => {
    if (!application) throw new Error("No active application");

    try {
      const { error } = await supabase
        .from('visa_applications')
        .update({ civil_status: civilStatus })
        .eq('id', application.id);

      if (error) throw error;

      setApplication(prev => prev ? { ...prev, civil_status: civilStatus } : null);
    } catch (err: any) {
      console.error("Error updating civil status:", err);
      throw err;
    }
  };

  const getDraftData = (step: StepId): any => {
    return application?.draft?.[step] || null;
  };

  return {
    application,
    isLoading,
    error,
    context: getContext(),
    loadApplication,
    saveDraft,
    completeStep,
    updateCivilStatus,
    getDraftData
  };
}
