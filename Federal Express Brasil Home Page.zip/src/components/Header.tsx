import { MapPin, Calendar, Cloud, CloudRain, Sun } from "lucide-react";
import { useState, useEffect } from "react";
import logoImage from "figma:asset/fdb4ef494a99e771ad2534fa1ee70561858f6471.png";
import WeatherPanel from "./WeatherPanel";

// Mock data structure para futura integração de API
interface WeatherData {
  location: string;
  tempC: number;
  description: string;
  icon: string;
  forecast: Array<{
    dateISO: string;
    minC: number;
    maxC: number;
    icon: string;
  }>;
  fetchedAt: string;
}

interface HeaderProps {
  onNavigateToRegister?: () => void;
  onNavigateToLogin?: () => void;
  onNavigateToHome?: () => void;
  currentPage?: "home" | "register" | "login" | "dashboard";
  isLoggedIn?: boolean;
  userEmail?: string;
  onLogout?: () => void;
  onCancel?: () => void;
}

const mockWeatherData: WeatherData = {
  location: "São Paulo, Brasil",
  tempC: 24,
  description: "Parcialmente nublado",
  icon: "⛅",
  forecast: [
    { dateISO: "2025-11-07", minC: 18, maxC: 26, icon: "⛅" },
    { dateISO: "2025-11-08", minC: 19, maxC: 27, icon: "☀️" },
    { dateISO: "2025-11-09", minC: 17, maxC: 25, icon: "🌧️" },
    { dateISO: "2025-11-10", minC: 16, maxC: 23, icon: "⛈️" },
    { dateISO: "2025-11-11", minC: 18, maxC: 26, icon: "☀️" }
  ],
  fetchedAt: "2025-11-06T20:21:00Z"
};

export default function Header({ onNavigateToRegister, onNavigateToLogin, onNavigateToHome, currentPage = "home", isLoggedIn = false, userEmail = "", onLogout, onCancel }: HeaderProps = {}) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isSticky, setIsSticky] = useState(false);
  const [hoveredButton, setHoveredButton] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 0);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const formatDate = (date: Date) => {
    const days = [
      "domingo",
      "segunda-feira",
      "terça-feira",
      "quarta-feira",
      "quinta-feira",
      "sexta-feira",
      "sábado"
    ];
    const months = [
      "janeiro", "fevereiro", "março", "abril", "maio", "junho",
      "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
    ];
    
    const dayName = days[date.getDay()];
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    
    return `${dayName}, ${day} de ${month} de ${year} – ${hours}:${minutes}`;
  };

  const getDayName = (dateISO: string) => {
    const date = new Date(dateISO);
    const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
    return days[date.getDay()];
  };

  return (
    <header
      className={`sticky top-0 z-50 bg-white transition-shadow duration-300 ${
        isSticky ? "shadow-lg" : "shadow-[0_4px_12px_rgba(0,0,0,0.08)]"
      }`}
      style={{ height: "190px", marginBottom: "0" }}
    >
      <div className="mx-auto max-w-[1920px] h-full flex items-end" style={{ paddingLeft: "80px", paddingRight: "40px", paddingTop: "40px", paddingBottom: "24px" }}>
        {/* HeaderRow - Layout Horizontal com Space Between */}
        <div className="flex items-center justify-between w-full" style={{ gap: "32px" }}>
          
          {/* 1️⃣ Logo Box - Fixed Left */}
          <div 
            className="flex-shrink-0 bg-white rounded-2xl shadow-[0_2px_6px_rgba(0,0,0,0.08)] cursor-pointer transition-transform hover:scale-105 active:scale-95 flex items-center justify-center"
            style={{ 
              width: "160px", 
              height: "160px",
              padding: "16px"
            }}
            onClick={onNavigateToHome}
          >
            <img
              src={logoImage}
              alt="Federal Express Brasil - Soluções Migratórias"
              className="w-full h-full object-contain"
            />
          </div>

          {/* 2️⃣ WeatherCard - Centralizado Absolutamente */}
          <div className="absolute left-1/2 transform -translate-x-1/2" style={{ maxWidth: "600px" }}>
            <WeatherPanel />
          </div>

          {/* 3️⃣ UserBlock - Fixed Right */}
          <div className="flex-shrink-0 flex flex-col items-end" style={{ gap: "12px", maxWidth: "300px", paddingRight: "0px" }}>
            {isLoggedIn ? (
              <>
                {/* Chip de Usuário */}
                <div 
                  className="flex items-center gap-3 bg-white rounded-xl border border-[#E7EAF3]"
                  style={{ padding: "8px 16px", marginLeft: "-650px" }}
                >
                  <div 
                    className="rounded-full bg-[#0A4B9E] flex items-center justify-center"
                    style={{ width: "32px", height: "32px" }}
                  >
                    <span
                      style={{
                        fontFamily: "Poppins, sans-serif",
                        fontSize: "14px",
                        fontWeight: 700,
                        color: "#FFFFFF"
                      }}
                    >
                      {userEmail?.charAt(0).toUpperCase() || "U"}
                    </span>
                  </div>
                  <span
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      fontWeight: 500,
                      color: "#0A4B9E"
                    }}
                  >
                    {userEmail || "Usuário"}
                  </span>
                </div>
                
                {/* Botão Sair */}
                <button
                  onClick={() => {
                    onLogout?.();
                    onNavigateToHome?.();
                  }}
                  onMouseEnter={() => setHoveredButton("logout")}
                  onMouseLeave={() => setHoveredButton(null)}
                  className="rounded-xl transition-all duration-200"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600,
                    backgroundColor: hoveredButton === "logout" ? "#E03E3E" : "#FF4E4E",
                    color: "#FFFFFF",
                    padding: "10px 20px"
                  }}
                >
                  Sair
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={onNavigateToLogin}
                  onMouseEnter={() => setHoveredButton("login")}
                  onMouseLeave={() => setHoveredButton(null)}
                  className="rounded-xl shadow-lg transition-all duration-200"
                  style={{
                    fontFamily: "Poppins, sans-serif",
                    fontSize: "16px",
                    fontWeight: 600,
                    backgroundColor: "#0058CC",
                    color: "white",
                    opacity: hoveredButton === "login" ? 0.9 : 1,
                    transform: hoveredButton === "login" ? "scale(1.03)" : "scale(1)",
                    padding: "10px 20px"
                  }}
                >
                  Login
                </button>

                <button
                  onClick={currentPage === "home" ? onNavigateToRegister : undefined}
                  onMouseEnter={() => setHoveredButton("signup")}
                  onMouseLeave={() => setHoveredButton(null)}
                  className="rounded-xl shadow-lg transition-all duration-200"
                  style={{
                    fontFamily: "Poppins, sans-serif",
                    fontSize: "16px",
                    fontWeight: 600,
                    backgroundColor: "#0058CC",
                    color: "white",
                    opacity: hoveredButton === "signup" ? 0.9 : 1,
                    transform: hoveredButton === "signup" ? "scale(1.03)" : "scale(1)",
                    padding: "10px 20px",
                    whiteSpace: "nowrap"
                  }}
                >
                  Cadastrar-se
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}