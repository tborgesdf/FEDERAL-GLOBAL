import { useState, useEffect } from "react";
import { Cloud, CloudRain, Sun, CloudSnow, Wind, Droplets, Eye } from "lucide-react";

interface WeatherData {
  temp: number;
  condition: string;
  city: string;
  humidity?: number;
  visibility?: number;
  windSpeed?: number;
  icon: string;
}

export default function WeatherPanel() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Mapeamento de condições para ícones
  const getWeatherIcon = (condition: string, weatherCode?: number) => {
    const conditionLower = condition.toLowerCase();
    
    // Para Open-Meteo weather codes
    if (weatherCode !== undefined) {
      if (weatherCode === 0) return { icon: <Sun size={32} />, color: "#F59E0B" };
      if (weatherCode >= 1 && weatherCode <= 3) return { icon: <Cloud size={32} />, color: "#6B7280" };
      if (weatherCode >= 51 && weatherCode <= 67) return { icon: <CloudRain size={32} />, color: "#3B82F6" };
      if (weatherCode >= 71 && weatherCode <= 77) return { icon: <CloudSnow size={32} />, color: "#60A5FA" };
      if (weatherCode >= 80 && weatherCode <= 82) return { icon: <CloudRain size={32} />, color: "#2563EB" };
      return { icon: <Cloud size={32} />, color: "#6B7280" };
    }
    
    // Para OpenWeatherMap
    if (conditionLower.includes("clear") || conditionLower.includes("sun")) {
      return { icon: <Sun size={32} />, color: "#F59E0B" };
    }
    if (conditionLower.includes("rain") || conditionLower.includes("drizzle")) {
      return { icon: <CloudRain size={32} />, color: "#2563EB" };
    }
    if (conditionLower.includes("cloud")) {
      return { icon: <Cloud size={32} />, color: "#6B7280" };
    }
    if (conditionLower.includes("snow")) {
      return { icon: <CloudSnow size={32} />, color: "#60A5FA" };
    }
    
    return { icon: <Cloud size={32} />, color: "#6B7280" };
  };

  // Tradução de condições
  const translateCondition = (condition: string) => {
    const translations: Record<string, string> = {
      "clear sky": "Céu limpo",
      "few clouds": "Poucas nuvens",
      "scattered clouds": "Nuvens dispersas",
      "broken clouds": "Nublado",
      "overcast clouds": "Nublado",
      "light rain": "Chuva leve",
      "moderate rain": "Chuva moderada",
      "heavy rain": "Chuva forte",
      "rain": "Chuva",
      "thunderstorm": "Tempestade",
      "snow": "Neve",
      "mist": "Neblina",
      "fog": "Névoa"
    };
    
    return translations[condition.toLowerCase()] || condition;
  };

  // Buscar dados do OpenWeatherMap
  const fetchOpenWeatherMap = async (apiKey: string, lat: number = -22.9068, lon: number = -43.1729) => {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric&lang=pt_br`
    );
    
    if (!response.ok) {
      throw new Error("OpenWeatherMap API failed");
    }
    
    const data = await response.json();
    
    return {
      temp: Math.round(data.main.temp),
      condition: translateCondition(data.weather[0].description),
      city: data.name,
      humidity: data.main.humidity,
      visibility: Math.round(data.visibility / 1000),
      windSpeed: Math.round(data.wind.speed * 3.6),
      icon: data.weather[0].main
    };
  };

  // Buscar dados do Open-Meteo (fallback)
  const fetchOpenMeteo = async (lat: number = -22.9068, lon: number = -43.1729) => {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=America/Sao_Paulo`
    );
    
    if (!response.ok) {
      throw new Error("Open-Meteo API failed");
    }
    
    const data = await response.json();
    const current = data.current_weather;
    
    // Mapeamento de códigos de clima para descrições
    const weatherCodeMap: Record<number, string> = {
      0: "Céu limpo",
      1: "Principalmente limpo",
      2: "Parcialmente nublado",
      3: "Nublado",
      45: "Neblina",
      48: "Névoa",
      51: "Garoa leve",
      53: "Garoa moderada",
      55: "Garoa densa",
      61: "Chuva leve",
      63: "Chuva moderada",
      65: "Chuva forte",
      71: "Neve leve",
      73: "Neve moderada",
      75: "Neve forte",
      80: "Pancadas de chuva leves",
      81: "Pancadas de chuva moderadas",
      82: "Pancadas de chuva fortes"
    };
    
    return {
      temp: Math.round(current.temperature),
      condition: weatherCodeMap[current.weathercode] || "Não disponível",
      city: "São Paulo", // Open-Meteo não retorna nome da cidade
      humidity: undefined,
      visibility: undefined,
      windSpeed: Math.round(current.windspeed),
      icon: String(current.weathercode)
    };
  };

  useEffect(() => {
    const fetchWeather = async () => {
      setLoading(true);
      setError(null);
      
      try {
        // Tentar obter localização do usuário
        let lat = -22.9068;
        let lon = -43.1729;
        
        if (navigator.geolocation) {
          try {
            const position = await new Promise<GeolocationPosition>((resolve, reject) => {
              navigator.geolocation.getCurrentPosition(resolve, reject, {
                timeout: 5000
              });
            });
            lat = position.coords.latitude;
            lon = position.coords.longitude;
          } catch (geoError) {
            console.log("Usando localização padrão (São Paulo)");
          }
        }
        
        // Primeiro, tentar OpenWeatherMap
        const apiKey = typeof import.meta !== 'undefined' && 
                      import.meta.env && 
                      import.meta.env.VITE_WEATHER_API_KEY 
                      ? import.meta.env.VITE_WEATHER_API_KEY 
                      : undefined;
        
        let weatherData: WeatherData;
        
        if (apiKey) {
          try {
            weatherData = await fetchOpenWeatherMap(apiKey, lat, lon);
            console.log("✅ Dados carregados: OpenWeatherMap");
          } catch (owmError) {
            console.log("⚠️ OpenWeatherMap falhou, usando Open-Meteo");
            weatherData = await fetchOpenMeteo(lat, lon);
          }
        } else {
          console.log("ℹ️ API Key não configurada, usando Open-Meteo");
          weatherData = await fetchOpenMeteo(lat, lon);
        }
        
        setWeather(weatherData);
      } catch (err) {
        console.error("Erro ao buscar dados de clima:", err);
        setError("Não foi possível carregar os dados do clima");
      } finally {
        setLoading(false);
      }
    };

    fetchWeather();
    
    // Atualizar a cada 20 minutos
    const interval = setInterval(fetchWeather, 20 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div 
        className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-md p-6 w-full max-w-[1080px] min-w-[320px]"
        style={{
          fontFamily: "Poppins, sans-serif"
        }}
      >
        <div className="flex items-center justify-center h-32">
          <div className="animate-pulse flex flex-col items-center gap-2">
            <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
            <p style={{ 
              fontFamily: "Poppins, sans-serif",
              fontSize: "14px",
              color: "#6B7280"
            }}>
              Carregando previsão...
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !weather) {
    return (
      <div 
        className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-md p-6 w-full max-w-[600px] min-w-[320px]"
        style={{
          fontFamily: "Poppins, sans-serif"
        }}
      >
        <div className="flex items-center justify-center h-32">
          <p style={{ 
            fontFamily: "Poppins, sans-serif",
            fontSize: "14px",
            color: "#EF4444"
          }}>
            {error || "Erro ao carregar clima"}
          </p>
        </div>
      </div>
    );
  }

  const { icon: WeatherIcon, color: iconColor } = getWeatherIcon(weather.condition, weather.icon ? Number(weather.icon) : undefined);

  return (
    <div 
      className="bg-white rounded-2xl border border-[#E7EAF3] shadow-[0_8px_20px_rgba(0,0,0,0.05)] transition-all duration-300 hover:shadow-[0_12px_32px_rgba(0,0,0,0.08)]"
      style={{
        fontFamily: "Inter, sans-serif",
        padding: "20px 24px"
      }}
    >
      {/* Layout Horizontal Compacto */}
      <div className="flex items-center gap-6 w-full">
        {/* Bloco 1: Localização e Data */}
        <div className="flex flex-col gap-1.5">
          <h3 
            id="city_text"
            style={{ 
              fontFamily: "Poppins, sans-serif",
              fontSize: "16px",
              fontWeight: 600,
              color: "#0A4B9E",
              lineHeight: 1.2,
              whiteSpace: "nowrap"
            }}
          >
            {weather.city}
          </h3>
          <p style={{ 
            fontFamily: "Inter, sans-serif",
            fontSize: "11px",
            color: "#6B7280",
            lineHeight: 1.3
          }}>
            {new Date().getDate()} de {new Date().toLocaleDateString('pt-BR', { month: 'long' })}
            <br />
            {new Date().toLocaleDateString('pt-BR', { weekday: 'long' })}
          </p>
        </div>

        {/* Bloco 2: Temperatura + Ícone + Condição */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span 
              id="temp_text"
              style={{ 
                fontFamily: "Poppins, sans-serif",
                fontSize: "48px",
                fontWeight: 700,
                color: "#2563EB",
                lineHeight: 1
              }}
            >
              {weather.temp}°
            </span>
            
            <div 
              id="weather_icon"
              style={{ color: iconColor }}
              className="flex items-center justify-center"
              aria-label={`condição: ${weather.condition}`}
              role="img"
            >
              {WeatherIcon}
            </div>
          </div>
        </div>

        {/* Bloco 3: Condição */}
        <div className="flex flex-col gap-0.5">
          <p 
            id="condition_text"
            role="status"
            style={{ 
              fontFamily: "Inter, sans-serif",
              fontSize: "13px",
              fontWeight: 400,
              color: "#374151",
              lineHeight: 1.3
            }}
          >
            {weather.condition}
          </p>
        </div>

        {/* Bloco 4: Vento */}
        {weather.windSpeed && (
          <div className="flex items-center gap-1.5">
            <Wind size={14} className="text-[#6B7280]" aria-hidden="true" />
            <span style={{ 
              fontFamily: "Inter, sans-serif",
              fontSize: "13px",
              fontWeight: 600,
              color: "#111827"
            }}>
              {weather.windSpeed} km/h
            </span>
            <span style={{ 
              fontFamily: "Inter, sans-serif",
              fontSize: "11px",
              color: "#6B7280"
            }}>
              Vento
            </span>
          </div>
        )}
      </div>

      {/* Rodapé - Atualização */}
      <div className="mt-3 pt-3 border-t border-[#E7EAF3]">
        <p style={{ 
          fontFamily: "Inter, sans-serif",
          fontSize: "9px",
          color: "#9CA3AF",
          lineHeight: 1.3,
          textAlign: "center",
          whiteSpace: "nowrap"
        }}>
          Atualizado automaticamente • 20 min
        </p>
      </div>
    </div>
  );
}