/**
 * 🎨 WeatherPanel - Exportação para Figma
 * 
 * Este arquivo serve como referência para criar o component
 * no Figma com as props e estrutura corretas.
 * 
 * ESTRUTURA DO FRAME NO FIGMA:
 * 
 * WeatherPanel (Auto Layout, Vertical, 24px padding)
 * ├── Header (Horizontal, space-between)
 * │   ├── CityInfo (Vertical)
 * │   │   ├── city_text (Text, Poppins SemiBold 18px)
 * │   │   └── date_text (Text, Poppins Regular 14px)
 * │   └── weather_icon (Component, 48x48)
 * ├── TempSection (Vertical)
 * │   ├── TempDisplay (Horizontal, baseline)
 * │   │   ├── temp_text (Text, Poppins SemiBold 56px, #2563EB)
 * │   │   └── unit_text (Text, Poppins Regular 24px)
 * │   └── condition_text (Text, Poppins Medium 16px)
 * ├── Divider (Line, 1px, #E5E7EB)
 * └── DetailsGrid (Auto Layout, Horizontal, 3 columns)
 *     ├── HumidityCard
 *     │   ├── icon (droplets)
 *     │   ├── humidity_text (Text, Poppins SemiBold 16px)
 *     │   └── label (Text, Poppins Regular 12px)
 *     ├── WindCard
 *     │   ├── icon (wind)
 *     │   ├── wind_text (Text, Poppins SemiBold 16px)
 *     │   └── label (Text, Poppins Regular 12px)
 *     └── VisibilityCard
 *         ├── icon (eye)
 *         ├── visibility_text (Text, Poppins SemiBold 16px)
 *         └── label (Text, Poppins Regular 12px)
 */

import React from 'react';

interface WeatherPanelExportProps {
  /** Temperatura em graus Celsius */
  temp: number;
  
  /** Condição do clima (ex: "Céu limpo", "Nublado") */
  condition: string;
  
  /** Nome da cidade */
  city: string;
  
  /** Umidade em porcentagem (0-100) */
  humidity?: number;
  
  /** Velocidade do vento em km/h */
  windSpeed?: number;
  
  /** Visibilidade em km */
  visibility?: number;
  
  /** Código do ícone do clima */
  icon: 'sun' | 'cloud' | 'cloud-rain' | 'cloud-snow' | 'wind';
}

/**
 * VARIANTES DO COMPONENTE (Figma):
 * 
 * 1. Default (com todos os dados)
 * 2. Minimal (sem umidade/vento/visibilidade)
 * 3. Loading (placeholder animado)
 * 4. Error (mensagem de erro)
 * 
 * ESTADOS INTERATIVOS:
 * - Default
 * - Hover (shadow aumenta)
 * - Active (nenhum, componente é read-only)
 */

/**
 * DESIGN TOKENS (use no Figma):
 */
export const WEATHER_DESIGN_TOKENS = {
  colors: {
    background: {
      default: 'rgba(255, 255, 255, 0.8)',
      hover: 'rgba(255, 255, 255, 0.9)',
    },
    text: {
      primary: '#1F2937',
      secondary: '#6B7280',
      muted: '#9CA3AF',
      temp: '#2563EB',
    },
    icon: {
      sun: '#F59E0B',
      cloud: '#6B7280',
      rain: '#2563EB',
      snow: '#60A5FA',
      wind: '#6B7280',
    },
    border: '#E5E7EB',
  },
  
  typography: {
    fontFamily: 'Poppins',
    sizes: {
      temp: 56,
      city: 18,
      condition: 16,
      details: 16,
      label: 12,
      footer: 11,
    },
    weights: {
      regular: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
    },
  },
  
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
  },
  
  borderRadius: {
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
  },
  
  shadows: {
    default: '0 4px 6px rgba(0, 0, 0, 0.1)',
    hover: '0 10px 15px rgba(0, 0, 0, 0.1)',
  },
  
  size: {
    minWidth: 320,
    maxWidth: 600,
    minHeight: 280,
  },
};

/**
 * MAPEAMENTO DE ÍCONES (Figma Components):
 */
export const WEATHER_ICONS = {
  sun: '☀️',
  cloud: '☁️',
  'cloud-rain': '🌧️',
  'cloud-snow': '❄️',
  wind: '💨',
};

/**
 * EXEMPLO DE DADOS PARA PREVIEW (Figma):
 */
export const WEATHER_MOCK_DATA: WeatherPanelExportProps = {
  temp: 24,
  condition: 'Céu limpo',
  city: 'São Paulo',
  humidity: 65,
  windSpeed: 12,
  visibility: 10,
  icon: 'sun',
};

/**
 * PROPRIEDADES DO AUTO-LAYOUT (Figma):
 */
export const AUTO_LAYOUT_CONFIG = {
  mainFrame: {
    direction: 'vertical',
    spacing: 16,
    padding: {
      top: 24,
      right: 24,
      bottom: 24,
      left: 24,
    },
    horizontalAlign: 'left',
    verticalAlign: 'top',
  },
  
  header: {
    direction: 'horizontal',
    spacing: 16,
    horizontalAlign: 'space-between',
    verticalAlign: 'center',
  },
  
  tempSection: {
    direction: 'vertical',
    spacing: 8,
  },
  
  detailsGrid: {
    direction: 'horizontal',
    spacing: 16,
    distribution: 'space-evenly',
  },
};

/**
 * RESPONSIVIDADE (Breakpoints):
 */
export const BREAKPOINTS = {
  mobile: {
    width: 320,
    padding: 16,
    fontSize: {
      temp: 48,
      city: 16,
    },
  },
  
  tablet: {
    width: 480,
    padding: 20,
    fontSize: {
      temp: 52,
      city: 17,
    },
  },
  
  desktop: {
    width: 600,
    padding: 24,
    fontSize: {
      temp: 56,
      city: 18,
    },
  },
};

/**
 * ACESSIBILIDADE:
 */
export const ACCESSIBILITY = {
  // Contrast ratio mínimo: 4.5:1 para texto normal
  // Contrast ratio mínimo: 3:1 para texto grande (>18px)
  contrastRatios: {
    primaryText: 7.2, // #1F2937 on white
    secondaryText: 4.8, // #6B7280 on white
    tempText: 6.1, // #2563EB on white
  },
  
  // ARIA labels para screen readers
  ariaLabels: {
    temp: 'Temperatura atual',
    condition: 'Condição do clima',
    city: 'Localização',
    humidity: 'Umidade relativa do ar',
    windSpeed: 'Velocidade do vento',
    visibility: 'Visibilidade',
  },
};

/**
 * PLUGIN FIGMA - Código de Exemplo:
 * 
 * Para criar este componente automaticamente no Figma via plugin:
 */
export const FIGMA_PLUGIN_CODE = `
// Figma Plugin Code (JavaScript)

async function createWeatherPanel() {
  const frame = figma.createFrame();
  frame.name = "WeatherPanel";
  frame.layoutMode = "VERTICAL";
  frame.primaryAxisSizingMode = "AUTO";
  frame.counterAxisSizingMode = "FIXED";
  frame.resize(600, 280);
  frame.paddingTop = 24;
  frame.paddingRight = 24;
  frame.paddingBottom = 24;
  frame.paddingLeft = 24;
  frame.itemSpacing = 16;
  
  // Configurar fundo
  frame.fills = [{
    type: "SOLID",
    color: { r: 1, g: 1, b: 1 },
    opacity: 0.8
  }];
  
  // Configurar backdrop blur
  frame.effects = [{
    type: "BACKGROUND_BLUR",
    visible: true,
    radius: 8
  }, {
    type: "DROP_SHADOW",
    visible: true,
    offset: { x: 0, y: 4 },
    radius: 6,
    color: { r: 0, g: 0, b: 0, a: 0.1 }
  }];
  
  // Arredondar bordas
  frame.cornerRadius = 24;
  
  // Carregar fonte
  await figma.loadFontAsync({ family: "Poppins", style: "SemiBold" });
  await figma.loadFontAsync({ family: "Poppins", style: "Regular" });
  
  // Criar texto de temperatura
  const tempText = figma.createText();
  tempText.name = "temp_text";
  tempText.characters = "24°";
  tempText.fontSize = 56;
  tempText.fontName = { family: "Poppins", style: "SemiBold" };
  tempText.fills = [{ type: "SOLID", color: { r: 0.145, g: 0.388, b: 0.922 } }];
  
  frame.appendChild(tempText);
  
  // Retornar para seleção
  figma.currentPage.selection = [frame];
  figma.viewport.scrollAndZoomIntoView([frame]);
  
  figma.closePlugin("Weather Panel criado com sucesso! ✅");
}

createWeatherPanel();
`;

/**
 * EXPORTAÇÃO PARA CÓDIGO REACT (Figma → Code):
 */
export const WeatherPanelExport: React.FC<WeatherPanelExportProps> = ({
  temp,
  condition,
  city,
  humidity,
  windSpeed,
  visibility,
  icon,
}) => {
  return (
    <div
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        backdropFilter: 'blur(8px)',
        borderRadius: '24px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        padding: '24px',
        width: '100%',
        maxWidth: '600px',
        minWidth: '320px',
        fontFamily: 'Poppins, sans-serif',
      }}
    >
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div>
          <div id="city_text" style={{ fontSize: '18px', fontWeight: 600, color: '#1F2937' }}>
            {city}
          </div>
          <div style={{ fontSize: '14px', color: '#6B7280' }}>
            {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}
          </div>
        </div>
        <div id="weather_icon" style={{ fontSize: '48px' }}>
          {WEATHER_ICONS[icon]}
        </div>
      </div>

      {/* Temperature */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginBottom: '8px' }}>
          <span id="temp_text" style={{ fontSize: '56px', fontWeight: 600, color: '#2563EB' }}>
            {temp}°
          </span>
          <span style={{ fontSize: '24px', color: '#6B7280' }}>C</span>
        </div>
        <div id="condition_text" style={{ fontSize: '16px', fontWeight: 500, color: '#374151' }}>
          {condition}
        </div>
      </div>

      {/* Details */}
      {(humidity || windSpeed || visibility) && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px', paddingTop: '16px', borderTop: '1px solid #E5E7EB' }}>
          {humidity && (
            <div style={{ textAlign: 'center' }}>
              <div id="humidity_text" style={{ fontSize: '16px', fontWeight: 600, color: '#1F2937' }}>
                {humidity}%
              </div>
              <div style={{ fontSize: '12px', color: '#6B7280' }}>Umidade</div>
            </div>
          )}
          {windSpeed && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '16px', fontWeight: 600, color: '#1F2937' }}>
                {windSpeed} km/h
              </div>
              <div style={{ fontSize: '12px', color: '#6B7280' }}>Vento</div>
            </div>
          )}
          {visibility && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '16px', fontWeight: 600, color: '#1F2937' }}>
                {visibility} km
              </div>
              <div style={{ fontSize: '12px', color: '#6B7280' }}>Visibilidade</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default WeatherPanelExport;
