import { useState } from "react";
import { ArrowLeft, Check, Lock, CreditCard, FileText, AlertCircle, Shield, Mail, Phone, Calendar, Clock, HelpCircle } from "lucide-react";
import { toast } from "sonner@2.0.3";
import Header from "./Header";

interface PaymentPageProps {
  selectedCountry: string;
  selectedServices: any[];
  onBack: () => void;
  onLogout: () => void;
  userEmail: string;
  onPaymentSuccess?: (transactionId: string) => void;
}

interface Service {
  id: string;
  title: string;
  price: number;
  familyPackage?: boolean;
  membersCount?: number;
}

export default function PaymentPage({ 
  selectedCountry, 
  selectedServices, 
  onBack, 
  onLogout, 
  userEmail,
  onPaymentSuccess
}: PaymentPageProps) {
  const [paymentMethod, setPaymentMethod] = useState<"card" | "boleto">("card");
  const [useProfileData, setUseProfileData] = useState(true);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Dados do requerente
  const [requesterData, setRequesterData] = useState({
    fullName: "João da Silva",
    cpf: "123.456.789-00",
    email: userEmail,
    phone: "(61) 98765-4321",
    zipCode: "70000-000",
    address: "SQN 123 Bloco A",
    number: "123",
    complement: "Apto 456",
    neighborhood: "Asa Norte",
    city: "Brasília",
    state: "DF"
  });

  // Dados do cartão
  const [cardData, setCardData] = useState({
    number: "",
    name: "",
    expiry: "",
    cvv: "",
    cpf: "",
    installments: "1"
  });

  // Dados do boleto
  const [boletoData, setBoletoData] = useState({
    cpf: ""
  });

  // Máscaras
  const formatCPF = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})/, "$1-$2")
      .replace(/(-\d{2})\d+?$/, "$1");
  };

  const formatPhone = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{4})\d+?$/, "$1");
  };

  const formatCardNumber = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})(\d)/, "$1 $2")
      .replace(/(\d{4})\d+?$/, "$1");
  };

  const formatExpiry = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{2})(\d)/, "$1/$2")
      .replace(/(\/\d{2})\d+?$/, "$1");
  };

  const formatZipCode = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{3})\d+?$/, "$1");
  };

  // Cálculos
  const servicesTotal = 3000; // Placeholder - calcular com base nos serviços reais
  const operationalCosts = 250;
  const estimatedFees = 360;
  const totalAmount = servicesTotal + operationalCosts;

  const handlePayment = async () => {
    // Validações
    if (!acceptTerms) {
      toast.error("Você precisa aceitar os termos para continuar");
      return;
    }

    if (paymentMethod === "card") {
      if (!cardData.number || !cardData.name || !cardData.expiry || !cardData.cvv || !cardData.cpf) {
        toast.error("Preencha todos os dados do cartão");
        return;
      }
    } else {
      if (!boletoData.cpf) {
        toast.error("Preencha o CPF do pagador");
        return;
      }
    }

    setIsProcessing(true);

    // Simulação de processamento
    setTimeout(() => {
      setIsProcessing(false);
      toast.success("Pagamento processado com sucesso!");
      
      // TODO: Integração com gateway de pagamento
      console.log("Processando pagamento:", {
        method: paymentMethod,
        amount: totalAmount,
        requester: requesterData,
        payment: paymentMethod === "card" ? cardData : boletoData
      });

      // Simulação de ID de transação
      const transactionId = "TX123456789";
      if (onPaymentSuccess) {
        onPaymentSuccess(transactionId);
      }
    }, 2000);
  };

  const getInitials = (email: string) => {
    return email.substring(0, 2).toUpperCase();
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--color-background-light)" }}>
      {/* Header */}
      <Header
        isLoggedIn={true}
        userEmail={userEmail}
        onNavigateToLogin={onLogout}
        onNavigateToHome={onBack}
      />

      {/* Breadcrumb Progress - Passo 3 ativo */}
      <div className="bg-white border-b" style={{ borderColor: "var(--color-border)" }}>
        <div className="mx-auto px-4" 
          style={{ 
            maxWidth: "1024px",
            paddingTop: "var(--space-md)",
            paddingBottom: "var(--space-md)"
          }}>
          <div className="flex items-center justify-between">
            {/* Step 1 - Completed */}
            <div className="flex items-center gap-3 flex-1" key="step-1">
              <div className="rounded-full flex items-center justify-center text-white" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "var(--color-brand-green)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                <Check size={20} />
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "var(--color-brand-green)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  País
                </div>
                <div style={{ fontSize: "12px", color: "var(--color-text-muted)", fontFamily: "Inter, sans-serif" }}>
                  Concluído
                </div>
              </div>
            </div>

            {/* Connector */}
            <div className="flex-1 mx-4" style={{ height: "2px", backgroundColor: "var(--color-brand-green)" }} key="connector-1"></div>

            {/* Step 2 - Completed */}
            <div className="flex items-center gap-3 flex-1" key="step-2">
              <div className="rounded-full flex items-center justify-center text-white" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "var(--color-brand-green)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                <Check size={20} />
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "var(--color-brand-green)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  Serviços
                </div>
                <div style={{ fontSize: "12px", color: "var(--color-text-muted)", fontFamily: "Inter, sans-serif" }}>
                  Concluído
                </div>
              </div>
            </div>

            {/* Connector */}
            <div className="flex-1 mx-4" style={{ height: "2px", backgroundColor: "var(--color-brand-blue)" }} key="connector-2"></div>

            {/* Step 3 - Active */}
            <div className="flex items-center gap-3 flex-1" key="step-3">
              <div className="rounded-full flex items-center justify-center text-white" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "var(--color-brand-blue)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                3
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "var(--color-brand-blue)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  Pagamento
                </div>
                <div style={{ fontSize: "12px", color: "var(--color-text-muted)", fontFamily: "Inter, sans-serif" }}>
                  Finalize a compra
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="mx-auto px-4" 
        style={{ 
          maxWidth: "var(--container-desktop)",
          paddingTop: "var(--space-md)",
          paddingBottom: "var(--space-lg)",
          paddingLeft: "var(--grid-margin-mobile)",
          paddingRight: "var(--grid-margin-mobile)"
        }}>
        
        {/* Botão Voltar */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 mb-6 text-gray-700 hover:text-gray-900 transition-colors"
          style={{ fontFamily: "Inter, sans-serif", fontWeight: 500 }}
        >
          <ArrowLeft size={20} />
          Voltar
        </button>

        {/* Layout 2 Colunas */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* COLUNA ESQUERDA - 60% (3 colunas de 5) */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* Seção 1: Resumo do Pedido */}
            <div className="bg-white rounded-lg p-6 border"
              style={{ 
                borderColor: "var(--color-border)",
                borderRadius: "var(--radius-md)",
                boxShadow: "var(--shadow-card)"
              }}>
              <h2 style={{ 
                fontFamily: "Poppins, sans-serif",
                fontWeight: 700,
                fontSize: "20px",
                color: "var(--color-text-primary)",
                marginBottom: "var(--space-md)"
              }}>
                Resumo do Pedido
              </h2>

              <div className="space-y-3 mb-4 pb-4 border-b" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex justify-between items-start">
                  <div>
                    <div style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "var(--color-text-primary)",
                      fontWeight: 600
                    }}>
                      VISTO EUA CHANCELADO - RENOVAÇÃO
                    </div>
                    <div style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      color: "var(--color-text-muted)",
                      marginTop: "4px"
                    }}>
                      Pacote Familiar: 1 + 2 membros
                    </div>
                  </div>
                  <div style={{ 
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 600,
                    fontSize: "16px",
                    color: "var(--color-text-primary)"
                  }}>
                    R$ 2.400
                  </div>
                </div>

                <div className="flex justify-between items-start">
                  <div>
                    <div style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "var(--color-text-primary)",
                      fontWeight: 600
                    }}>
                      VISTO ELETRÔNICO (ESTA) - EUA
                    </div>
                  </div>
                  <div style={{ 
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 600,
                    fontSize: "16px",
                    color: "var(--color-text-primary)"
                  }}>
                    R$ 100
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <div style={{ 
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700,
                  fontSize: "18px",
                  color: "var(--color-text-primary)"
                }}>
                  Subtotal
                </div>
                <div style={{ 
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700,
                  fontSize: "20px",
                  color: "var(--color-brand-blue)"
                }}>
                  R$ {servicesTotal.toLocaleString('pt-BR')}
                </div>
              </div>
            </div>

            {/* Seção 2: Dados do Requerente */}
            <div className="bg-white rounded-lg p-6 border"
              style={{ 
                borderColor: "var(--color-border)",
                borderRadius: "var(--radius-md)",
                boxShadow: "var(--shadow-card)"
              }}>
              <div className="flex items-center justify-between mb-6">
                <h2 style={{ 
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700,
                  fontSize: "20px",
                  color: "var(--color-text-primary)"
                }}>
                  Dados do Requerente
                </h2>

                {/* Toggle usar dados do perfil */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setUseProfileData(!useProfileData)}
                    className="relative inline-flex h-6 w-11 items-center rounded-full transition-colors"
                    style={{ 
                      backgroundColor: useProfileData ? "var(--color-brand-blue)" : "#D1D5DB"
                    }}
                  >
                    <span
                      className="inline-block h-4 w-4 transform rounded-full bg-white transition-transform"
                      style={{ 
                        transform: useProfileData ? "translateX(1.5rem)" : "translateX(0.25rem)"
                      }}
                    />
                  </button>
                  <span style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-secondary)"
                  }}>
                    Usar dados do perfil
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Nome Completo */}
                <div className="md:col-span-2">
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    value={requesterData.fullName}
                    onChange={(e) => setRequesterData({ ...requesterData, fullName: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* CPF */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    CPF *
                  </label>
                  <input
                    type="text"
                    value={requesterData.cpf}
                    onChange={(e) => setRequesterData({ ...requesterData, cpf: formatCPF(e.target.value) })}
                    disabled={useProfileData}
                    maxLength={14}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Email */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Email *
                  </label>
                  <input
                    type="email"
                    value={requesterData.email}
                    onChange={(e) => setRequesterData({ ...requesterData, email: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Telefone */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Telefone *
                  </label>
                  <input
                    type="text"
                    value={requesterData.phone}
                    onChange={(e) => setRequesterData({ ...requesterData, phone: formatPhone(e.target.value) })}
                    disabled={useProfileData}
                    maxLength={15}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* CEP */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    CEP
                  </label>
                  <input
                    type="text"
                    value={requesterData.zipCode}
                    onChange={(e) => setRequesterData({ ...requesterData, zipCode: formatZipCode(e.target.value) })}
                    disabled={useProfileData}
                    maxLength={9}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Endereço */}
                <div className="md:col-span-2">
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Endereço
                  </label>
                  <input
                    type="text"
                    value={requesterData.address}
                    onChange={(e) => setRequesterData({ ...requesterData, address: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Número */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Número
                  </label>
                  <input
                    type="text"
                    value={requesterData.number}
                    onChange={(e) => setRequesterData({ ...requesterData, number: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Complemento */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Complemento
                  </label>
                  <input
                    type="text"
                    value={requesterData.complement}
                    onChange={(e) => setRequesterData({ ...requesterData, complement: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Bairro */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Bairro
                  </label>
                  <input
                    type="text"
                    value={requesterData.neighborhood}
                    onChange={(e) => setRequesterData({ ...requesterData, neighborhood: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Cidade */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Cidade
                  </label>
                  <input
                    type="text"
                    value={requesterData.city}
                    onChange={(e) => setRequesterData({ ...requesterData, city: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  />
                </div>

                {/* Estado */}
                <div>
                  <label style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-primary)",
                    fontWeight: 600,
                    display: "block",
                    marginBottom: "8px"
                  }}>
                    Estado
                  </label>
                  <select
                    value={requesterData.state}
                    onChange={(e) => setRequesterData({ ...requesterData, state: e.target.value })}
                    disabled={useProfileData}
                    className="w-full px-4 py-2 border rounded-lg"
                    style={{ 
                      borderColor: "var(--color-border)",
                      borderRadius: "var(--radius-sm)",
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      backgroundColor: useProfileData ? "#F9FAFB" : "white"
                    }}
                  >
                    <option value="DF">DF</option>
                    <option value="SP">SP</option>
                    <option value="RJ">RJ</option>
                    <option value="MG">MG</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Seção 3: Método de Pagamento */}
            <div className="bg-white rounded-lg p-6 border"
              style={{ 
                borderColor: "var(--color-border)",
                borderRadius: "var(--radius-md)",
                boxShadow: "var(--shadow-card)"
              }}>
              <h2 style={{ 
                fontFamily: "Poppins, sans-serif",
                fontWeight: 700,
                fontSize: "20px",
                color: "var(--color-text-primary)",
                marginBottom: "var(--space-md)"
              }}>
                Método de Pagamento
              </h2>

              {/* Tabs */}
              <div className="flex gap-4 mb-6">
                <button
                  onClick={() => setPaymentMethod("card")}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 border-2 rounded-lg transition-all"
                  style={{ 
                    borderColor: paymentMethod === "card" ? "var(--color-brand-blue)" : "var(--color-border)",
                    backgroundColor: paymentMethod === "card" ? "#EFF6FF" : "white",
                    borderRadius: "var(--radius-sm)",
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 600,
                    color: paymentMethod === "card" ? "var(--color-brand-blue)" : "var(--color-text-secondary)"
                  }}
                >
                  <CreditCard size={20} />
                  Cartão de Crédito
                </button>

                <button
                  onClick={() => setPaymentMethod("boleto")}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 border-2 rounded-lg transition-all"
                  style={{ 
                    borderColor: paymentMethod === "boleto" ? "var(--color-brand-blue)" : "var(--color-border)",
                    backgroundColor: paymentMethod === "boleto" ? "#EFF6FF" : "white",
                    borderRadius: "var(--radius-sm)",
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 600,
                    color: paymentMethod === "boleto" ? "var(--color-brand-blue)" : "var(--color-text-secondary)"
                  }}
                >
                  <FileText size={20} />
                  Boleto Bancário
                </button>
              </div>

              {/* Formulário Cartão */}
              {paymentMethod === "card" && (
                <div className="space-y-4">
                  {/* Número do Cartão */}
                  <div>
                    <label style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "var(--color-text-primary)",
                      fontWeight: 600,
                      display: "block",
                      marginBottom: "8px"
                    }}>
                      Número do Cartão *
                    </label>
                    <input
                      type="text"
                      value={cardData.number}
                      onChange={(e) => setCardData({ ...cardData, number: formatCardNumber(e.target.value) })}
                      placeholder="0000 0000 0000 0000"
                      maxLength={19}
                      className="w-full px-4 py-2 border rounded-lg"
                      style={{ 
                        borderColor: "var(--color-border)",
                        borderRadius: "var(--radius-sm)",
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px"
                      }}
                    />
                  </div>

                  {/* Nome no Cartão */}
                  <div>
                    <label style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "var(--color-text-primary)",
                      fontWeight: 600,
                      display: "block",
                      marginBottom: "8px"
                    }}>
                      Nome no Cartão *
                    </label>
                    <input
                      type="text"
                      value={cardData.name}
                      onChange={(e) => setCardData({ ...cardData, name: e.target.value.toUpperCase() })}
                      placeholder="NOME COMPLETO"
                      className="w-full px-4 py-2 border rounded-lg"
                      style={{ 
                        borderColor: "var(--color-border)",
                        borderRadius: "var(--radius-sm)",
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px"
                      }}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    {/* Validade */}
                    <div>
                      <label style={{ 
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px",
                        color: "var(--color-text-primary)",
                        fontWeight: 600,
                        display: "block",
                        marginBottom: "8px"
                      }}>
                        Validade *
                      </label>
                      <input
                        type="text"
                        value={cardData.expiry}
                        onChange={(e) => setCardData({ ...cardData, expiry: formatExpiry(e.target.value) })}
                        placeholder="MM/AA"
                        maxLength={5}
                        className="w-full px-4 py-2 border rounded-lg"
                        style={{ 
                          borderColor: "var(--color-border)",
                          borderRadius: "var(--radius-sm)",
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px"
                        }}
                      />
                    </div>

                    {/* CVV */}
                    <div>
                      <label style={{ 
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px",
                        color: "var(--color-text-primary)",
                        fontWeight: 600,
                        display: "block",
                        marginBottom: "8px"
                      }}>
                        CVV *
                      </label>
                      <input
                        type="text"
                        value={cardData.cvv}
                        onChange={(e) => setCardData({ ...cardData, cvv: e.target.value.replace(/\D/g, "") })}
                        placeholder="123"
                        maxLength={4}
                        className="w-full px-4 py-2 border rounded-lg"
                        style={{ 
                          borderColor: "var(--color-border)",
                          borderRadius: "var(--radius-sm)",
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px"
                        }}
                      />
                    </div>

                    {/* CPF do Titular */}
                    <div>
                      <label style={{ 
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px",
                        color: "var(--color-text-primary)",
                        fontWeight: 600,
                        display: "block",
                        marginBottom: "8px"
                      }}>
                        CPF *
                      </label>
                      <input
                        type="text"
                        value={cardData.cpf}
                        onChange={(e) => setCardData({ ...cardData, cpf: formatCPF(e.target.value) })}
                        placeholder="000.000.000-00"
                        maxLength={14}
                        className="w-full px-4 py-2 border rounded-lg"
                        style={{ 
                          borderColor: "var(--color-border)",
                          borderRadius: "var(--radius-sm)",
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px"
                        }}
                      />
                    </div>
                  </div>

                  {/* Parcelamento */}
                  <div>
                    <label style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "var(--color-text-primary)",
                      fontWeight: 600,
                      display: "block",
                      marginBottom: "8px"
                    }}>
                      Parcelamento
                    </label>
                    <select
                      value={cardData.installments}
                      onChange={(e) => setCardData({ ...cardData, installments: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg"
                      style={{ 
                        borderColor: "var(--color-border)",
                        borderRadius: "var(--radius-sm)",
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px"
                      }}
                    >
                      <option value="1">1x de R$ {totalAmount.toLocaleString('pt-BR')} sem juros</option>
                      <option value="2">2x de R$ {(totalAmount / 2).toLocaleString('pt-BR')} sem juros</option>
                      <option value="3">3x de R$ {(totalAmount / 3).toFixed(2)} sem juros</option>
                      <option value="4">4x de R$ {(totalAmount / 4).toFixed(2)} sem juros</option>
                      <option value="5">5x de R$ {(totalAmount / 5).toFixed(2)} sem juros</option>
                      <option value="6">6x de R$ {(totalAmount / 6).toFixed(2)} sem juros</option>
                    </select>
                  </div>

                  {/* Bandeiras */}
                  <div className="flex items-center gap-3 pt-4">
                    <span style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      color: "var(--color-text-muted)"
                    }}>
                      Bandeiras aceitas:
                    </span>
                    <div className="flex gap-2">
                      {["VISA", "MASTER", "ELO", "AMEX"].map(brand => (
                        <div key={brand} className="px-3 py-1 border rounded"
                          style={{ 
                            borderColor: "var(--color-border)",
                            fontFamily: "Poppins, sans-serif",
                            fontSize: "10px",
                            fontWeight: 700,
                            color: "var(--color-text-muted)"
                          }}>
                          {brand}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Formulário Boleto */}
              {paymentMethod === "boleto" && (
                <div className="space-y-4">
                  {/* Info Alert */}
                  <div className="p-4 rounded-lg" 
                    style={{ 
                      backgroundColor: "#FEF3C7",
                      borderRadius: "var(--radius-sm)"
                    }}>
                    <div className="flex items-start gap-3">
                      <AlertCircle size={20} style={{ color: "#F59E0B", marginTop: "2px" }} />
                      <div>
                        <div style={{ 
                          fontFamily: "Poppins, sans-serif",
                          fontWeight: 600,
                          fontSize: "14px",
                          color: "#D97706",
                          marginBottom: "4px"
                        }}>
                          Pagamento confirmado em até 2 dias úteis
                        </div>
                        <div style={{ 
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px",
                          color: "#92400E"
                        }}>
                          Você receberá o boleto por email e poderá baixar após finalizar o pedido.
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* CPF do Pagador */}
                  <div>
                    <label style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "var(--color-text-primary)",
                      fontWeight: 600,
                      display: "block",
                      marginBottom: "8px"
                    }}>
                      CPF do Pagador *
                    </label>
                    <input
                      type="text"
                      value={boletoData.cpf}
                      onChange={(e) => setBoletoData({ ...boletoData, cpf: formatCPF(e.target.value) })}
                      placeholder="000.000.000-00"
                      maxLength={14}
                      className="w-full px-4 py-2 border rounded-lg"
                      style={{ 
                        borderColor: "var(--color-border)",
                        borderRadius: "var(--radius-sm)",
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px"
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Seção 4: Termos e Condições */}
            <div className="bg-white rounded-lg p-6 border"
              style={{ 
                borderColor: "var(--color-border)",
                borderRadius: "var(--radius-md)",
                boxShadow: "var(--shadow-card)"
              }}>
              <div className="flex items-start gap-3">
                <div 
                  onClick={() => setAcceptTerms(!acceptTerms)}
                  className="cursor-pointer mt-1"
                  style={{ 
                    width: "24px", 
                    height: "24px",
                    minWidth: "24px",
                    borderRadius: "6px",
                    border: `2px solid ${acceptTerms ? 'var(--color-brand-blue)' : '#D1D5DB'}`,
                    backgroundColor: acceptTerms ? 'var(--color-brand-blue)' : 'white',
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.2s"
                  }}
                >
                  {acceptTerms && (
                    <Check size={16} className="text-white" />
                  )}
                </div>
                
                <div style={{ 
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "var(--color-text-secondary)"
                }}>
                  Li e aceito os{" "}
                  <a href="#" style={{ color: "var(--color-brand-blue)", textDecoration: "underline" }}>
                    termos de serviço
                  </a>
                  {" "}e a{" "}
                  <a href="#" style={{ color: "var(--color-brand-blue)", textDecoration: "underline" }}>
                    política de privacidade
                  </a>
                  {" "}*
                </div>
              </div>
            </div>
          </div>

          {/* COLUNA DIREITA - 40% (2 colunas de 5) */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg p-6 border sticky top-24"
              style={{ 
                borderColor: "var(--color-border)",
                borderRadius: "var(--radius-md)",
                boxShadow: "var(--shadow-card)"
              }}>
              
              {/* Selo de Segurança */}
              <div className="flex items-center gap-3 mb-6 p-4 rounded-lg" 
                style={{ 
                  backgroundColor: "#DCFCE7",
                  borderRadius: "var(--radius-sm)"
                }}>
                <Shield size={24} style={{ color: "var(--color-brand-green)" }} />
                <div>
                  <div style={{ 
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 700,
                    fontSize: "16px",
                    color: "var(--color-brand-green)"
                  }}>
                    Pagamento 100% Seguro
                  </div>
                  <div style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "12px",
                    color: "#065F46"
                  }}>
                    SSL • Criptografia de ponta
                  </div>
                </div>
              </div>

              {/* Resumo Financeiro */}
              <h3 style={{ 
                fontFamily: "Poppins, sans-serif",
                fontWeight: 700,
                fontSize: "18px",
                color: "var(--color-text-primary)",
                marginBottom: "var(--space-md)"
              }}>
                Resumo Financeiro
              </h3>

              <div className="space-y-3 mb-6 pb-6 border-b" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex justify-between items-center">
                  <span style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-secondary)"
                  }}>
                    Serviços
                  </span>
                  <span style={{ 
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 600,
                    fontSize: "16px",
                    color: "var(--color-text-primary)"
                  }}>
                    R$ {servicesTotal.toLocaleString('pt-BR')}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-secondary)"
                  }}>
                    Custos operacionais
                  </span>
                  <span style={{ 
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 600,
                    fontSize: "16px",
                    color: "var(--color-text-primary)"
                  }}>
                    R$ {operationalCosts.toLocaleString('pt-BR')}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <span style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "var(--color-text-secondary)"
                    }}>
                      Taxas estimadas
                    </span>
                    <HelpCircle size={14} style={{ color: "var(--color-text-muted)" }} />
                  </div>
                  <span style={{ 
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 600,
                    fontSize: "16px",
                    color: "#F59E0B"
                  }}>
                    ~R$ {estimatedFees.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>

              {/* Total */}
              <div className="flex justify-between items-center mb-6">
                <div style={{ 
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700,
                  fontSize: "20px",
                  color: "var(--color-text-primary)"
                }}>
                  TOTAL
                </div>
                <div style={{ 
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700,
                  fontSize: "32px",
                  color: "var(--color-brand-blue)"
                }}>
                  R$ {totalAmount.toLocaleString('pt-BR')}
                </div>
              </div>

              {/* Informações Importantes */}
              <div className="space-y-3 mb-6 p-4 rounded-lg" 
                style={{ 
                  backgroundColor: "#F9FAFB",
                  borderRadius: "var(--radius-sm)"
                }}>
                <div style={{ 
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600,
                  fontSize: "14px",
                  color: "var(--color-text-primary)",
                  marginBottom: "8px"
                }}>
                  Informações Importantes:
                </div>

                <div className="flex items-start gap-2">
                  <Calendar size={16} style={{ color: "var(--color-text-secondary)", marginTop: "2px" }} />
                  <span style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "12px",
                    color: "var(--color-text-secondary)"
                  }}>
                    Prazo de processamento: 5-7 dias úteis
                  </span>
                </div>

                <div className="flex items-start gap-2">
                  <Mail size={16} style={{ color: "var(--color-text-secondary)", marginTop: "2px" }} />
                  <span style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "12px",
                    color: "var(--color-text-secondary)"
                  }}>
                    Confirmação enviada por email
                  </span>
                </div>

                <div className="flex items-start gap-2">
                  <Lock size={16} style={{ color: "var(--color-text-secondary)", marginTop: "2px" }} />
                  <span style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "12px",
                    color: "var(--color-text-secondary)"
                  }}>
                    Dados protegidos com criptografia
                  </span>
                </div>

                <div className="flex items-start gap-2">
                  <Phone size={16} style={{ color: "var(--color-text-secondary)", marginTop: "2px" }} />
                  <span style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "12px",
                    color: "var(--color-text-secondary)"
                  }}>
                    Suporte: (61) 3456-7890
                  </span>
                </div>
              </div>

              {/* Botão Finalizar */}
              <button
                onClick={handlePayment}
                disabled={isProcessing}
                className="w-full flex items-center justify-center gap-2 px-8 py-4 rounded-lg transition-all"
                style={{ 
                  backgroundColor: isProcessing ? "#D1D5DB" : "var(--color-brand-blue)",
                  color: "white",
                  cursor: isProcessing ? "not-allowed" : "pointer",
                  borderRadius: "var(--radius-sm)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700,
                  fontSize: "16px",
                  boxShadow: isProcessing ? "none" : "var(--shadow-button)"
                }}
              >
                {isProcessing ? (
                  <>
                    <Clock size={20} className="animate-spin" />
                    Processando...
                  </>
                ) : (
                  <>
                    <Lock size={20} />
                    Finalizar Pagamento
                  </>
                )}
              </button>

              <div style={{ 
                fontFamily: "Inter, sans-serif",
                fontSize: "11px",
                color: "var(--color-text-muted)",
                textAlign: "center",
                marginTop: "12px"
              }}>
                Ao finalizar, você concorda com nossos termos
              </div>
            </div>
          </div>
        </div>

        {/* Botão Voltar (mobile) */}
        <div className="mt-8 pt-8 border-t lg:hidden" style={{ borderColor: "var(--color-border)" }}>
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-6 py-3 border-2 rounded-lg hover:bg-gray-50 transition-colors"
            style={{ 
              borderColor: "#D1D5DB",
              color: "var(--color-text-secondary)",
              borderRadius: "var(--radius-sm)",
              fontFamily: "Poppins, sans-serif",
              fontWeight: 600
            }}
          >
            <ArrowLeft size={20} />
            Voltar
          </button>
        </div>
      </main>
    </div>
  );
}