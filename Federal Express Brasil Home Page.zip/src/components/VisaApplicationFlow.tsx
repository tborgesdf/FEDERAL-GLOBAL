import { useState, useEffect } from "react";
import { CheckCircle } from "lucide-react";
import Header from "./Header";
import Hero from "./Hero";
import ProgressStepper from "./visa/ProgressStepper";
import StepMaritalStatus from "./visa/StepMaritalStatus";
import StepSocialMedia from "./visa/StepSocialMedia";
import StepPassport from "./visa/StepPassport";
import StepPreviousVisa from "./visa/StepPreviousVisa";
import StepBrazilianDocument from "./visa/StepBrazilianDocument";
import StepMarriageCertificate from "./visa/StepMarriageCertificate";
import StepSelfie from "./visa/StepSelfie";
import StepQuestionnaire from "./visa/StepQuestionnaire";

interface VisaApplicationFlowProps {
  flowType: "first-visa" | "renewal";
  paymentTransactionId: string;
  userEmail: string;
  onLogout: () => void;
  onNavigateToHome: () => void;
  onComplete: () => void;
}

export default function VisaApplicationFlow({
  flowType,
  paymentTransactionId,
  userEmail,
  onLogout,
  onNavigateToHome,
  onComplete
}: VisaApplicationFlowProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [formData, setFormData] = useState<any>({});

  // Define steps based on flow type
  const getSteps = () => {
    const baseSteps = [
      { id: "marital-status", label: "Estado civil" },
      { id: "social-media", label: "Redes sociais" },
      { id: "passport", label: "Passaporte" }
    ];

    const renewalStep = flowType === "renewal" 
      ? [{ id: "previous-visa", label: "Visto anterior" }]
      : [];

    const documentSteps = [
      { id: "brazilian-document", label: "Documento" }
    ];

    // Add marriage/union certificate step if married or stable union
    const marriageStep = (formData.maritalStatus === "married" || formData.maritalStatus === "stable-union")
      ? [{ id: "marriage-certificate", label: formData.maritalStatus === "married" ? "Certidão" : "Declaração", optional: true }]
      : [];

    const finalSteps = [
      { id: "selfie", label: "Selfie" },
      { id: "questionnaire", label: "Questionário" }
    ];

    return [
      ...baseSteps,
      ...renewalStep,
      ...documentSteps,
      ...marriageStep,
      ...finalSteps
    ];
  };

  const steps = getSteps();

  const handleNext = (data?: any) => {
    if (data) {
      setFormData({ ...formData, ...data });
    }

    setCompletedSteps([...completedSteps, currentStep]);
    
    // Check if we need to add marriage certificate step
    if (steps[currentStep].id === "marital-status" && data?.maritalStatus && 
        (data.maritalStatus === "married" || data.maritalStatus === "stable-union") && 
        formData.maritalStatus !== data.maritalStatus) {
      // Force re-render to add marriage/union step
      setFormData({ ...formData, ...data });
    }
    
    setCurrentStep(currentStep + 1);
  };

  const renderCurrentStep = () => {
    const stepId = steps[currentStep]?.id;

    switch (stepId) {
      case "marital-status":
        return <StepMaritalStatus onNext={(maritalStatus) => handleNext({ maritalStatus })} />;
      
      case "social-media":
        return <StepSocialMedia onNext={(hasSocial, platforms) => handleNext({ hasSocial, socialPlatforms: platforms })} />;
      
      case "passport":
        return <StepPassport onNext={(data) => handleNext({ passportData: data })} />;
      
      case "previous-visa":
        return <StepPreviousVisa onNext={(data) => handleNext({ previousVisaData: data })} />;
      
      case "brazilian-document":
        return <StepBrazilianDocument onNext={(data) => handleNext({ documentData: data })} />;
      
      case "marriage-certificate":
        return <StepMarriageCertificate onNext={(data) => handleNext({ marriageCertificateData: data })} />;
      
      case "selfie":
        return <StepSelfie onNext={(data) => handleNext({ selfieData: data })} />;
      
      case "questionnaire":
        return <StepQuestionnaire onComplete={onComplete} />;
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        userEmail={userEmail}
        isLoggedIn={true}
        onLogout={onLogout}
        onNavigateToHome={onNavigateToHome}
        onNavigateToRegister={() => {}}
        onNavigateToLogin={() => {}}
        currentPage="visa-application"
      />

      <Hero />

      <ProgressStepper
        steps={steps}
        currentStep={currentStep}
        completedSteps={completedSteps}
      />

      {/* Payment Confirmation Banner */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
            <CheckCircle className="w-5 h-5 text-[#2BA84A] flex-shrink-0" />
            <div className="flex-1">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#166534",
                  fontWeight: 600
                }}
              >
                Pagamento confirmado
              </p>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#166534"
                }}
              >
                Transação #{paymentTransactionId} • {flowType === "first-visa" ? "Primeiro Visto" : "Renovação de Visto"}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderCurrentStep()}
      </main>

      {/* Footer Spacer */}
      <div className="h-16" />
    </div>
  );
}