import { useState } from "react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";

interface AddressData {
  logradouro: string;
  bairro: string;
  localidade: string;
  uf: string;
}

export default function NewAccountForm({ onSuccess }: { onSuccess: () => void }) {
  const [formData, setFormData] = useState({
    cpf: "",
    fullName: "",
    email: "",
    cellPhone: "",
    homePhone: "",
    cep: "",
    street: "",
    neighborhood: "",
    city: "",
    state: "",
    number: "",
    complement: "",
    password: "",
    confirmPassword: ""
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Máscaras
  const maskCPF = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d)/, "$1.$2")
      .replace(/(\d{3})(\d{1,2})/, "$1-$2")
      .replace(/(-\d{2})\d+?$/, "$1");
  };

  const maskPhone = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{4})\d+?$/, "$1");
  };

  const maskCEP = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/(\d{5})(\d)/, "$1-$2")
      .replace(/(-\d{3})\d+?$/, "$1");
  };

  // Validações
  const validateCPF = (cpf: string): boolean => {
    const cleanCPF = cpf.replace(/\D/g, "");
    if (cleanCPF.length !== 11) return false;
    
    // Verifica se todos os dígitos são iguais
    if (/^(\d)\1{10}$/.test(cleanCPF)) return false;

    // Validação do primeiro dígito verificador
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += parseInt(cleanCPF.charAt(i)) * (10 - i);
    }
    let digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cleanCPF.charAt(9))) return false;

    // Validação do segundo dígito verificador
    sum = 0;
    for (let i = 0; i < 10; i++) {
      sum += parseInt(cleanCPF.charAt(i)) * (11 - i);
    }
    digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cleanCPF.charAt(10))) return false;

    return true;
  };

  const validateEmail = (email: string): boolean => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const fetchAddressByCEP = async (cep: string) => {
    const cleanCEP = cep.replace(/\D/g, "");
    if (cleanCEP.length !== 8) return;

    setIsLoadingCep(true);
    setErrors(prev => ({ ...prev, cep: "" }));

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleanCEP}/json/`);
      const data: AddressData & { erro?: boolean } = await response.json();

      if (data.erro) {
        setErrors(prev => ({ ...prev, cep: "CEP não encontrado" }));
        return;
      }

      setFormData(prev => ({
        ...prev,
        street: data.logradouro || "",
        neighborhood: data.bairro || "",
        city: data.localidade || "",
        state: data.uf || ""
      }));

      // Focar no campo de número após preencher
      setTimeout(() => {
        document.getElementById("number")?.focus();
      }, 100);
    } catch (error) {
      setErrors(prev => ({ ...prev, cep: "Erro ao buscar CEP" }));
    } finally {
      setIsLoadingCep(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    let maskedValue = value;

    // Aplicar máscaras
    if (field === "cpf") maskedValue = maskCPF(value);
    if (field === "cellPhone" || field === "homePhone") maskedValue = maskPhone(value);
    if (field === "cep") maskedValue = maskCEP(value);

    setFormData(prev => ({ ...prev, [field]: maskedValue }));
    setErrors(prev => ({ ...prev, [field]: "" }));

    // Buscar CEP automaticamente quando completo
    if (field === "cep" && maskedValue.replace(/\D/g, "").length === 8) {
      fetchAddressByCEP(maskedValue);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!validateCPF(formData.cpf)) {
      newErrors.cpf = "CPF inválido";
    }

    if (!formData.fullName.trim()) {
      newErrors.fullName = "Nome completo é obrigatório";
    }

    if (!validateEmail(formData.email)) {
      newErrors.email = "E-mail inválido";
    }

    if (formData.cellPhone.replace(/\D/g, "").length < 10) {
      newErrors.cellPhone = "Celular inválido";
    }

    if (formData.cep.replace(/\D/g, "").length !== 8) {
      newErrors.cep = "CEP inválido";
    }

    if (!formData.number.trim()) {
      newErrors.number = "Número é obrigatório";
    }

    if (formData.password.length < 6) {
      newErrors.password = "Senha deve ter no mínimo 6 caracteres";
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Senhas não coincidem";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      // Simular chamada de API
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // TODO: Integrar com Supabase signup
      console.log("Form data:", formData);
      
      onSuccess();
    } catch (error) {
      setErrors({ submit: "Erro ao criar conta. Tente novamente." });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* CPF */}
      <div>
        <Label htmlFor="cpf">CPF *</Label>
        <Input
          id="cpf"
          value={formData.cpf}
          onChange={(e) => handleChange("cpf", e.target.value)}
          placeholder="000.000.000-00"
          maxLength={14}
          className={errors.cpf ? "border-red-500" : ""}
        />
        {errors.cpf && (
          <p className="mt-1 text-sm text-red-600">{errors.cpf}</p>
        )}
      </div>

      {/* Nome Completo */}
      <div>
        <Label htmlFor="fullName">Nome Completo *</Label>
        <Input
          id="fullName"
          value={formData.fullName}
          onChange={(e) => handleChange("fullName", e.target.value)}
          placeholder="Seu nome completo"
          className={errors.fullName ? "border-red-500" : ""}
        />
        {errors.fullName && (
          <p className="mt-1 text-sm text-red-600">{errors.fullName}</p>
        )}
      </div>

      {/* E-mail */}
      <div>
        <Label htmlFor="email">E-mail *</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => handleChange("email", e.target.value)}
          placeholder="seu@email.com"
          className={errors.email ? "border-red-500" : ""}
        />
        {errors.email && (
          <p className="mt-1 text-sm text-red-600">{errors.email}</p>
        )}
      </div>

      {/* Telefones */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="cellPhone">Celular *</Label>
          <Input
            id="cellPhone"
            value={formData.cellPhone}
            onChange={(e) => handleChange("cellPhone", e.target.value)}
            placeholder="(00) 00000-0000"
            maxLength={15}
            className={errors.cellPhone ? "border-red-500" : ""}
          />
          {errors.cellPhone && (
            <p className="mt-1 text-sm text-red-600">{errors.cellPhone}</p>
          )}
        </div>

        <div>
          <Label htmlFor="homePhone">Telefone Residencial</Label>
          <Input
            id="homePhone"
            value={formData.homePhone}
            onChange={(e) => handleChange("homePhone", e.target.value)}
            placeholder="(00) 0000-0000"
            maxLength={14}
          />
        </div>
      </div>

      {/* CEP */}
      <div>
        <Label htmlFor="cep">CEP *</Label>
        <div className="relative">
          <Input
            id="cep"
            value={formData.cep}
            onChange={(e) => handleChange("cep", e.target.value)}
            placeholder="00000-000"
            maxLength={9}
            className={errors.cep ? "border-red-500" : ""}
          />
          {isLoadingCep && (
            <Loader2 className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-[#0058CC]" />
          )}
        </div>
        {errors.cep && (
          <p className="mt-1 text-sm text-red-600">{errors.cep}</p>
        )}
      </div>

      {/* Endereço (readonly após preencher CEP) */}
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <Label htmlFor="street">Logradouro</Label>
          <Input
            id="street"
            value={formData.street}
            readOnly
            className="bg-gray-50"
          />
        </div>

        <div>
          <Label htmlFor="neighborhood">Bairro</Label>
          <Input
            id="neighborhood"
            value={formData.neighborhood}
            readOnly
            className="bg-gray-50"
          />
        </div>

        <div>
          <Label htmlFor="city">Cidade</Label>
          <Input
            id="city"
            value={formData.city}
            readOnly
            className="bg-gray-50"
          />
        </div>

        <div>
          <Label htmlFor="state">UF</Label>
          <Input
            id="state"
            value={formData.state}
            readOnly
            className="bg-gray-50"
          />
        </div>

        <div>
          <Label htmlFor="number">Número *</Label>
          <Input
            id="number"
            value={formData.number}
            onChange={(e) => handleChange("number", e.target.value)}
            placeholder="123"
            className={errors.number ? "border-red-500" : ""}
          />
          {errors.number && (
            <p className="mt-1 text-sm text-red-600">{errors.number}</p>
          )}
        </div>

        <div className="col-span-2">
          <Label htmlFor="complement">Complemento</Label>
          <Input
            id="complement"
            value={formData.complement}
            onChange={(e) => handleChange("complement", e.target.value)}
            placeholder="Apto 101, Bloco A, etc."
          />
        </div>
      </div>

      {/* Senhas */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="password">Senha *</Label>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              value={formData.password}
              onChange={(e) => handleChange("password", e.target.value)}
              placeholder="Mínimo 6 caracteres"
              className={errors.password ? "border-red-500" : ""}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4 text-gray-500" />
              ) : (
                <Eye className="h-4 w-4 text-gray-500" />
              )}
            </button>
          </div>
          {errors.password && (
            <p className="mt-1 text-sm text-red-600">{errors.password}</p>
          )}
        </div>

        <div>
          <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
          <div className="relative">
            <Input
              id="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              value={formData.confirmPassword}
              onChange={(e) => handleChange("confirmPassword", e.target.value)}
              placeholder="Repita a senha"
              className={errors.confirmPassword ? "border-red-500" : ""}
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              {showConfirmPassword ? (
                <EyeOff className="h-4 w-4 text-gray-500" />
              ) : (
                <Eye className="h-4 w-4 text-gray-500" />
              )}
            </button>
          </div>
          {errors.confirmPassword && (
            <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>
          )}
        </div>
      </div>

      {/* Erro de submissão */}
      {errors.submit && (
        <div className="rounded-lg bg-red-50 p-4">
          <p className="text-sm text-red-800">{errors.submit}</p>
        </div>
      )}

      {/* Botão submit */}
      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-[#0058CC] hover:bg-[#0A4B9E]"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Criando conta...
          </>
        ) : (
          "Criar conta"
        )}
      </Button>
    </form>
  );
}
