import { useState } from "react";
import { ChevronDown, ChevronUp, Check, AlertCircle, RefreshCw, Save, Edit3 } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { DocumentOcrConfig, OcrField, OcrSection } from "../../lib/ocr/fields";

interface OcrReviewCardProps {
  config: DocumentOcrConfig;
  imageUrl?: string;
  initialData?: Record<string, string>;
  onSave: (data: Record<string, string>) => void;
  onReprocess?: () => void;
  isProcessing?: boolean;
}

export default function OcrReviewCard({
  config,
  imageUrl,
  initialData = {},
  onSave,
  onReprocess,
  isProcessing = false
}: OcrReviewCardProps) {
  const [ocrData, setOcrData] = useState<Record<string, string>>(initialData);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(
    new Set(config.sections.filter(s => s.defaultExpanded).map(s => s.id))
  );
  const [isEditing, setIsEditing] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId);
    } else {
      newExpanded.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };

  const handleFieldChange = (key: string, value: string) => {
    setOcrData(prev => ({ ...prev, [key]: value }));
    setIsSaved(false);
  };

  const handleSave = () => {
    onSave(ocrData);
    setIsSaved(true);
    setIsEditing(false);
    
    // Reset saved state after animation
    setTimeout(() => setIsSaved(false), 2000);
  };

  const isFieldEmpty = (field: OcrField): boolean => {
    const value = ocrData[field.key];
    return !value || value.trim() === '';
  };

  const hasErrors = (): boolean => {
    return config.sections.some(section =>
      section.fields.some(field => field.required && isFieldEmpty(field))
    );
  };

  const renderField = (field: OcrField) => {
    const isEmpty = isFieldEmpty(field);
    const showWarning = isEmpty && field.required;

    return (
      <div key={field.key} className="space-y-2">
        <Label
          htmlFor={field.key}
          className="flex items-center gap-2"
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "13px",
            fontWeight: 500,
            color: showWarning ? "#DC2626" : "#374151"
          }}
        >
          {field.label}
          {field.required && <span className="text-red-500">*</span>}
          {showWarning && (
            <span className="text-xs text-amber-600">
              (Campo não reconhecido)
            </span>
          )}
        </Label>

        {field.type === 'select' ? (
          <Select
            value={ocrData[field.key] || ''}
            onValueChange={(value) => handleFieldChange(field.key, value)}
            disabled={!isEditing}
          >
            <SelectTrigger
              id={field.key}
              className={`h-11 ${showWarning ? 'border-amber-400 bg-amber-50' : ''}`}
            >
              <SelectValue placeholder={field.placeholder || 'Selecione...'} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map(option => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : field.type === 'textarea' ? (
          <Textarea
            id={field.key}
            value={ocrData[field.key] || ''}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            placeholder={field.placeholder}
            disabled={!isEditing}
            rows={2}
            className={`resize-none ${showWarning ? 'border-amber-400 bg-amber-50' : ''}`}
            style={{
              fontFamily: "monospace",
              fontSize: "12px"
            }}
          />
        ) : (
          <Input
            id={field.key}
            type={field.type}
            value={ocrData[field.key] || ''}
            onChange={(e) => handleFieldChange(field.key, e.target.value)}
            placeholder={field.placeholder}
            disabled={!isEditing}
            className={`h-11 ${showWarning ? 'border-amber-400 bg-amber-50' : ''}`}
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "14px"
            }}
          />
        )}

        {field.hint && (
          <p
            className="text-xs text-gray-500"
            style={{
              fontFamily: "Inter, sans-serif"
            }}
          >
            {field.hint}
          </p>
        )}
      </div>
    );
  };

  const renderSection = (section: OcrSection) => {
    const isExpanded = expandedSections.has(section.id);
    const isCollapsible = section.collapsible !== false;

    return (
      <div key={section.id} className="border-b border-gray-200 last:border-b-0">
        <button
          type="button"
          onClick={() => isCollapsible && toggleSection(section.id)}
          className="flex w-full items-center justify-between py-4 text-left transition-colors hover:bg-gray-50"
          disabled={!isCollapsible}
        >
          <div className="flex items-center gap-2">
            {section.icon && <span className="text-xl">{section.icon}</span>}
            <h4
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "15px",
                fontWeight: 600,
                color: "#0A4B9E"
              }}
            >
              {section.title}
            </h4>
          </div>

          {isCollapsible && (
            isExpanded ? (
              <ChevronUp className="h-5 w-5 text-gray-400" />
            ) : (
              <ChevronDown className="h-5 w-5 text-gray-400" />
            )
          )}
        </button>

        {isExpanded && (
          <div className="grid grid-cols-1 gap-4 pb-6 md:grid-cols-2">
            {section.fields.map(renderField)}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="rounded-xl border border-gray-200 bg-white shadow-sm">
      {/* Header */}
      <div className="border-b border-gray-200 bg-gradient-to-r from-blue-50 to-white p-6">
        <div className="flex items-start gap-4">
          {/* Thumbnail */}
          {imageUrl && (
            <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-lg border border-gray-200 bg-gray-100">
              <img
                src={imageUrl}
                alt="Documento"
                className="h-full w-full object-cover"
              />
            </div>
          )}

          {/* Title and Actions */}
          <div className="flex-1">
            <h3
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "18px",
                fontWeight: 600,
                color: "#0A4B9E",
                marginBottom: "12px"
              }}
            >
              {config.title}
            </h3>

            <div className="flex flex-wrap gap-2">
              {onReprocess && (
                <Button
                  type="button"
                  onClick={onReprocess}
                  disabled={isProcessing}
                  variant="outline"
                  size="sm"
                  className="border-[#0058CC] text-[#0058CC] hover:bg-[#0058CC] hover:text-white"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Reprocessar OCR
                    </>
                  )}
                </Button>
              )}

              <Button
                type="button"
                onClick={() => setIsEditing(!isEditing)}
                variant="outline"
                size="sm"
                className={isEditing ? "bg-amber-50 border-amber-500 text-amber-700" : ""}
              >
                <Edit3 className="mr-2 h-4 w-4" />
                {isEditing ? "Cancelar edição" : "Editar manualmente"}
              </Button>

              <Button
                type="button"
                onClick={handleSave}
                disabled={hasErrors()}
                size="sm"
                className={`${
                  isSaved
                    ? "bg-[#2BA84A] hover:bg-[#2BA84A]"
                    : "bg-[#0058CC] hover:bg-[#0A4B9E]"
                } transition-all`}
              >
                {isSaved ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Salvo!
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Confirmar e salvar
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Warning Banner */}
        {hasErrors() && (
          <div className="mt-4 flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3">
            <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-amber-600" />
            <div>
              <p
                style={{
                  fontFamily: "Poppins, sans-serif",
                  fontSize: "13px",
                  fontWeight: 600,
                  color: "#D97706",
                  marginBottom: "4px"
                }}
              >
                Campos obrigatórios incompletos
              </p>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "12px",
                  color: "#92400E"
                }}
              >
                Alguns campos obrigatórios não foram reconhecidos. Preencha-os manualmente.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Sections */}
      <div className="p-6">
        {config.sections.map(renderSection)}
      </div>
    </div>
  );
}
