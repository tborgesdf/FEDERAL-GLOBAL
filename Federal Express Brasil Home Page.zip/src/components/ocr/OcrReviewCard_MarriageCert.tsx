import OcrReviewCard from "./OcrReviewCard";
import { getOcrConfig } from "../../lib/ocr/fields";

interface OcrReviewCard_MarriageCertProps {
  imageUrl?: string;
  initialData?: Record<string, string>;
  onSave: (data: Record<string, string>) => void;
  onReprocess?: () => void;
  isProcessing?: boolean;
}

export default function OcrReviewCard_MarriageCert(props: OcrReviewCard_MarriageCertProps) {
  return <OcrReviewCard config={getOcrConfig('marriage')} {...props} />;
}
