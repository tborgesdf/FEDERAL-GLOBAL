import { useState } from "react";
import OcrReviewCard from "./OcrReviewCard";
import { getOcrConfig } from "../../lib/ocr/fields";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";

interface OcrReviewCard_BRIDProps {
  imageUrl?: string;
  initialData?: Record<string, string>;
  onSave: (data: Record<string, string>) => void;
  onReprocess?: () => void;
  isProcessing?: boolean;
  documentType?: 'rg' | 'cnh' | 'cin';
}

export default function OcrReviewCard_BRID({
  documentType = 'rg',
  ...props
}: OcrReviewCard_BRIDProps) {
  const [selectedType, setSelectedType] = useState<'rg' | 'cnh' | 'cin'>(documentType);

  return (
    <div className="space-y-4">
      {/* Document Type Selector */}
      <Tabs value={selectedType} onValueChange={(v) => setSelectedType(v as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="rg">RG</TabsTrigger>
          <TabsTrigger value="cnh">CNH</TabsTrigger>
          <TabsTrigger value="cin">CIN</TabsTrigger>
        </TabsList>

        <TabsContent value="rg">
          <OcrReviewCard config={getOcrConfig('rg')} {...props} />
        </TabsContent>

        <TabsContent value="cnh">
          <OcrReviewCard config={getOcrConfig('cnh')} {...props} />
        </TabsContent>

        <TabsContent value="cin">
          <OcrReviewCard config={getOcrConfig('cin')} {...props} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
