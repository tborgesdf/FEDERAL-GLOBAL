import OcrReviewCard from "./OcrReviewCard";
import { getOcrConfig } from "../../lib/ocr/fields";

interface OcrReviewCard_CivilUnionProps {
  imageUrl?: string;
  initialData?: Record<string, string>;
  onSave: (data: Record<string, string>) => void;
  onReprocess?: () => void;
  isProcessing?: boolean;
}

export default function OcrReviewCard_CivilUnion(props: OcrReviewCard_CivilUnionProps) {
  return <OcrReviewCard config={getOcrConfig('civilUnion')} {...props} />;
}
