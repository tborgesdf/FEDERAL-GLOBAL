import OcrReviewCard from "./OcrReviewCard";
import { getOcrConfig } from "../../lib/ocr/fields";

interface OcrReviewCard_VisaProps {
  imageUrl?: string;
  initialData?: Record<string, string>;
  onSave: (data: Record<string, string>) => void;
  onReprocess?: () => void;
  isProcessing?: boolean;
}

export default function OcrReviewCard_Visa(props: OcrReviewCard_VisaProps) {
  return <OcrReviewCard config={getOcrConfig('visa')} {...props} />;
}
