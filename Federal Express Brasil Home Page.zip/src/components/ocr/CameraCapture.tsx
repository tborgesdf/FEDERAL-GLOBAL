import { useState, useRef, useEffect } from "react";
import { Camera, X, RefreshCw, Upload, Video, AlertCircle, Check } from "lucide-react";
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog";

interface CameraCaptureProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (file: File) => void;
  title?: string;
  facingMode?: "user" | "environment";
  acceptFiles?: string;
}

export default function CameraCapture({
  isOpen,
  onClose,
  onCapture,
  title = "Capturar Imagem",
  facingMode = "environment",
  acceptFiles = "image/jpeg,image/png,application/pdf"
}: CameraCaptureProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [availableCameras, setAvailableCameras] = useState<MediaDeviceInfo[]>([]);
  const [selectedCamera, setSelectedCamera] = useState<string>("");
  const [currentFacingMode, setCurrentFacingMode] = useState<"user" | "environment">(facingMode);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Enumerate cameras on mount
  useEffect(() => {
    if (isOpen) {
      enumerateCameras();
    }
  }, [isOpen]);

  // Start camera when selected
  useEffect(() => {
    if (isOpen && !capturedImage) {
      startCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, selectedCamera, currentFacingMode, capturedImage]);

  const enumerateCameras = async () => {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const cameras = devices.filter(device => device.kind === 'videoinput');
      setAvailableCameras(cameras);

      if (cameras.length > 0 && !selectedCamera) {
        setSelectedCamera(cameras[0].deviceId);
      }
    } catch (err) {
      console.error("Error enumerating cameras:", err);
    }
  };

  const startCamera = async () => {
    setError(null);
    setIsLoading(true);

    try {
      // Stop existing stream first
      stopCamera();

      const constraints: MediaStreamConstraints = {
        video: selectedCamera
          ? { deviceId: { exact: selectedCamera } }
          : {
              facingMode: currentFacingMode,
              width: { ideal: 1280 },
              height: { ideal: 720 }
            },
        audio: false
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }

      setIsLoading(false);
    } catch (err: any) {
      console.error("Camera access error:", err);
      
      let errorMessage = "Não foi possível acessar a câmera.";
      
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        errorMessage = "Permissão de câmera negada. Por favor, permita o acesso à câmera nas configurações do navegador.";
      } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
        errorMessage = "Nenhuma câmera foi encontrada no dispositivo.";
      } else if (err.name === "NotReadableError" || err.name === "TrackStartError") {
        errorMessage = "A câmera está sendo usada por outro aplicativo.";
      } else if (err.name === "OverconstrainedError") {
        errorMessage = "Câmera não suporta as configurações solicitadas.";
      } else if (err.name === "NotSupportedError") {
        errorMessage = "Seu navegador não suporta acesso à câmera. Use HTTPS ou localhost.";
      }

      setError(errorMessage);
      setIsLoading(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");

    if (!context) return;

    // Set canvas size to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw video frame to canvas
    context.drawImage(video, 0, 0);

    // Convert to blob and create preview
    canvas.toBlob((blob) => {
      if (!blob) return;

      const imageUrl = URL.createObjectURL(blob);
      setCapturedImage(imageUrl);
    }, "image/jpeg", 0.9);
  };

  const recapture = () => {
    if (capturedImage) {
      URL.revokeObjectURL(capturedImage);
    }
    setCapturedImage(null);
  };

  const confirmCapture = () => {
    if (!canvasRef.current) return;

    canvasRef.current.toBlob((blob) => {
      if (!blob) return;

      const file = new File([blob], `capture_${Date.now()}.jpg`, { type: "image/jpeg" });
      onCapture(file);
      handleClose();
    }, "image/jpeg", 0.9);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onCapture(file);
      handleClose();
    }
    e.target.value = '';
  };

  const switchCamera = () => {
    setCurrentFacingMode(prev => prev === "user" ? "environment" : "user");
  };

  const handleClose = () => {
    stopCamera();
    if (capturedImage) {
      URL.revokeObjectURL(capturedImage);
    }
    setCapturedImage(null);
    setError(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl p-0">
        <DialogHeader className="border-b border-gray-200 p-6">
          <DialogTitle
            style={{
              fontFamily: "Poppins, sans-serif",
              fontSize: "18px",
              fontWeight: 600,
              color: "#0A4B9E"
            }}
          >
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="p-6">
          {/* Camera Selection - Only show if multiple cameras */}
          {availableCameras.length > 1 && !capturedImage && (
            <div className="mb-4">
              <Label
                htmlFor="camera-select"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  fontWeight: 500,
                  color: "#374151",
                  marginBottom: "8px",
                  display: "block"
                }}
              >
                Selecionar câmera
              </Label>
              <Select value={selectedCamera} onValueChange={setSelectedCamera}>
                <SelectTrigger id="camera-select">
                  <SelectValue placeholder="Escolha uma câmera" />
                </SelectTrigger>
                <SelectContent>
                  {availableCameras.map((camera, index) => (
                    <SelectItem key={camera.deviceId} value={camera.deviceId}>
                      {camera.label || `Câmera ${index + 1}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Video Preview or Captured Image */}
          <div className="relative mb-4 overflow-hidden rounded-xl bg-black">
            {!capturedImage ? (
              <>
                {!error ? (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full"
                      style={{
                        aspectRatio: "16/9",
                        objectFit: "cover",
                        transform: currentFacingMode === "user" ? "scaleX(-1)" : "none"
                      }}
                    />

                    {isLoading && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                        <div className="text-center">
                          <RefreshCw className="mx-auto mb-3 h-8 w-8 animate-spin text-white" />
                          <p
                            style={{
                              fontFamily: "Inter, sans-serif",
                              fontSize: "14px",
                              color: "white"
                            }}
                          >
                            Iniciando câmera...
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Camera overlay hint */}
                    {stream && !isLoading && (
                      <div className="absolute bottom-4 left-0 right-0 text-center">
                        <p
                          style={{
                            fontFamily: "Inter, sans-serif",
                            fontSize: "14px",
                            fontWeight: 600,
                            color: "white",
                            textShadow: "0 2px 4px rgba(0,0,0,0.8)"
                          }}
                        >
                          Posicione o documento dentro do enquadramento
                        </p>
                      </div>
                    )}
                  </>
                ) : (
                  <div
                    className="flex items-center justify-center bg-gray-100 p-12 text-center"
                    style={{ aspectRatio: "16/9" }}
                  >
                    <div>
                      <AlertCircle className="mx-auto mb-4 h-12 w-12 text-red-500" />
                      <p
                        className="mb-2"
                        style={{
                          fontFamily: "Poppins, sans-serif",
                          fontSize: "15px",
                          fontWeight: 600,
                          color: "#DC2626"
                        }}
                      >
                        Erro ao acessar câmera
                      </p>
                      <p
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "13px",
                          color: "#666",
                          maxWidth: "400px",
                          lineHeight: "1.5"
                        }}
                      >
                        {error}
                      </p>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="relative">
                <img
                  src={capturedImage}
                  alt="Captura"
                  className="w-full"
                  style={{
                    aspectRatio: "16/9",
                    objectFit: "cover",
                    transform: currentFacingMode === "user" ? "scaleX(-1)" : "none"
                  }}
                />
                <div className="absolute right-3 top-3">
                  <div className="flex items-center gap-1.5 rounded-full bg-[#2BA84A] px-3 py-1.5">
                    <Check className="h-3.5 w-3.5 text-white" />
                    <span
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "12px",
                        fontWeight: 600,
                        color: "white"
                      }}
                    >
                      Capturada
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3">
            {!capturedImage ? (
              <>
                <Button
                  type="button"
                  onClick={capturePhoto}
                  disabled={!stream || isLoading || !!error}
                  className="flex-1 bg-[#0058CC] hover:bg-[#0A4B9E]"
                >
                  <Camera className="mr-2 h-4 w-4" />
                  Capturar
                </Button>

                {availableCameras.length > 1 && (
                  <Button
                    type="button"
                    onClick={switchCamera}
                    disabled={!stream || isLoading}
                    variant="outline"
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Trocar câmera
                  </Button>
                )}

                <input
                  ref={fileInputRef}
                  type="file"
                  accept={acceptFiles}
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Enviar arquivo
                </Button>
              </>
            ) : (
              <>
                <Button
                  type="button"
                  onClick={recapture}
                  variant="outline"
                  className="flex-1"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Recapturar
                </Button>

                <Button
                  type="button"
                  onClick={confirmCapture}
                  className="flex-1 bg-[#2BA84A] hover:bg-[#238A3A]"
                >
                  <Check className="mr-2 h-4 w-4" />
                  Confirmar e enviar
                </Button>
              </>
            )}
          </div>

          {/* Helper Text */}
          <p
            className="mt-3 text-center"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "12px",
              color: "#6B7280",
              lineHeight: "1.5"
            }}
          >
            {!capturedImage
              ? "Certifique-se de que o documento está bem iluminado e legível"
              : "Revise a imagem antes de confirmar"}
          </p>
        </div>

        {/* Hidden canvas for capture */}
        <canvas ref={canvasRef} className="hidden" />
      </DialogContent>
    </Dialog>
  );
}