import OcrReviewCard from "./OcrReviewCard";
import { getOcrConfig } from "../../lib/ocr/fields";

interface OcrReviewCard_PassportProps {
  imageUrl?: string;
  initialData?: Record<string, string>;
  onSave: (data: Record<string, string>) => void;
  onReprocess?: () => void;
  isProcessing?: boolean;
}

export default function OcrReviewCard_Passport(props: OcrReviewCard_PassportProps) {
  return <OcrReviewCard config={getOcrConfig('passport')} {...props} />;
}
