/**
 * Exportação central de componentes OCR
 * Para uso no Cursor e integração com Supabase
 */

// Componente base universal
export { default as OcrReviewCard } from './OcrReviewCard';

// Componentes específicos por tipo de documento
export { default as OcrReviewCard_Passport } from './OcrReviewCard_Passport';
export { default as OcrReviewCard_BRID } from './OcrReviewCard_BRID';
export { default as OcrReviewCard_Visa } from './OcrReviewCard_Visa';
export { default as OcrReviewCard_MarriageCert } from './OcrReviewCard_MarriageCert';
export { default as OcrReviewCard_CivilUnion } from './OcrReviewCard_CivilUnion';
export { default as OcrReviewCard_BirthCert } from './OcrReviewCard_BirthCert';

// Componente de captura de câmera
export { default as CameraCapture } from './CameraCapture';

// Utilitários e configurações
export * from '../../lib/ocr/fields';
