import { useState } from "react";
import { ArrowLeft, ArrowRight, ChevronDown, ChevronUp, Check, CreditCard, FileText, Users, User, Plus, Minus, AlertCircle } from "lucide-react";
import { toast } from "sonner@2.0.3";
import Header from "./Header";

interface SelectServicesPageProps {
  selectedCountry: string;
  onNext: (services: any[]) => void;
  onBack: () => void;
  onChangeCountry: () => void;
  onLogout: () => void;
  userEmail: string;
}

interface FamilyMember {
  id: string;
  name: string;
}

interface Service {
  id: string;
  title: string;
  price: number;
  badge: string;
  badgeColor: string;
  items: Array<{ label: string; price?: number }>;
  additionalCosts?: Array<{ label: string; value: string }>;
  embassyFees?: Array<{ label: string; value: string }>;
  familyPackage?: {
    principal: number;
    members: number;
  };
}

export default function SelectServicesPage({ 
  selectedCountry, 
  onNext, 
  onBack, 
  onChangeCountry, 
  onLogout, 
  userEmail 
}: SelectServicesPageProps) {
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [expandedServices, setExpandedServices] = useState<string[]>([]);
  const [familyPackages, setFamilyPackages] = useState<Record<string, boolean>>({});
  const [familyMembers, setFamilyMembers] = useState<Record<string, FamilyMember[]>>({});

  // Definir serviços por país
  const servicesData: Record<string, Service[]> = {
    usa: [
      {
        id: "usa-renewal",
        title: "VISTO EUA CHANCELADO - RENOVAÇÃO",
        price: 2000,
        badge: "RENOVAÇÃO",
        badgeColor: "#2BA84A",
        items: [
          { label: "Transmissão DS-160" },
          { label: "Agendamento", },
          { label: "Monitoramento de Agendamento/Antecipação", },
          { label: "Representação CASV (BSB)", }
        ],
        additionalCosts: [
          { label: "Custo Operacional", value: "R$ 250,00 (por requerente)" },
          { label: "Comissionamento", value: "10% sobre valor líquido" }
        ],
        familyPackage: {
          principal: 1200,
          members: 600
        }
      },
      {
        id: "usa-first-time",
        title: "VISTO EUA CHANCELADO - 1ª SOLICITAÇÃO",
        price: 2500,
        badge: "PRIMEIRA VEZ",
        badgeColor: "#0058CC",
        items: [
          { label: "Transmissão DS-160", },
          { label: "Agendamento",},
          { label: "Monitoramento/Antecipação",},
          { label: "Análise Documental",},
          { label: "Consultoria Preventiva",},
          { label: "Assessoria para Entrevista",}
        ],
        embassyFees: [
          { label: "MRV (Taxa Embaixada)", value: "USD 185" },
          { label: "Taxa Retorno Passaporte", value: "R$ 66,00" }
        ],
        familyPackage: {
          principal: 1000,
          members: 500
        }
      },
      {
        id: "usa-esta",
        title: "VISTO ELETRÔNICO (ESTA) - EUA",
        price: 100,
        badge: "ELETRÔNICO",
        badgeColor: "#7C6EE4",
        items: [
          { label: "Transmissão Formulário", price: 100 }
        ],
        embassyFees: [
          { label: "Taxa Embaixada", value: "USD 21 (~R$ 360*)" }
        ]
      }
    ],
    canada: [
      {
        id: "canada-eta",
        title: "VISTO ELETRÔNICO (E-TA) - CANADÁ",
        price: 100,
        badge: "ELETRÔNICO",
        badgeColor: "#7C6EE4",
        items: [
          { label: "Transmissão Formulário", price: 100 }
        ],
        embassyFees: [
          { label: "Taxa Embaixada", value: "CAD 7 (~R$ 360*)" }
        ]
      }
    ]
  };

  const services = servicesData[selectedCountry] || [];

  const countryInfo: Record<string, { flag: string; name: string }> = {
    usa: { flag: "🇺🇸", name: "ESTADOS UNIDOS" },
    canada: { flag: "🇨🇦", name: "CANADÁ" },
    mexico: { flag: "🇲🇽", name: "MÉXICO" }
  };

  const toggleService = (serviceId: string) => {
    if (selectedServices.includes(serviceId)) {
      setSelectedServices(selectedServices.filter(id => id !== serviceId));
      // Desativar pacote familiar se desmarcar serviço
      if (familyPackages[serviceId]) {
        const newPackages = { ...familyPackages };
        delete newPackages[serviceId];
        setFamilyPackages(newPackages);
      }
    } else {
      setSelectedServices([...selectedServices, serviceId]);
    }
  };

  const toggleExpanded = (serviceId: string) => {
    if (expandedServices.includes(serviceId)) {
      setExpandedServices(expandedServices.filter(id => id !== serviceId));
    } else {
      setExpandedServices([...expandedServices, serviceId]);
    }
  };

  const toggleFamilyPackage = (serviceId: string) => {
    setFamilyPackages({
      ...familyPackages,
      [serviceId]: !familyPackages[serviceId]
    });
    
    // Inicializar com 1 membro se ativar
    if (!familyPackages[serviceId] && !familyMembers[serviceId]) {
      setFamilyMembers({
        ...familyMembers,
        [serviceId]: [{ id: '1', name: '' }]
      });
    }
  };

  const addFamilyMember = (serviceId: string) => {
    const current = familyMembers[serviceId] || [];
    const newId = (current.length + 1).toString();
    setFamilyMembers({
      ...familyMembers,
      [serviceId]: [...current, { id: newId, name: '' }]
    });
  };

  const removeFamilyMember = (serviceId: string, memberId: string) => {
    const current = familyMembers[serviceId] || [];
    if (current.length > 1) {
      setFamilyMembers({
        ...familyMembers,
        [serviceId]: current.filter(m => m.id !== memberId)
      });
    }
  };

  const calculateTotal = () => {
    let total = 0;
    selectedServices.forEach(serviceId => {
      const service = services.find(s => s.id === serviceId);
      if (service) {
        if (familyPackages[serviceId] && service.familyPackage) {
          total += service.familyPackage.principal;
          const members = familyMembers[serviceId] || [];
          total += members.length * service.familyPackage.members;
        } else {
          total += service.price;
        }
      }
    });
    return total;
  };

  const handleNext = () => {
    if (selectedServices.length === 0) {
      toast.error("Selecione pelo menos um serviço para continuar");
      return;
    }
    onNext(selectedServices);
  };

  const getInitials = (email: string) => {
    return email.substring(0, 2).toUpperCase();
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--color-background-light)" }}>
      {/* Header */}
      <Header
        isLoggedIn={true}
        userEmail={userEmail}
        onNavigateToLogin={onLogout}
        onNavigateToHome={onBack}
      />

      {/* Breadcrumb Progress - Passo 2 ativo */}
      <div className="bg-white border-b" style={{ borderColor: "var(--color-border)" }}>
        <div className="mx-auto px-4" 
          style={{ 
            maxWidth: "1024px",
            paddingTop: "var(--space-md)",
            paddingBottom: "var(--space-md)"
          }}>
          <div className="flex items-center justify-between">
            {/* Step 1 - Completed */}
            <div className="flex items-center gap-3 flex-1" key="step-1">
              <div className="rounded-full flex items-center justify-center text-white" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "var(--color-brand-green)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                <Check size={20} />
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "var(--color-brand-green)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  País
                </div>
                <div style={{ fontSize: "12px", color: "var(--color-text-muted)" }}>Concluído</div>
              </div>
            </div>

            {/* Connector */}
            <div className="flex-1 mx-4" style={{ height: "2px", backgroundColor: "var(--color-brand-blue)" }} key="connector-1"></div>

            {/* Step 2 - Active */}
            <div className="flex items-center gap-3 flex-1" key="step-2">
              <div className="rounded-full flex items-center justify-center text-white" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "var(--color-brand-blue)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                2
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "var(--color-brand-blue)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  Serviços
                </div>
                <div style={{ fontSize: "12px", color: "var(--color-text-muted)" }}>Escolha os serviços</div>
              </div>
            </div>

            {/* Connector */}
            <div className="flex-1 mx-4" style={{ height: "2px", backgroundColor: "#E5E7EB" }} key="connector-2"></div>

            {/* Step 3 - Inactive */}
            <div className="flex items-center gap-3 flex-1" key="step-3">
              <div className="rounded-full flex items-center justify-center" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "#E5E7EB",
                  color: "#9CA3AF",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                3
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "#9CA3AF",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  Pagamento
                </div>
                <div style={{ fontSize: "12px", color: "#9CA3AF" }}>Finalize a compra</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="mx-auto px-4" 
        style={{ 
          maxWidth: "var(--container-desktop)",
          paddingTop: "var(--space-md)",
          paddingBottom: "var(--space-lg)",
          paddingLeft: "var(--grid-margin-mobile)",
          paddingRight: "var(--grid-margin-mobile)"
        }}>
        
        {/* Botão Voltar */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 mb-6 text-gray-700 hover:text-gray-900 transition-colors"
          style={{ fontFamily: "Inter, sans-serif", fontWeight: 500 }}
        >
          <ArrowLeft size={20} />
          Voltar
        </button>

        {/* Card País Selecionado */}
        <div className="bg-white rounded-lg p-4 mb-6 flex items-center justify-between border"
          style={{ 
            borderColor: "var(--color-border)",
            borderRadius: "var(--radius-md)",
            boxShadow: "var(--shadow-card)"
          }}>
          <div className="flex items-center gap-3">
            <div style={{ fontSize: "32px" }}>{countryInfo[selectedCountry]?.flag}</div>
            <div>
              <div style={{ 
                fontSize: "12px", 
                color: "var(--color-text-muted)",
                fontFamily: "Inter, sans-serif"
              }}>
                País selecionado
              </div>
              <div style={{ 
                fontFamily: "Poppins, sans-serif",
                fontWeight: 700,
                fontSize: "18px",
                color: "var(--color-text-primary)"
              }}>
                {countryInfo[selectedCountry]?.name}
              </div>
            </div>
          </div>
          <button
            onClick={onChangeCountry}
            style={{ 
              color: "var(--color-brand-blue)",
              fontFamily: "Inter, sans-serif",
              fontWeight: 600,
              fontSize: "14px"
            }}
            className="hover:underline"
          >
            Alterar país
          </button>
        </div>

        {/* Layout 2 Colunas */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Coluna Esquerda - Lista de Serviços */}
          <div className="lg:col-span-2 space-y-4">
            <h2 style={{ 
              fontFamily: "Poppins, sans-serif",
              fontWeight: 700,
              fontSize: "24px",
              color: "var(--color-text-primary)",
              marginBottom: "var(--space-md)"
            }}>
              Serviços Disponíveis
            </h2>

            {services.map((service) => (
              <div
                key={service.id}
                className="bg-white rounded-lg border transition-all"
                style={{ 
                  borderColor: selectedServices.includes(service.id) ? "var(--color-brand-blue)" : "var(--color-border)",
                  borderWidth: selectedServices.includes(service.id) ? "2px" : "1px",
                  borderRadius: "var(--radius-md)",
                  boxShadow: selectedServices.includes(service.id) ? "var(--shadow-hover)" : "var(--shadow-card)"
                }}
              >
                {/* Cabeçalho do Card */}
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    {/* Checkbox */}
                    <div 
                      onClick={() => toggleService(service.id)}
                      className="cursor-pointer mt-1"
                      style={{ 
                        width: "24px", 
                        height: "24px",
                        borderRadius: "6px",
                        border: `2px solid ${selectedServices.includes(service.id) ? 'var(--color-brand-blue)' : '#D1D5DB'}`,
                        backgroundColor: selectedServices.includes(service.id) ? 'var(--color-brand-blue)' : 'white',
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        transition: "all 0.2s"
                      }}
                    >
                      {selectedServices.includes(service.id) && (
                        <Check size={16} className="text-white" />
                      )}
                    </div>

                    {/* Conteúdo */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 style={{ 
                              fontFamily: "Poppins, sans-serif",
                              fontWeight: 700,
                              fontSize: "18px",
                              color: "var(--color-text-primary)"
                            }}>
                              {service.title}
                            </h3>
                            <span 
                              className="px-3 py-1 rounded-full text-white"
                              style={{ 
                                backgroundColor: service.badgeColor,
                                fontSize: "12px",
                                fontFamily: "Poppins, sans-serif",
                                fontWeight: 600
                              }}
                            >
                              {service.badge}
                            </span>
                          </div>
                          <div style={{ 
                            fontFamily: "Poppins, sans-serif",
                            fontWeight: 700,
                            fontSize: "24px",
                            color: "var(--color-brand-blue)"
                          }}>
                            {service.badge === "ELETRÔNICO" 
                              ? `R$ ${service.price.toLocaleString('pt-BR')} + Taxa Embaixada`
                              : `R$ ${service.price.toLocaleString('pt-BR')}`
                            }
                          </div>
                        </div>

                        {/* Botão Expandir */}
                        <button
                          onClick={() => toggleExpanded(service.id)}
                          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                          style={{ borderRadius: "var(--radius-sm)" }}
                        >
                          {expandedServices.includes(service.id) ? (
                            <ChevronUp size={24} style={{ color: "var(--color-text-secondary)" }} />
                          ) : (
                            <ChevronDown size={24} style={{ color: "var(--color-text-secondary)" }} />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Conteúdo Expandido */}
                  {expandedServices.includes(service.id) && (
                    <div className="mt-6 pt-6 border-t" style={{ borderColor: "var(--color-border)" }}>
                      {/* Serviços Incluídos */}
                      <div className="mb-6">
                        <h4 style={{ 
                          fontFamily: "Poppins, sans-serif",
                          fontWeight: 600,
                          fontSize: "16px",
                          color: "var(--color-text-primary)",
                          marginBottom: "var(--space-sm)"
                        }}>
                          Serviços incluídos:
                        </h4>
                        <div className="space-y-2">
                          {service.items.map((item, idx) => (
                            <div key={idx} className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Check size={16} style={{ color: "var(--color-brand-green)" }} />
                                <span style={{ 
                                  fontFamily: "Inter, sans-serif",
                                  fontSize: "14px",
                                  color: "var(--color-text-secondary)"
                                }}>
                                  {item.label}
                                </span>
                              </div>
                              {item.price && (
                                <span style={{ 
                                  fontFamily: "Poppins, sans-serif",
                                  fontWeight: 600,
                                  fontSize: "14px",
                                  color: "var(--color-text-primary)"
                                }}>
                                  R$ {item.price.toLocaleString('pt-BR')}
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Custos Adicionais */}
                      {service.additionalCosts && (
                        <div className="mb-6 p-4 rounded-lg" 
                          style={{ 
                            backgroundColor: "#EFF6FF",
                            borderRadius: "var(--radius-sm)"
                          }}>
                          <div className="flex items-start gap-2 mb-3">
                            <AlertCircle size={18} style={{ color: "var(--color-brand-blue)", marginTop: "2px" }} />
                            <h4 style={{ 
                              fontFamily: "Poppins, sans-serif",
                              fontWeight: 600,
                              fontSize: "14px",
                              color: "var(--color-brand-blue)"
                            }}>
                              Custos Adicionais:
                            </h4>
                          </div>
                          <div className="space-y-1 ml-6">
                            {service.additionalCosts.map((cost, idx) => (
                              <div key={idx} style={{ 
                                fontFamily: "Inter, sans-serif",
                                fontSize: "14px",
                                color: "var(--color-text-secondary)"
                              }}>
                                <strong>{cost.label}:</strong> {cost.value}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Taxas Embaixada */}
                      {service.embassyFees && (
                        <div className="mb-6 p-4 rounded-lg" 
                          style={{ 
                            backgroundColor: "#FEF3C7",
                            borderRadius: "var(--radius-sm)"
                          }}>
                          <div className="flex items-start gap-2 mb-3">
                            <AlertCircle size={18} style={{ color: "#F59E0B", marginTop: "2px" }} />
                            <h4 style={{ 
                              fontFamily: "Poppins, sans-serif",
                              fontWeight: 600,
                              fontSize: "14px",
                              color: "#D97706"
                            }}>
                              Custos Extras (pagos diretamente à embaixada):
                            </h4>
                          </div>
                          <div className="space-y-1 ml-6">
                            {service.embassyFees.map((fee, idx) => (
                              <div key={idx} style={{ 
                                fontFamily: "Inter, sans-serif",
                                fontSize: "14px",
                                color: "#92400E"
                              }}>
                                <strong>{fee.label}:</strong> {fee.value}
                              </div>
                            ))}
                          </div>
                          {service.id === "usa-esta" || service.id === "canada-eta" ? (
                            <div className="mt-2 ml-6" style={{ 
                              fontFamily: "Inter, sans-serif",
                              fontSize: "12px",
                              color: "#92400E",
                              fontStyle: "italic"
                            }}>
                              *Valor aproximado, sujeito à cotação
                            </div>
                          ) : service.embassyFees && (
                            <div className="mt-2 ml-6" style={{ 
                              fontFamily: "Inter, sans-serif",
                              fontSize: "12px",
                              color: "#92400E",
                              fontStyle: "italic"
                            }}>
                              Observação: Valores pagos diretamente à embaixada
                            </div>
                          )}
                        </div>
                      )}

                      {/* Pacote Familiar */}
                      {service.familyPackage && (
                        <div className="p-4 rounded-lg border" 
                          style={{ 
                            borderColor: familyPackages[service.id] ? "var(--color-brand-blue)" : "var(--color-border)",
                            backgroundColor: familyPackages[service.id] ? "#EFF6FF" : "#F9FAFB",
                            borderRadius: "var(--radius-sm)"
                          }}>
                          <div className="flex items-start gap-3 mb-4">
                            <Users size={20} style={{ color: "var(--color-brand-blue)", marginTop: "2px" }} />
                            <div className="flex-1">
                              <h4 style={{ 
                                fontFamily: "Poppins, sans-serif",
                                fontWeight: 600,
                                fontSize: "16px",
                                color: "var(--color-text-primary)",
                                marginBottom: "4px"
                              }}>
                                Pacote Promocional Familiar
                              </h4>
                              <div className="space-y-1 mb-4">
                                <div className="flex items-center gap-2" style={{ 
                                  fontFamily: "Inter, sans-serif",
                                  fontSize: "14px",
                                  color: "var(--color-text-secondary)"
                                }}>
                                  <User size={16} />
                                  Requerente Principal: <strong>R$ {service.familyPackage.principal.toLocaleString('pt-BR')}</strong>
                                </div>
                                <div className="flex items-center gap-2" style={{ 
                                  fontFamily: "Inter, sans-serif",
                                  fontSize: "14px",
                                  color: "var(--color-text-secondary)"
                                }}>
                                  <Users size={16} />
                                  Membros Familiares: <strong>R$ {service.familyPackage.members.toLocaleString('pt-BR')}/cada</strong>
                                </div>
                              </div>

                              {/* Toggle Switch */}
                              <div className="flex items-center gap-3 mb-4">
                                <button
                                  onClick={() => toggleFamilyPackage(service.id)}
                                  className="relative inline-flex h-6 w-11 items-center rounded-full transition-colors"
                                  style={{ 
                                    backgroundColor: familyPackages[service.id] ? "var(--color-brand-blue)" : "#D1D5DB"
                                  }}
                                >
                                  <span
                                    className="inline-block h-4 w-4 transform rounded-full bg-white transition-transform"
                                    style={{ 
                                      transform: familyPackages[service.id] ? "translateX(1.5rem)" : "translateX(0.25rem)"
                                    }}
                                  />
                                </button>
                                <span style={{ 
                                  fontFamily: "Poppins, sans-serif",
                                  fontWeight: 600,
                                  fontSize: "14px",
                                  color: "var(--color-text-primary)"
                                }}>
                                  Contratar Pacote Familiar
                                </span>
                              </div>

                              {/* Campos Membros Familiares */}
                              {familyPackages[service.id] && (
                                <div className="space-y-3">
                                  <div style={{ 
                                    fontFamily: "Inter, sans-serif",
                                    fontSize: "14px",
                                    color: "var(--color-text-secondary)",
                                    marginBottom: "8px"
                                  }}>
                                    Adicione os membros familiares:
                                  </div>
                                  {(familyMembers[service.id] || []).map((member, idx) => (
                                    <div key={member.id} className="flex items-center gap-2">
                                      <input
                                        type="text"
                                        placeholder={`Membro ${idx + 1}`}
                                        className="flex-1 px-3 py-2 border rounded-lg"
                                        style={{ 
                                          borderColor: "var(--color-border)",
                                          borderRadius: "var(--radius-sm)",
                                          fontFamily: "Inter, sans-serif",
                                          fontSize: "14px"
                                        }}
                                      />
                                      <button
                                        onClick={() => removeFamilyMember(service.id, member.id)}
                                        disabled={familyMembers[service.id]?.length === 1}
                                        className="p-2 rounded-lg transition-colors"
                                        style={{ 
                                          backgroundColor: familyMembers[service.id]?.length === 1 ? "#F3F4F6" : "#FEE2E2",
                                          color: familyMembers[service.id]?.length === 1 ? "#9CA3AF" : "#DC2626",
                                          cursor: familyMembers[service.id]?.length === 1 ? "not-allowed" : "pointer",
                                          borderRadius: "var(--radius-sm)"
                                        }}
                                      >
                                        <Minus size={20} />
                                      </button>
                                      {idx === (familyMembers[service.id]?.length || 0) - 1 && (
                                        <button
                                          onClick={() => addFamilyMember(service.id)}
                                          className="p-2 rounded-lg transition-colors"
                                          style={{ 
                                            backgroundColor: "#DCFCE7",
                                            color: "var(--color-brand-green)",
                                            borderRadius: "var(--radius-sm)"
                                          }}
                                        >
                                          <Plus size={20} />
                                        </button>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Coluna Direita - Resumo do Pedido */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 border sticky top-24"
              style={{ 
                borderColor: "var(--color-border)",
                borderRadius: "var(--radius-md)",
                boxShadow: "var(--shadow-card)"
              }}>
              <h3 style={{ 
                fontFamily: "Poppins, sans-serif",
                fontWeight: 700,
                fontSize: "20px",
                color: "var(--color-text-primary)",
                marginBottom: "var(--space-md)"
              }}>
                Resumo do Pedido
              </h3>

              {selectedServices.length === 0 ? (
                <div className="text-center py-8">
                  <FileText size={48} className="mx-auto mb-4" style={{ color: "#D1D5DB" }} />
                  <p style={{ 
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "var(--color-text-muted)"
                  }}>
                    Nenhum serviço selecionado
                  </p>
                </div>
              ) : (
                <>
                  {/* Lista de Serviços */}
                  <div className="space-y-3 mb-6 pb-6 border-b" style={{ borderColor: "var(--color-border)" }}>
                    {selectedServices.map(serviceId => {
                      const service = services.find(s => s.id === serviceId);
                      if (!service) return null;

                      const isFamilyPackage = familyPackages[serviceId];
                      const members = familyMembers[serviceId] || [];
                      const serviceTotal = isFamilyPackage && service.familyPackage
                        ? service.familyPackage.principal + (members.length * service.familyPackage.members)
                        : service.price;

                      return (
                        <div key={serviceId}>
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div style={{ 
                                fontFamily: "Inter, sans-serif",
                                fontSize: "14px",
                                color: "var(--color-text-primary)",
                                fontWeight: 600
                              }}>
                                {service.title}
                              </div>
                              {isFamilyPackage && service.familyPackage && (
                                <div style={{ 
                                  fontFamily: "Inter, sans-serif",
                                  fontSize: "12px",
                                  color: "var(--color-text-muted)",
                                  marginTop: "4px"
                                }}>
                                  Pacote Familiar: 1 + {members.length} {members.length === 1 ? 'membro' : 'membros'}
                                </div>
                              )}
                            </div>
                            <div style={{ 
                              fontFamily: "Poppins, sans-serif",
                              fontWeight: 600,
                              fontSize: "16px",
                              color: "var(--color-text-primary)",
                              whiteSpace: "nowrap",
                              marginLeft: "12px"
                            }}>
                              R$ {serviceTotal.toLocaleString('pt-BR')}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Total */}
                  <div className="mb-6">
                    <div className="flex justify-between items-center">
                      <div style={{ 
                        fontFamily: "Poppins, sans-serif",
                        fontWeight: 700,
                        fontSize: "20px",
                        color: "var(--color-text-primary)"
                      }}>
                        TOTAL
                      </div>
                      <div style={{ 
                        fontFamily: "Poppins, sans-serif",
                        fontWeight: 700,
                        fontSize: "28px",
                        color: "var(--color-brand-blue)"
                      }}>
                        R$ {calculateTotal().toLocaleString('pt-BR')}
                      </div>
                    </div>
                  </div>

                  {/* Formas de Pagamento */}
                  <div className="mb-6 p-4 rounded-lg" 
                    style={{ 
                      backgroundColor: "#F9FAFB",
                      borderRadius: "var(--radius-sm)"
                    }}>
                    <div style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      color: "var(--color-text-muted)",
                      marginBottom: "8px"
                    }}>
                      Formas de pagamento aceitas:
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <CreditCard size={20} style={{ color: "var(--color-text-secondary)" }} />
                        <span style={{ 
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px",
                          color: "var(--color-text-secondary)"
                        }}>
                          Cartão
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <FileText size={20} style={{ color: "var(--color-text-secondary)" }} />
                        <span style={{ 
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px",
                          color: "var(--color-text-secondary)"
                        }}>
                          Boleto
                        </span>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between mt-8 pt-8 border-t" style={{ borderColor: "var(--color-border)" }}>
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-6 py-3 border-2 rounded-lg hover:bg-gray-50 transition-colors"
            style={{ 
              borderColor: "#D1D5DB",
              color: "var(--color-text-secondary)",
              borderRadius: "var(--radius-sm)",
              fontFamily: "Poppins, sans-serif",
              fontWeight: 600
            }}
          >
            <ArrowLeft size={20} />
            Voltar
          </button>

          <button
            onClick={handleNext}
            disabled={selectedServices.length === 0}
            className="flex items-center gap-2 px-8 py-3 rounded-lg transition-all"
            style={{ 
              backgroundColor: selectedServices.length > 0 ? "var(--color-brand-blue)" : "#D1D5DB",
              color: selectedServices.length > 0 ? "white" : "#6B7280",
              cursor: selectedServices.length > 0 ? "pointer" : "not-allowed",
              borderRadius: "var(--radius-sm)",
              fontFamily: "Poppins, sans-serif",
              fontWeight: 600,
              boxShadow: selectedServices.length > 0 ? "var(--shadow-button)" : "none"
            }}
          >
            Ir para Pagamento
            <ArrowRight size={20} />
          </button>
        </div>
      </main>
    </div>
  );
}