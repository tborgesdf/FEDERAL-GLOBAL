import { useState, useEffect } from "react";
import DocumentCapture from "../DocumentCapture";

interface PassportData {
  file: File | null;
  ocrData: {
    number: string;
    fullName: string;
    birthDate: string;
    issueDate: string;
    expiryDate: string;
    nationality: string;
    mrz: string;
  } | null;
}

interface PassportStepProps {
  data: PassportData;
  onChange: (data: PassportData) => void;
}

export default function PassportStep({ data, onChange }: PassportStepProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const simulateOCR = async (file: File): Promise<PassportData["ocrData"]> => {
    // Simular processamento OCR
    await new Promise(resolve => setTimeout(resolve, 2000));

    return {
      number: "BR123456789",
      fullName: "JOÃO DA SILVA SANTOS",
      birthDate: "15/03/1985",
      issueDate: "10/01/2020",
      expiryDate: "10/01/2030",
      nationality: "BRASILEIRA",
      mrz: "P<BRASILVA<<SANTOS<<JOAO<<<<<<<<<<<<<<<<<\nBR12345678BRA8503156M3001105<<<<<<<<<<<<<<06"
    };
  };

  const handleFileSelected = async (file: File | null) => {
    if (!file) {
      onChange({ file: null, ocrData: null });
      return;
    }

    setIsProcessing(true);
    onChange({ ...data, file });

    try {
      const ocrResult = await simulateOCR(file);
      onChange({ file, ocrData: ocrResult });
    } catch (error) {
      console.error("OCR Error:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  const ocrFields = [
    { key: "number", label: "Número do Passaporte" },
    { key: "fullName", label: "Nome Completo" },
    { key: "birthDate", label: "Data de Nascimento" },
    { key: "issueDate", label: "Data de Emissão" },
    { key: "expiryDate", label: "Data de Validade" },
    { key: "nationality", label: "Nacionalidade" },
    { key: "mrz", label: "MRZ (Machine Readable Zone)" }
  ];

  return (
    <div>
      <DocumentCapture
        title="Passaporte"
        description="Envie uma foto clara da página de identificação do seu passaporte. O sistema extrairá automaticamente os dados."
        onFileSelected={handleFileSelected}
        acceptedFormats="image/jpeg,image/jpg,image/png,application/pdf"
        ocrFields={ocrFields}
        showOCRReview={true}
        capturedFile={data.file}
        ocrData={data.ocrData}
        isProcessing={isProcessing}
      />
    </div>
  );
}
