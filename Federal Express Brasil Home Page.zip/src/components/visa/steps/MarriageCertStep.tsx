import { useState } from "react";
import DocumentCapture from "../DocumentCapture";

interface MarriageCertData {
  file: File | null;
  ocrData: {
    spouseName: string;
    marriageDate: string;
    registryOffice: string;
    state: string;
    book: string;
    page: string;
    term: string;
  } | null;
}

interface MarriageCertStepProps {
  data: MarriageCertData;
  onChange: (data: MarriageCertData) => void;
  civilStatus: "married" | "common-law";
}

export default function MarriageCertStep({ data, onChange, civilStatus }: MarriageCertStepProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const simulateOCR = async (file: File): Promise<MarriageCertData["ocrData"]> => {
    await new Promise(resolve => setTimeout(resolve, 2000));

    return {
      spouseName: "MARIA OLIVEIRA SANTOS",
      marriageDate: "10/06/2010",
      registryOffice: "1º Cartório de Registro Civil",
      state: "SP",
      book: "A-123",
      page: "45",
      term: "678"
    };
  };

  const handleFileSelected = async (file: File | null) => {
    if (!file) {
      onChange({ file: null, ocrData: null });
      return;
    }

    setIsProcessing(true);
    onChange({ ...data, file });

    try {
      const ocrResult = await simulateOCR(file);
      onChange({ file, ocrData: ocrResult });
    } catch (error) {
      console.error("OCR Error:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  const ocrFields = [
    { key: "spouseName", label: civilStatus === "married" ? "Nome do Cônjuge" : "Nome do(a) Companheiro(a)" },
    { key: "marriageDate", label: civilStatus === "married" ? "Data do Casamento" : "Data da União" },
    { key: "registryOffice", label: "Cartório" },
    { key: "state", label: "UF" },
    { key: "book", label: "Livro" },
    { key: "page", label: "Folha" },
    { key: "term", label: "Termo" }
  ];

  const title = civilStatus === "married" ? "Certidão de Casamento" : "Certidão de União Estável";
  const description = civilStatus === "married"
    ? "Envie uma foto ou PDF da certidão de casamento atualizada"
    : "Envie uma foto ou PDF da certidão de união estável";

  return (
    <div>
      <DocumentCapture
        title={title}
        description={description}
        onFileSelected={handleFileSelected}
        acceptedFormats="image/jpeg,image/jpg,image/png,application/pdf"
        ocrFields={ocrFields}
        showOCRReview={true}
        capturedFile={data.file}
        ocrData={data.ocrData}
        isProcessing={isProcessing}
      />
    </div>
  );
}
