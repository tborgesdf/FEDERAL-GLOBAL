import { useState } from "react";
import { Label } from "../../ui/label";
import { Input } from "../../ui/input";
import { Switch } from "../../ui/switch";

interface SocialsData {
  hasSocials: boolean;
  facebook?: string;
  instagram?: string;
  x?: string;
  youtube?: string;
  linkedin?: string;
  tiktok?: string;
  snapchat?: string;
  pinterest?: string;
  kwai?: string;
  messenger?: string;
  telegram?: string;
  others?: string;
}

interface SocialsStepProps {
  data: SocialsData;
  onChange: (data: SocialsData) => void;
  errors?: Record<string, string>;
}

export default function SocialsStep({ data, onChange, errors = {} }: SocialsStepProps) {
  const [formData, setFormData] = useState<SocialsData>(data);

  const handleToggle = (checked: boolean) => {
    const newData = { ...formData, hasSocials: checked };
    setFormData(newData);
    onChange(newData);
  };

  const handleChange = (platform: string, value: string) => {
    const newData = { ...formData, [platform]: value };
    setFormData(newData);
    onChange(newData);
  };

  const platforms = [
    { key: "facebook", label: "Facebook", placeholder: "@seuperfil" },
    { key: "instagram", label: "Instagram", placeholder: "@seuperfil" },
    { key: "x", label: "X (Twitter)", placeholder: "@seuperfil" },
    { key: "youtube", label: "YouTube", placeholder: "@seucanal" },
    { key: "linkedin", label: "LinkedIn", placeholder: "linkedin.com/in/seuperfil" },
    { key: "tiktok", label: "TikTok", placeholder: "@seuperfil" },
    { key: "snapchat", label: "Snapchat", placeholder: "@seuperfil" },
    { key: "pinterest", label: "Pinterest", placeholder: "@seuperfil" },
    { key: "kwai", label: "Kwai", placeholder: "@seuperfil" },
    { key: "messenger", label: "Messenger", placeholder: "Nome de usuário" },
    { key: "telegram", label: "Telegram", placeholder: "@seuperfil" },
    { key: "others", label: "Outras redes", placeholder: "Especifique" }
  ];

  return (
    <div className="space-y-6">
      {/* Toggle principal */}
      <div className="flex items-center justify-between rounded-lg border border-gray-200 bg-gray-50 p-4">
        <div>
          <Label
            htmlFor="hasSocials"
            style={{
              fontFamily: "Poppins, sans-serif",
              fontSize: "16px",
              fontWeight: 600,
              color: "#0A4B9E"
            }}
          >
            Você possui redes sociais?
          </Label>
          <p
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "13px",
              fontWeight: 400,
              color: "#666",
              marginTop: "4px"
            }}
          >
            Marque sim se você possui perfil em alguma rede social
          </p>
        </div>
        <Switch
          id="hasSocials"
          checked={formData.hasSocials}
          onCheckedChange={handleToggle}
        />
      </div>

      {/* Grid de inputs (só aparece se hasSocials = true) */}
      {formData.hasSocials && (
        <>
          <div className="rounded-lg border border-blue-100 bg-blue-50 p-4">
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "13px",
                fontWeight: 500,
                color: "#0058CC"
              }}
            >
              ℹ️ Preencha pelo menos uma rede social abaixo
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {platforms.map((platform) => (
              <div key={platform.key}>
                <Label htmlFor={platform.key}>{platform.label}</Label>
                <Input
                  id={platform.key}
                  value={formData[platform.key as keyof SocialsData] || ""}
                  onChange={(e) => handleChange(platform.key, e.target.value)}
                  placeholder={platform.placeholder}
                  className={errors[platform.key] ? "border-red-500" : ""}
                />
                {errors[platform.key] && (
                  <p className="mt-1 text-sm text-red-600">{errors[platform.key]}</p>
                )}
              </div>
            ))}
          </div>

          {errors.general && (
            <div className="rounded-lg bg-red-50 p-4">
              <p className="text-sm text-red-800">{errors.general}</p>
            </div>
          )}
        </>
      )}

      {!formData.hasSocials && (
        <div className="rounded-lg border border-gray-200 bg-gray-50 p-6 text-center">
          <p
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "14px",
              fontWeight: 400,
              color: "#666"
            }}
          >
            Você marcou que não possui redes sociais. Clique em "Próximo" para continuar.
          </p>
        </div>
      )}
    </div>
  );
}
