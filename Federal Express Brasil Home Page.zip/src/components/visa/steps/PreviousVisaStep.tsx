import { useState } from "react";
import DocumentCapture from "../DocumentCapture";

interface PreviousVisaData {
  file: File | null;
  ocrData: {
    number: string;
    type: string;
    issueDate: string;
    expiryDate: string;
  } | null;
}

interface PreviousVisaStepProps {
  data: PreviousVisaData;
  onChange: (data: PreviousVisaData) => void;
}

export default function PreviousVisaStep({ data, onChange }: PreviousVisaStepProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const simulateOCR = async (file: File): Promise<PreviousVisaData["ocrData"]> => {
    await new Promise(resolve => setTimeout(resolve, 2000));

    return {
      number: "A12345678",
      type: "B1/B2 (Turismo e Negócios)",
      issueDate: "20/05/2019",
      expiryDate: "20/05/2024"
    };
  };

  const handleFileSelected = async (file: File | null) => {
    if (!file) {
      onChange({ file: null, ocrData: null });
      return;
    }

    setIsProcessing(true);
    onChange({ ...data, file });

    try {
      const ocrResult = await simulateOCR(file);
      onChange({ file, ocrData: ocrResult });
    } catch (error) {
      console.error("OCR Error:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  const ocrFields = [
    { key: "number", label: "Número do Visto" },
    { key: "type", label: "Tipo de Visto" },
    { key: "issueDate", label: "Data de Emissão" },
    { key: "expiryDate", label: "Data de Validade" }
  ];

  return (
    <div>
      <DocumentCapture
        title="Visto Anterior"
        description="Envie uma foto do seu visto americano anterior. Esta informação é necessária para renovação."
        onFileSelected={handleFileSelected}
        acceptedFormats="image/jpeg,image/jpg,image/png,application/pdf"
        ocrFields={ocrFields}
        showOCRReview={true}
        capturedFile={data.file}
        ocrData={data.ocrData}
        isProcessing={isProcessing}
      />
    </div>
  );
}
