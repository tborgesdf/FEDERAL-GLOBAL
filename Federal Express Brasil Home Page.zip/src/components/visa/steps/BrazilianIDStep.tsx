import { useState } from "react";
import { Label } from "../../ui/label";
import DocumentCapture from "../DocumentCapture";

type IDType = "rg" | "cnh" | "cnh-digital";

interface BrazilianIDData {
  type: IDType;
  frontFile: File | null;
  backFile: File | null;
  pdfFile: File | null;
  ocrData: {
    number: string;
    fullName: string;
    cpf: string;
    birthDate: string;
    issuer: string;
    state: string;
  } | null;
}

interface BrazilianIDStepProps {
  data: BrazilianIDData;
  onChange: (data: BrazilianIDData) => void;
}

export default function BrazilianIDStep({ data, onChange }: BrazilianIDStepProps) {
  const [isProcessingFront, setIsProcessingFront] = useState(false);
  const [isProcessingBack, setIsProcessingBack] = useState(false);
  const [isProcessingPDF, setIsProcessingPDF] = useState(false);

  const simulateOCR = async (file: File, side: "front" | "back" | "pdf"): Promise<Partial<BrazilianIDData["ocrData"]>> => {
    await new Promise(resolve => setTimeout(resolve, 2000));

    if (side === "front" || side === "pdf") {
      return {
        number: data.type === "rg" ? "12.345.678-9" : "123456789012",
        fullName: "JOÃO DA SILVA SANTOS",
        cpf: "123.456.789-00",
        birthDate: "15/03/1985",
        issuer: data.type === "rg" ? "SSP" : "DETRAN",
        state: "SP"
      };
    }

    return {};
  };

  const handleTypeChange = (type: IDType) => {
    onChange({
      type,
      frontFile: null,
      backFile: null,
      pdfFile: null,
      ocrData: null
    });
  };

  const handleFrontFileSelected = async (file: File | null) => {
    if (!file) {
      onChange({ ...data, frontFile: null });
      return;
    }

    setIsProcessingFront(true);
    onChange({ ...data, frontFile: file });

    try {
      const ocrResult = await simulateOCR(file, "front");
      onChange({
        ...data,
        frontFile: file,
        ocrData: { ...data.ocrData, ...ocrResult } as BrazilianIDData["ocrData"]
      });
    } catch (error) {
      console.error("OCR Error:", error);
    } finally {
      setIsProcessingFront(false);
    }
  };

  const handleBackFileSelected = async (file: File | null) => {
    if (!file) {
      onChange({ ...data, backFile: null });
      return;
    }

    setIsProcessingBack(true);
    onChange({ ...data, backFile: file });

    try {
      await simulateOCR(file, "back");
      onChange({ ...data, backFile: file });
    } catch (error) {
      console.error("OCR Error:", error);
    } finally {
      setIsProcessingBack(false);
    }
  };

  const handlePDFFileSelected = async (file: File | null) => {
    if (!file) {
      onChange({ ...data, pdfFile: null });
      return;
    }

    setIsProcessingPDF(true);
    onChange({ ...data, pdfFile: file });

    try {
      const ocrResult = await simulateOCR(file, "pdf");
      onChange({
        ...data,
        pdfFile: file,
        ocrData: { ...data.ocrData, ...ocrResult } as BrazilianIDData["ocrData"]
      });
    } catch (error) {
      console.error("OCR Error:", error);
    } finally {
      setIsProcessingPDF(false);
    }
  };

  const ocrFields = [
    { key: "number", label: data.type === "rg" ? "Número do RG" : "Número da CNH" },
    { key: "fullName", label: "Nome Completo" },
    { key: "cpf", label: "CPF" },
    { key: "birthDate", label: "Data de Nascimento" },
    { key: "issuer", label: "Órgão Emissor" },
    { key: "state", label: "UF" }
  ];

  return (
    <div className="space-y-6">
      {/* Seletor de tipo de documento */}
      <div>
        <Label
          style={{
            fontFamily: "Poppins, sans-serif",
            fontSize: "16px",
            fontWeight: 600,
            color: "#0A4B9E",
            marginBottom: "12px",
            display: "block"
          }}
        >
          Selecione o tipo de documento
        </Label>

        <div className="grid grid-cols-3 gap-3">
          {[
            { value: "rg" as IDType, label: "RG" },
            { value: "cnh" as IDType, label: "CNH" },
            { value: "cnh-digital" as IDType, label: "CNH Digital" }
          ].map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => handleTypeChange(option.value)}
              className={`rounded-lg border-2 px-4 py-3 transition-all ${
                data.type === option.value
                  ? "border-[#0058CC] bg-[#0058CC]/10 text-[#0058CC]"
                  : "border-gray-200 bg-white text-gray-700 hover:border-gray-300"
              }`}
            >
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 600
                }}
              >
                {option.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Captura de documentos */}
      {data.type !== "cnh-digital" ? (
        <div className="space-y-6">
          <DocumentCapture
            title={`${data.type === "rg" ? "RG" : "CNH"} - Frente`}
            description="Envie uma foto clara da frente do documento"
            onFileSelected={handleFrontFileSelected}
            acceptedFormats="image/jpeg,image/jpg,image/png"
            ocrFields={ocrFields}
            showOCRReview={true}
            capturedFile={data.frontFile}
            ocrData={data.ocrData}
            isProcessing={isProcessingFront}
          />

          <DocumentCapture
            title={`${data.type === "rg" ? "RG" : "CNH"} - Verso`}
            description="Envie uma foto clara do verso do documento"
            onFileSelected={handleBackFileSelected}
            acceptedFormats="image/jpeg,image/jpg,image/png"
            showOCRReview={false}
            capturedFile={data.backFile}
            ocrData={null}
            isProcessing={isProcessingBack}
          />
        </div>
      ) : (
        <DocumentCapture
          title="CNH Digital - PDF"
          description="Envie o arquivo PDF da sua CNH Digital"
          onFileSelected={handlePDFFileSelected}
          acceptedFormats="application/pdf"
          ocrFields={ocrFields}
          showOCRReview={true}
          capturedFile={data.pdfFile}
          ocrData={data.ocrData}
          isProcessing={isProcessingPDF}
        />
      )}
    </div>
  );
}
