import { useState } from "react";
import { Label } from "../../ui/label";
import { Input } from "../../ui/input";
import { Checkbox } from "../../ui/checkbox";
import { ChevronDown, ChevronUp, Check } from "lucide-react";

interface QuestionnaireData {
  // Dados já extraídos (readonly)
  extractedData: {
    fullName?: string;
    cpf?: string;
    birthDate?: string;
    passportNumber?: string;
    nationality?: string;
  };

  // Campos adicionais do formulário
  birthCity: string;
  birthCountry: string;
  fatherName: string;
  motherName: string;
  occupation: string;
  employer: string;
  
  // Viagem
  travelPurpose: string;
  stayDuration: string;
  usContact: string;
  usAddress: string;

  // Segurança (checkboxes pré-marcados)
  hasBeenDeported: boolean;
  hasCriminalRecord: boolean;
  hasInfectiousDisease: boolean;
  hasDrugHistory: boolean;
  hasBeenDeniedVisa: boolean;
}

interface QuestionnaireStepProps {
  data: QuestionnaireData;
  onChange: (data: QuestionnaireData) => void;
  errors?: Record<string, string>;
}

export default function QuestionnaireStep({ data, onChange, errors = {} }: QuestionnaireStepProps) {
  const [showExtracted, setShowExtracted] = useState(true);

  const handleChange = (field: string, value: string | boolean) => {
    onChange({ ...data, [field]: value });
  };

  const securityQuestions = [
    { key: "hasBeenDeported", label: "Você já foi deportado de algum país?" },
    { key: "hasCriminalRecord", label: "Você possui antecedentes criminais?" },
    { key: "hasInfectiousDisease", label: "Você possui alguma doença infectocontagiosa?" },
    { key: "hasDrugHistory", label: "Você já foi envolvido com tráfico ou uso de drogas?" },
    { key: "hasBeenDeniedVisa", label: "Você já teve um visto negado anteriormente?" }
  ];

  const extractedFields = [
    { key: "fullName", label: "Nome Completo" },
    { key: "cpf", label: "CPF" },
    { key: "birthDate", label: "Data de Nascimento" },
    { key: "passportNumber", label: "Número do Passaporte" },
    { key: "nationality", label: "Nacionalidade" }
  ];

  return (
    <div className="space-y-6">
      {/* Dados extraídos (colapsável) */}
      <div className="rounded-lg border border-gray-200 bg-white">
        <button
          type="button"
          onClick={() => setShowExtracted(!showExtracted)}
          className="flex w-full items-center justify-between p-4"
        >
          <div className="flex items-center gap-2">
            <Check className="h-5 w-5 text-[#2BA84A]" />
            <span
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "16px",
                fontWeight: 600,
                color: "#0A4B9E"
              }}
            >
              Dados já extraídos
            </span>
          </div>
          {showExtracted ? (
            <ChevronUp className="h-5 w-5 text-gray-400" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-400" />
          )}
        </button>

        {showExtracted && (
          <div className="border-t border-gray-200 p-4">
            <div className="grid grid-cols-2 gap-4">
              {extractedFields.map((field) => (
                <div key={field.key}>
                  <p
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "11px",
                      fontWeight: 500,
                      color: "#666",
                      marginBottom: "4px"
                    }}
                  >
                    {field.label}
                  </p>
                  <p
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      fontWeight: 600,
                      color: "#333"
                    }}
                  >
                    {data.extractedData[field.key as keyof typeof data.extractedData] || "—"}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Informações pessoais adicionais */}
      <div>
        <h3
          style={{
            fontFamily: "Poppins, sans-serif",
            fontSize: "18px",
            fontWeight: 600,
            color: "#0A4B9E",
            marginBottom: "16px"
          }}
        >
          Informações Pessoais
        </h3>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="birthCity">Cidade de Nascimento *</Label>
            <Input
              id="birthCity"
              value={data.birthCity}
              onChange={(e) => handleChange("birthCity", e.target.value)}
              placeholder="São Paulo"
              className={errors.birthCity ? "border-red-500" : ""}
            />
            {errors.birthCity && (
              <p className="mt-1 text-sm text-red-600">{errors.birthCity}</p>
            )}
          </div>

          <div>
            <Label htmlFor="birthCountry">País de Nascimento *</Label>
            <Input
              id="birthCountry"
              value={data.birthCountry}
              onChange={(e) => handleChange("birthCountry", e.target.value)}
              placeholder="Brasil"
              className={errors.birthCountry ? "border-red-500" : ""}
            />
            {errors.birthCountry && (
              <p className="mt-1 text-sm text-red-600">{errors.birthCountry}</p>
            )}
          </div>

          <div className="col-span-2">
            <Label htmlFor="fatherName">Nome do Pai *</Label>
            <Input
              id="fatherName"
              value={data.fatherName}
              onChange={(e) => handleChange("fatherName", e.target.value)}
              placeholder="Nome completo do pai"
              className={errors.fatherName ? "border-red-500" : ""}
            />
            {errors.fatherName && (
              <p className="mt-1 text-sm text-red-600">{errors.fatherName}</p>
            )}
          </div>

          <div className="col-span-2">
            <Label htmlFor="motherName">Nome da Mãe *</Label>
            <Input
              id="motherName"
              value={data.motherName}
              onChange={(e) => handleChange("motherName", e.target.value)}
              placeholder="Nome completo da mãe"
              className={errors.motherName ? "border-red-500" : ""}
            />
            {errors.motherName && (
              <p className="mt-1 text-sm text-red-600">{errors.motherName}</p>
            )}
          </div>
        </div>
      </div>

      {/* Informações profissionais */}
      <div>
        <h3
          style={{
            fontFamily: "Poppins, sans-serif",
            fontSize: "18px",
            fontWeight: 600,
            color: "#0A4B9E",
            marginBottom: "16px"
          }}
        >
          Informações Profissionais
        </h3>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="occupation">Ocupação/Profissão *</Label>
            <Input
              id="occupation"
              value={data.occupation}
              onChange={(e) => handleChange("occupation", e.target.value)}
              placeholder="Engenheiro, Médico, etc."
              className={errors.occupation ? "border-red-500" : ""}
            />
            {errors.occupation && (
              <p className="mt-1 text-sm text-red-600">{errors.occupation}</p>
            )}
          </div>

          <div>
            <Label htmlFor="employer">Empregador *</Label>
            <Input
              id="employer"
              value={data.employer}
              onChange={(e) => handleChange("employer", e.target.value)}
              placeholder="Nome da empresa"
              className={errors.employer ? "border-red-500" : ""}
            />
            {errors.employer && (
              <p className="mt-1 text-sm text-red-600">{errors.employer}</p>
            )}
          </div>
        </div>
      </div>

      {/* Informações de viagem */}
      <div>
        <h3
          style={{
            fontFamily: "Poppins, sans-serif",
            fontSize: "18px",
            fontWeight: 600,
            color: "#0A4B9E",
            marginBottom: "16px"
          }}
        >
          Informações de Viagem
        </h3>

        <div className="space-y-4">
          <div>
            <Label htmlFor="travelPurpose">Propósito da Viagem *</Label>
            <Input
              id="travelPurpose"
              value={data.travelPurpose}
              onChange={(e) => handleChange("travelPurpose", e.target.value)}
              placeholder="Turismo, Negócios, Estudos, etc."
              className={errors.travelPurpose ? "border-red-500" : ""}
            />
            {errors.travelPurpose && (
              <p className="mt-1 text-sm text-red-600">{errors.travelPurpose}</p>
            )}
          </div>

          <div>
            <Label htmlFor="stayDuration">Duração da Estadia *</Label>
            <Input
              id="stayDuration"
              value={data.stayDuration}
              onChange={(e) => handleChange("stayDuration", e.target.value)}
              placeholder="15 dias, 1 mês, etc."
              className={errors.stayDuration ? "border-red-500" : ""}
            />
            {errors.stayDuration && (
              <p className="mt-1 text-sm text-red-600">{errors.stayDuration}</p>
            )}
          </div>

          <div>
            <Label htmlFor="usContact">Contato nos EUA *</Label>
            <Input
              id="usContact"
              value={data.usContact}
              onChange={(e) => handleChange("usContact", e.target.value)}
              placeholder="Nome e telefone de contato"
              className={errors.usContact ? "border-red-500" : ""}
            />
            {errors.usContact && (
              <p className="mt-1 text-sm text-red-600">{errors.usContact}</p>
            )}
          </div>

          <div>
            <Label htmlFor="usAddress">Endereço nos EUA *</Label>
            <Input
              id="usAddress"
              value={data.usAddress}
              onChange={(e) => handleChange("usAddress", e.target.value)}
              placeholder="Endereço completo de hospedagem"
              className={errors.usAddress ? "border-red-500" : ""}
            />
            {errors.usAddress && (
              <p className="mt-1 text-sm text-red-600">{errors.usAddress}</p>
            )}
          </div>
        </div>
      </div>

      {/* Questões de segurança */}
      <div>
        <h3
          style={{
            fontFamily: "Poppins, sans-serif",
            fontSize: "18px",
            fontWeight: 600,
            color: "#0A4B9E",
            marginBottom: "8px"
          }}
        >
          Questões de Segurança
        </h3>
        <p
          className="mb-4"
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "13px",
            color: "#666"
          }}
        >
          Por padrão, todas as respostas estão marcadas como "NÃO". Marque a caixa apenas se a resposta for "SIM".
        </p>

        <div className="space-y-3">
          {securityQuestions.map((question) => (
            <div
              key={question.key}
              className="flex items-start gap-3 rounded-lg border border-gray-200 bg-gray-50 p-3"
            >
              <Checkbox
                id={question.key}
                checked={data[question.key as keyof QuestionnaireData] as boolean}
                onCheckedChange={(checked) =>
                  handleChange(question.key, checked === true)
                }
              />
              <Label
                htmlFor={question.key}
                className="cursor-pointer"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 400,
                  color: "#333"
                }}
              >
                {question.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Aviso final */}
      <div className="rounded-lg border border-yellow-200 bg-yellow-50 p-4">
        <p
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "13px",
            fontWeight: 500,
            color: "#92400E"
          }}
        >
          ⚠️ Certifique-se de que todas as informações estão corretas. Declarações falsas podem resultar na negação permanente do visto.
        </p>
      </div>
    </div>
  );
}
