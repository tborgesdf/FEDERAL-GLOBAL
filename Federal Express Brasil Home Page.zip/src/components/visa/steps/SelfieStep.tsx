import { useState, useRef, useEffect } from "react";
import { Camera, Upload, Check, X, AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "../../ui/button";

interface QualityCheck {
  lighting: "good" | "poor" | "neutral";
  face: "centered" | "off-center" | "not-detected";
  eyes: "open" | "closed" | "unclear";
  blur: "sharp" | "blurry";
}

interface SelfieData {
  file: File | null;
  quality: QualityCheck | null;
  isApproved: boolean;
}

interface SelfieStepProps {
  data: SelfieData;
  onChange: (data: SelfieData) => void;
}

export default function SelfieStep({ data, onChange }: SelfieStepProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (data.file) {
      const url = URL.createObjectURL(data.file);
      setCapturedImage(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [data.file]);

  useEffect(() => {
    if (showCamera) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => stopCamera();
  }, [showCamera]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn("Camera access failed:", err.name);
      setCameraError("Não foi possível acessar a câmera. Verifique as permissões ou use o upload.");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const analyzeQuality = async (imageData: string): Promise<QualityCheck> => {
    // Simular análise de qualidade
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Simular análise (em produção, usar API de ML)
    const random = Math.random();
    return {
      lighting: random > 0.3 ? "good" : "poor",
      face: random > 0.2 ? "centered" : "off-center",
      eyes: random > 0.15 ? "open" : "closed",
      blur: random > 0.25 ? "sharp" : "blurry"
    };
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");

    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    canvas.toBlob(async (blob) => {
      if (!blob) return;

      const file = new File([blob], `selfie_${Date.now()}.jpg`, { type: "image/jpeg" });
      const imageUrl = URL.createObjectURL(blob);

      setCapturedImage(imageUrl);
      setShowCamera(false);
      setIsAnalyzing(true);

      const quality = await analyzeQuality(imageUrl);
      const isApproved = quality.lighting !== "poor" &&
                        quality.face === "centered" &&
                        quality.eyes === "open" &&
                        quality.blur === "sharp";

      onChange({ file, quality, isApproved });
      setIsAnalyzing(false);
    }, "image/jpeg", 0.9);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const imageUrl = URL.createObjectURL(file);
    setCapturedImage(imageUrl);
    setIsAnalyzing(true);

    const quality = await analyzeQuality(imageUrl);
    const isApproved = quality.lighting !== "poor" &&
                      quality.face === "centered" &&
                      quality.eyes === "open" &&
                      quality.blur === "sharp";

    onChange({ file, quality, isApproved });
    setIsAnalyzing(false);
    e.target.value = '';
  };

  const handleRetake = () => {
    setCapturedImage(null);
    onChange({ file: null, quality: null, isApproved: false });
    setShowCamera(true);
  };

  const getQualityMessage = (quality: QualityCheck): string[] => {
    const messages: string[] = [];

    if (quality.lighting === "poor") messages.push("Iluminação insuficiente - busque um local mais claro");
    if (quality.face === "off-center") messages.push("Rosto fora do centro - centralize seu rosto");
    if (quality.face === "not-detected") messages.push("Rosto não detectado - tente novamente");
    if (quality.eyes === "closed") messages.push("Olhos fechados - mantenha os olhos abertos");
    if (quality.blur === "blurry") messages.push("Imagem tremida - mantenha a câmera firme");

    return messages;
  };

  return (
    <div className="space-y-6">
      {/* Instruções */}
      <div className="rounded-lg border border-blue-100 bg-blue-50 p-4">
        <h4
          style={{
            fontFamily: "Poppins, sans-serif",
            fontSize: "14px",
            fontWeight: 600,
            color: "#0058CC",
            marginBottom: "8px"
          }}
        >
          📸 Instruções para a selfie
        </h4>
        <ul
          className="space-y-1"
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "13px",
            color: "#666"
          }}
        >
          <li>• Posicione seu rosto no centro da câmera</li>
          <li>• Certifique-se de que há boa iluminação</li>
          <li>• Mantenha os olhos abertos e olhe para a câmera</li>
          <li>• Remova óculos escuros ou acessórios que cubram o rosto</li>
          <li>• Mantenha uma expressão neutra</li>
        </ul>
      </div>

      {/* Preview da câmera */}
      {showCamera && !capturedImage && (
        <div className="space-y-4">
          <div className="relative overflow-hidden rounded-xl bg-black">
            {!cameraError ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full"
                  style={{ transform: "scaleX(-1)" }}
                />

                {/* Overlay de enquadramento */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div
                    className="rounded-full border-4 border-dashed border-white/50"
                    style={{
                      width: "60%",
                      paddingBottom: "60%",
                      maxWidth: "400px",
                      maxHeight: "400px"
                    }}
                  />
                </div>

                {/* Guia de posicionamento */}
                <div className="absolute bottom-4 left-0 right-0 text-center">
                  <p
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      fontWeight: 600,
                      color: "white",
                      textShadow: "0 2px 4px rgba(0,0,0,0.8)"
                    }}
                  >
                    Centralize seu rosto no círculo
                  </p>
                </div>
              </>
            ) : (
              <div className="flex min-h-[300px] items-center justify-center bg-gray-100 p-6 text-center">
                <div>
                  <AlertCircle className="mx-auto mb-3 h-12 w-12 text-red-500" />
                  <p
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "#666"
                    }}
                  >
                    {cameraError}
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              onClick={() => setShowCamera(false)}
              variant="outline"
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button
              type="button"
              onClick={capturePhoto}
              disabled={!!cameraError}
              className="flex-1 bg-[#0058CC] hover:bg-[#0A4B9E]"
            >
              <Camera className="mr-2 h-4 w-4" />
              Tirar foto
            </Button>
          </div>
        </div>
      )}

      {/* Imagem capturada com análise */}
      {capturedImage && !showCamera && (
        <div className="space-y-4">
          <div className="relative overflow-hidden rounded-xl border-2 border-gray-200">
            <img
              src={capturedImage}
              alt="Selfie"
              className="w-full"
              style={{ transform: "scaleX(-1)" }}
            />

            {/* Badge de status */}
            <div className="absolute right-3 top-3">
              {isAnalyzing ? (
                <div className="rounded-full bg-yellow-500 px-3 py-1.5">
                  <span
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      fontWeight: 600,
                      color: "white"
                    }}
                  >
                    Analisando...
                  </span>
                </div>
              ) : data.isApproved ? (
                <div className="flex items-center gap-1.5 rounded-full bg-[#2BA84A] px-3 py-1.5">
                  <Check className="h-3.5 w-3.5 text-white" />
                  <span
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      fontWeight: 600,
                      color: "white"
                    }}
                  >
                    Aprovada
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 rounded-full bg-red-500 px-3 py-1.5">
                  <X className="h-3.5 w-3.5 text-white" />
                  <span
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      fontWeight: 600,
                      color: "white"
                    }}
                  >
                    Reprovada
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Feedback de qualidade */}
          {data.quality && !isAnalyzing && (
            <div>
              {data.isApproved ? (
                <div className="rounded-lg border border-green-200 bg-green-50 p-4">
                  <div className="flex items-start gap-3">
                    <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-600" />
                    <div>
                      <p
                        style={{
                          fontFamily: "Poppins, sans-serif",
                          fontSize: "14px",
                          fontWeight: 600,
                          color: "#2BA84A"
                        }}
                      >
                        Selfie aprovada!
                      </p>
                      <p
                        className="mt-1"
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "13px",
                          color: "#666"
                        }}
                      >
                        Sua foto atende todos os requisitos de qualidade.
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border border-red-200 bg-red-50 p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-red-600" />
                    <div className="flex-1">
                      <p
                        style={{
                          fontFamily: "Poppins, sans-serif",
                          fontSize: "14px",
                          fontWeight: 600,
                          color: "#DC2626",
                          marginBottom: "8px"
                        }}
                      >
                        Selfie reprovada - Tire novamente
                      </p>
                      <ul className="space-y-1">
                        {getQualityMessage(data.quality).map((msg, idx) => (
                          <li
                            key={idx}
                            style={{
                              fontFamily: "Inter, sans-serif",
                              fontSize: "13px",
                              color: "#666"
                            }}
                          >
                            • {msg}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Botão de recaptura */}
          <Button
            type="button"
            onClick={handleRetake}
            variant="outline"
            className="w-full"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Tirar nova foto
          </Button>
        </div>
      )}

      {/* Botões iniciais */}
      {!capturedImage && !showCamera && (
        <div className="flex gap-3">
          <Button
            type="button"
            onClick={() => setShowCamera(true)}
            className="flex-1 bg-[#0058CC] hover:bg-[#0A4B9E]"
          >
            <Camera className="mr-2 h-4 w-4" />
            Abrir câmera
          </Button>

          {/* Hidden file input - moved outside label */}
          <input
            id="selfie-file-upload"
            type="file"
            accept="image/jpeg,image/jpg,image/png"
            onChange={handleFileUpload}
            className="hidden"
          />
          <label htmlFor="selfie-file-upload" className="flex-1">
            <div className="flex h-full cursor-pointer items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 transition-colors hover:bg-gray-50">
              <Upload className="mr-2 h-4 w-4" />
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 500
                }}
              >
                Upload
              </span>
            </div>
          </label>
        </div>
      )}

      {/* Canvas oculto para captura */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}