import { useState } from "react";
import { Camera, Upload, File, X, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "../ui/button";
import CameraModal from "./CameraModal";

interface OCRData {
  [key: string]: string;
}

interface DocumentCaptureProps {
  title: string;
  description?: string;
  onFileSelected: (file: File) => void;
  onOCRComplete?: (data: OCRData) => void;
  acceptedFormats?: string;
  ocrFields?: { key: string; label: string }[];
  showOCRReview?: boolean;
  capturedFile?: File | null;
  ocrData?: OCRData | null;
  isProcessing?: boolean;
}

export default function DocumentCapture({
  title,
  description,
  onFileSelected,
  onOCRComplete,
  acceptedFormats = "image/jpeg,image/jpg,image/png,application/pdf",
  ocrFields = [],
  showOCRReview = false,
  capturedFile = null,
  ocrData = null,
  isProcessing = false
}: DocumentCaptureProps) {
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [isOCRExpanded, setIsOCRExpanded] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelected(file);
    }
    e.target.value = '';
  };

  const handleCameraCapture = (blob: Blob) => {
    const file = new File([blob], `capture_${Date.now()}.jpg`, { type: "image/jpeg" });
    onFileSelected(file);
    setShowCameraModal(false);
  };

  const handleRemoveFile = () => {
    onFileSelected(null as any);
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith("image/")) {
      return URL.createObjectURL(file);
    }
    return null;
  };

  return (
    <div className="space-y-4">
      {/* Título e descrição */}
      <div>
        <h3
          style={{
            fontFamily: "Poppins, sans-serif",
            fontSize: "18px",
            fontWeight: 600,
            color: "#0A4B9E"
          }}
        >
          {title}
        </h3>
        {description && (
          <p
            className="mt-1"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "13px",
              fontWeight: 400,
              color: "#666"
            }}
          >
            {description}
          </p>
        )}
      </div>

      {/* Área de captura/upload */}
      {!capturedFile ? (
        <div className="flex gap-3">
          <Button
            type="button"
            onClick={() => setShowCameraModal(true)}
            variant="outline"
            className="flex-1 border-[#0058CC] text-[#0058CC] hover:bg-[#0058CC] hover:text-white"
          >
            <Camera className="mr-2 h-4 w-4" />
            Capturar com câmera
          </Button>

          {/* Hidden file input - moved outside label */}
          <input
            id={`file-upload-${title.replace(/\s+/g, '-').toLowerCase()}`}
            type="file"
            accept={acceptedFormats}
            onChange={handleFileChange}
            className="hidden"
          />
          <label 
            htmlFor={`file-upload-${title.replace(/\s+/g, '-').toLowerCase()}`}
            className="flex-1"
          >
            <div className="flex h-full cursor-pointer items-center justify-center rounded-md border border-gray-300 bg-white px-4 py-2 transition-colors hover:bg-gray-50">
              <Upload className="mr-2 h-4 w-4" />
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 500
                }}
              >
                Enviar arquivo
              </span>
            </div>
          </label>
        </div>
      ) : (
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          {/* Preview do arquivo */}
          <div className="flex items-start gap-4">
            {/* Thumbnail ou ícone */}
            <div className="flex h-20 w-20 flex-shrink-0 items-center justify-center overflow-hidden rounded-lg bg-gray-100">
              {getFileIcon(capturedFile) ? (
                <img
                  src={getFileIcon(capturedFile)!}
                  alt="Preview"
                  className="h-full w-full object-cover"
                />
              ) : (
                <File className="h-8 w-8 text-gray-400" />
              )}
            </div>

            {/* Info do arquivo */}
            <div className="flex-1">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "#333"
                }}
              >
                {capturedFile.name}
              </p>
              <p
                className="mt-1"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "12px",
                  fontWeight: 400,
                  color: "#666"
                }}
              >
                {(capturedFile.size / 1024).toFixed(2)} KB
              </p>

              {isProcessing && (
                <div className="mt-2 flex items-center gap-2 text-[#0058CC]">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      fontWeight: 500
                    }}
                  >
                    Processando documento...
                  </span>
                </div>
              )}
            </div>

            {/* Botão remover */}
            <button
              type="button"
              onClick={handleRemoveFile}
              className="rounded-full p-1 hover:bg-red-50"
            >
              <X className="h-5 w-5 text-red-600" />
            </button>
          </div>

          {/* Revisão OCR */}
          {showOCRReview && ocrData && ocrFields.length > 0 && !isProcessing && (
            <div className="mt-4 border-t border-gray-200 pt-4">
              <button
                type="button"
                onClick={() => setIsOCRExpanded(!isOCRExpanded)}
                className="flex w-full items-center justify-between text-left"
              >
                <span
                  style={{
                    fontFamily: "Poppins, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "#0A4B9E"
                  }}
                >
                  📋 Dados extraídos
                </span>
                {isOCRExpanded ? (
                  <ChevronUp className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                )}
              </button>

              {isOCRExpanded && (
                <div className="mt-3 grid grid-cols-2 gap-3">
                  {ocrFields.map((field) => (
                    <div key={field.key}>
                      <p
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "11px",
                          fontWeight: 500,
                          color: "#666"
                        }}
                      >
                        {field.label}
                      </p>
                      <p
                        className="mt-1"
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "13px",
                          fontWeight: 600,
                          color: "#333"
                        }}
                      >
                        {ocrData[field.key] || "—"}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Modal de câmera */}
      <CameraModal
        isOpen={showCameraModal}
        onClose={() => setShowCameraModal(false)}
        onCapture={handleCameraCapture}
        title={title}
      />
    </div>
  );
}