import { FileText, ArrowLeft } from "lucide-react";

interface StepQuestionnaireProps {
  onComplete: () => void;
}

export default function StepQuestionnaire({ onComplete }: StepQuestionnaireProps) {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#2BA84A]/10 flex items-center justify-center flex-shrink-0">
            <FileText className="w-6 h-6 text-[#2BA84A]" />
          </div>
          <div className="flex-1">
            <h2
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "24px",
                fontWeight: 600,
                color: "#1F2937",
                marginBottom: "8px"
              }}
            >
              Questionário complementar
            </h2>
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#6B7280",
                lineHeight: "1.6"
              }}
            >
              Esta etapa está sendo preparada e ficará disponível em breve.
            </p>
          </div>
        </div>

        {/* Placeholder Content */}
        <div className="space-y-6">
          {/* Info Card */}
          <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center flex-shrink-0 shadow-sm">
                <FileText className="w-6 h-6 text-[#0058CC]" />
              </div>
              <div className="flex-1">
                <h3
                  style={{
                    fontFamily: "Poppins, sans-serif",
                    fontSize: "18px",
                    fontWeight: 600,
                    color: "#1F2937",
                    marginBottom: "8px"
                  }}
                >
                  Próximos passos
                </h3>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "#374151",
                    lineHeight: "1.6",
                    marginBottom: "12px"
                  }}
                >
                  O questionário complementar incluirá perguntas sobre:
                </p>
                <ul className="space-y-2">
                  {[
                    "Histórico de viagens internacionais",
                    "Informações profissionais e acadêmicas",
                    "Dados de contato de emergência",
                    "Informações sobre sua viagem planejada",
                    "Perguntas de segurança padrão do consulado"
                  ].map((item, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-2"
                    >
                      <span className="text-[#0058CC] mt-1">•</span>
                      <span
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px",
                          color: "#374151",
                          lineHeight: "1.6"
                        }}
                      >
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Status Card */}
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#166534",
                lineHeight: "1.6"
              }}
            >
              <strong>Documentos salvos com sucesso!</strong><br />
              Todos os documentos que você enviou foram salvos e estão seguros. 
              Você poderá retornar para completar o questionário assim que estiver disponível.
            </p>
          </div>

          {/* Next Steps */}
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#1E40AF",
                lineHeight: "1.6"
              }}
            >
              <strong>O que acontece agora?</strong><br />
              Você será redirecionado ao Dashboard onde poderá acompanhar o status da sua solicitação. 
              Enviaremos um e-mail quando o questionário estiver disponível para preenchimento.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-8 flex gap-3">
          <button
            onClick={onComplete}
            className="flex-1 px-6 py-3 rounded-lg transition-colors"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "16px",
              fontWeight: 600,
              backgroundColor: "#2BA84A",
              color: "#FFFFFF"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "#248A3D";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "#2BA84A";
            }}
          >
            Concluir e voltar ao Dashboard
          </button>
        </div>

        {/* Help Text */}
        <p
          className="mt-4 text-center"
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "13px",
            color: "#6B7280",
            lineHeight: "1.5"
          }}
        >
          Sua solicitação ficará com status "Em análise" até que todos os documentos sejam verificados
        </p>
      </div>
    </div>
  );
}
