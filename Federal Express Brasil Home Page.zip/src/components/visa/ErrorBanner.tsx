import { AlertTriangle, X, Info, CheckCircle } from "lucide-react";

interface ErrorBannerProps {
  type: "error" | "warning" | "info" | "success";
  message: string;
  onDismiss?: () => void;
}

export default function ErrorBanner({ type, message, onDismiss }: ErrorBannerProps) {
  const config = {
    error: {
      icon: AlertTriangle,
      bgColor: "#FEF2F2",
      borderColor: "#FCA5A5",
      textColor: "#991B1B",
      iconColor: "#DC2626"
    },
    warning: {
      icon: AlertTriangle,
      bgColor: "#FFFBEB",
      borderColor: "#FCD34D",
      textColor: "#92400E",
      iconColor: "#F59E0B"
    },
    info: {
      icon: Info,
      bgColor: "#EFF6FF",
      borderColor: "#93C5FD",
      textColor: "#1E40AF",
      iconColor: "#3B82F6"
    },
    success: {
      icon: CheckCircle,
      bgColor: "#F0FDF4",
      borderColor: "#86EFAC",
      textColor: "#166534",
      iconColor: "#22C55E"
    }
  };

  const { icon: Icon, bgColor, borderColor, textColor, iconColor } = config[type];

  return (
    <div
      className="flex items-start gap-3 p-4 rounded-lg border"
      style={{
        backgroundColor: bgColor,
        borderColor: borderColor
      }}
      role="alert"
    >
      <Icon className="flex-shrink-0 w-5 h-5 mt-0.5" style={{ color: iconColor }} />
      <p
        className="flex-1"
        style={{
          fontFamily: "Inter, sans-serif",
          fontSize: "14px",
          color: textColor,
          lineHeight: "1.5"
        }}
      >
        {message}
      </p>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="flex-shrink-0 p-1 hover:opacity-70 transition-opacity"
          aria-label="Fechar"
        >
          <X className="w-4 h-4" style={{ color: textColor }} />
        </button>
      )}
    </div>
  );
}
