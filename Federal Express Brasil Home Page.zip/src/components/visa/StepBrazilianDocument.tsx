import { useState } from "react";
import { CreditCard, Eye } from "lucide-react";
import DocumentUpload from "./DocumentUpload";
import OCRPreviewCard from "./OCRPreviewCard";
import ErrorBanner from "./ErrorBanner";

interface StepBrazilianDocumentProps {
  onNext: (data: any) => void;
}

export default function StepBrazilianDocument({ onNext }: StepBrazilianDocumentProps) {
  const [documentType, setDocumentType] = useState<string>("");
  const [frontFile, setFrontFile] = useState<File | null>(null);
  const [backFile, setBackFile] = useState<File | null>(null);
  const [frontPreviewUrl, setFrontPreviewUrl] = useState<string>("");
  const [backPreviewUrl, setBackPreviewUrl] = useState<string>("");
  const [isProcessingFront, setIsProcessingFront] = useState(false);
  const [isProcessingBack, setIsProcessingBack] = useState(false);
  const [showFrontPreview, setShowFrontPreview] = useState(false);
  const [showBackPreview, setShowBackPreview] = useState(false);
  const [frontConfirmed, setFrontConfirmed] = useState(false);
  const [backConfirmed, setBackConfirmed] = useState(false);
  const [showExample, setShowExample] = useState(false);

  const documentTypes = [
    { value: "cnh", label: "CNH - Carteira Nacional de Habilitação" },
    { value: "cnh_digital", label: "CNH Digital" },
    { value: "rg", label: "RG - Registro Geral" },
    { value: "cin", label: "CIN - Carteira de Identidade Nacional" }
  ];

  const handleFrontFileSelected = (file: File) => {
    setFrontFile(file);
    const url = URL.createObjectURL(file);
    setFrontPreviewUrl(url);
    setShowFrontPreview(true);
    setIsProcessingFront(true);

    setTimeout(() => {
      setIsProcessingFront(false);
    }, 2000);
  };

  const handleBackFileSelected = (file: File) => {
    setBackFile(file);
    const url = URL.createObjectURL(file);
    setBackPreviewUrl(url);
    setShowBackPreview(true);
    setIsProcessingBack(true);

    setTimeout(() => {
      setIsProcessingBack(false);
    }, 2000);
  };

  const handleFrontConfirm = (fields: any) => {
    setFrontConfirmed(true);
    setShowFrontPreview(false);
  };

  const handleBackConfirm = (fields: any) => {
    setBackConfirmed(true);
    setShowBackPreview(false);
  };

  const handleNext = () => {
    const needsBack = documentType !== "cnh_digital";
    if ((needsBack && frontConfirmed && backConfirmed) || (!needsBack && frontConfirmed)) {
      onNext({
        documentType,
        frontFile,
        backFile
      });
    }
  };

  const canProceed = () => {
    if (!documentType) return false;
    if (documentType === "cnh_digital") return frontConfirmed;
    return frontConfirmed && backConfirmed;
  };

  const mockFrontFields = [
    { label: "Nome completo", value: "JOÃO DA SILVA SANTOS", editable: true },
    { label: "CPF", value: "123.456.789-00", editable: true },
    { label: "RG/CNH", value: "12.345.678-9", editable: true },
    { label: "Data de nascimento", value: "15/03/1990", editable: true },
    { label: "Filiação", value: "MARIA SANTOS", editable: true }
  ];

  const mockBackFields = [
    { label: "Data de emissão", value: "10/01/2020", editable: true },
    { label: "Órgão emissor", value: "SSP/SP", editable: true }
  ];

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#0058CC]/10 flex items-center justify-center flex-shrink-0">
            <CreditCard className="w-6 h-6 text-[#0058CC]" />
          </div>
          <div className="flex-1">
            <h2
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "24px",
                fontWeight: 600,
                color: "#1F2937",
                marginBottom: "8px"
              }}
            >
              Documento brasileiro
            </h2>
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#6B7280",
                lineHeight: "1.6"
              }}
            >
              Envie fotos da frente e verso do seu documento de identificação brasileiro válido.
            </p>
          </div>
        </div>

        {/* Document Type Selection */}
        <div className="space-y-4 mb-6">
          <label
            htmlFor="document-type"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "14px",
              fontWeight: 600,
              color: "#1F2937"
            }}
          >
            Tipo de documento *
          </label>
          <select
            id="document-type"
            value={documentType}
            onChange={(e) => {
              setDocumentType(e.target.value);
              // Reset states when changing document type
              setFrontConfirmed(false);
              setBackConfirmed(false);
              setShowFrontPreview(false);
              setShowBackPreview(false);
            }}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0058CC] focus:border-transparent"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "14px"
            }}
          >
            <option value="">Selecione o tipo de documento</option>
            {documentTypes.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>

        {/* Example Link */}
        {documentType && (
          <div className="mb-6">
            <button
              onClick={() => setShowExample(!showExample)}
              className="flex items-center gap-2 text-[#0058CC] hover:text-[#0A4B9E] transition-colors"
            >
              <Eye className="w-4 h-4" />
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 500
                }}
              >
                {showExample ? "Ocultar exemplo" : "Ver exemplo de foto"}
              </span>
            </button>

            {showExample && (
              <div className="mt-3 p-4 bg-gray-50 rounded-lg border">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=400&q=80"
                      alt="Exemplo frente"
                      className="w-full rounded-lg"
                    />
                    <p
                      className="mt-2 text-center"
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "13px",
                        color: "#6B7280"
                      }}
                    >
                      Frente
                    </p>
                  </div>
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1633613286991-611fe299c4be?w=400&q=80"
                      alt="Exemplo verso"
                      className="w-full rounded-lg"
                    />
                    <p
                      className="mt-2 text-center"
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "13px",
                        color: "#6B7280"
                      }}
                    >
                      Verso
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Upload Sections */}
        {documentType && (
          <div className="space-y-6">
            {/* Front */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3
                  style={{
                    fontFamily: "Poppins, sans-serif",
                    fontSize: "16px",
                    fontWeight: 600,
                    color: "#1F2937"
                  }}
                >
                  Frente do documento
                </h3>
                {frontConfirmed && (
                  <span
                    className="px-3 py-1 bg-green-100 text-green-700 rounded-full"
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "12px",
                      fontWeight: 600
                    }}
                  >
                    ✓ Confirmado
                  </span>
                )}
              </div>

              {!showFrontPreview && !frontConfirmed ? (
                <DocumentUpload
                  documentType={`${documentType} - Frente`}
                  onFileSelected={handleFrontFileSelected}
                  showCameraOption={documentType !== "cnh_digital"}
                />
              ) : showFrontPreview ? (
                <OCRPreviewCard
                  imageUrl={frontPreviewUrl}
                  fields={mockFrontFields}
                  isProcessing={isProcessingFront}
                  onConfirm={handleFrontConfirm}
                  onCancel={() => {
                    setShowFrontPreview(false);
                    setFrontFile(null);
                  }}
                />
              ) : (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-center justify-between">
                  <p
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "#166534"
                    }}
                  >
                    Frente do documento salva com sucesso
                  </p>
                  <button
                    onClick={() => {
                      setFrontConfirmed(false);
                      setFrontFile(null);
                    }}
                    className="text-[#0058CC] hover:text-[#0A4B9E]"
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "13px",
                      fontWeight: 600
                    }}
                  >
                    Enviar novamente
                  </button>
                </div>
              )}
            </div>

            {/* Back (conditional) */}
            {documentType !== "cnh_digital" && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3
                    style={{
                      fontFamily: "Poppins, sans-serif",
                      fontSize: "16px",
                      fontWeight: 600,
                      color: "#1F2937"
                    }}
                  >
                    Verso do documento
                  </h3>
                  {backConfirmed && (
                    <span
                      className="px-3 py-1 bg-green-100 text-green-700 rounded-full"
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "12px",
                        fontWeight: 600
                      }}
                    >
                      ✓ Confirmado
                    </span>
                  )}
                </div>

                {!showBackPreview && !backConfirmed ? (
                  <DocumentUpload
                    documentType={`${documentType} - Verso`}
                    onFileSelected={handleBackFileSelected}
                    showCameraOption={true}
                  />
                ) : showBackPreview ? (
                  <OCRPreviewCard
                    imageUrl={backPreviewUrl}
                    fields={mockBackFields}
                    isProcessing={isProcessingBack}
                    onConfirm={handleBackConfirm}
                    onCancel={() => {
                      setShowBackPreview(false);
                      setBackFile(null);
                    }}
                  />
                ) : (
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-center justify-between">
                    <p
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px",
                        color: "#166534"
                      }}
                    >
                      Verso do documento salvo com sucesso
                    </p>
                    <button
                      onClick={() => {
                        setBackConfirmed(false);
                        setBackFile(null);
                      }}
                      className="text-[#0058CC] hover:text-[#0A4B9E]"
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "13px",
                        fontWeight: 600
                      }}
                    >
                      Enviar novamente
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="mt-8 flex justify-end">
          <button
            onClick={handleNext}
            disabled={!canProceed()}
            className="px-6 py-3 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "16px",
              fontWeight: 600,
              backgroundColor: canProceed() ? "#0058CC" : "#D1D5DB",
              color: "#FFFFFF",
              minWidth: "140px"
            }}
            onMouseEnter={(e) => {
              if (canProceed()) {
                e.currentTarget.style.backgroundColor = "#0A4B9E";
              }
            }}
            onMouseLeave={(e) => {
              if (canProceed()) {
                e.currentTarget.style.backgroundColor = "#0058CC";
              }
            }}
          >
            Próximo
          </button>
        </div>
      </div>
    </div>
  );
}
