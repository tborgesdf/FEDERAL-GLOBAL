import { Check } from "lucide-react";

interface Step {
  id: string;
  label: string;
  optional?: boolean;
}

interface ProgressStepperProps {
  steps: Step[];
  currentStep: number;
  completedSteps: number[];
}

export default function ProgressStepper({ steps, currentStep, completedSteps }: ProgressStepperProps) {
  return (
    <div 
      className="sticky bg-white border-b shadow-sm"
      style={{ 
        top: "64px", // Header height
        zIndex: 40
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between gap-2 overflow-x-auto">
          {steps.map((step, index) => {
            const isCompleted = completedSteps.includes(index);
            const isCurrent = currentStep === index;
            const isUpcoming = index > currentStep;

            return (
              <div key={step.id} className="flex items-center flex-shrink-0">
                <div className="flex flex-col items-center gap-2 min-w-[80px] sm:min-w-[120px]">
                  {/* Circle */}
                  <div
                    className={`
                      w-8 h-8 rounded-full flex items-center justify-center transition-all
                      ${isCompleted ? "bg-[#2BA84A]" : ""}
                      ${isCurrent ? "bg-[#0058CC] ring-4 ring-[#0058CC]/20" : ""}
                      ${isUpcoming ? "bg-gray-200" : ""}
                    `}
                  >
                    {isCompleted ? (
                      <Check className="w-5 h-5 text-white" />
                    ) : (
                      <span
                        className={`
                          ${isCurrent ? "text-white" : ""}
                          ${isUpcoming ? "text-gray-500" : ""}
                        `}
                        style={{ 
                          fontFamily: "Poppins, sans-serif",
                          fontSize: "14px",
                          fontWeight: 600 
                        }}
                      >
                        {index + 1}
                      </span>
                    )}
                  </div>

                  {/* Label */}
                  <span
                    className={`
                      text-center text-xs sm:text-sm
                      ${isCurrent ? "text-[#0058CC]" : ""}
                      ${isCompleted ? "text-[#2BA84A]" : ""}
                      ${isUpcoming ? "text-gray-500" : ""}
                    `}
                    style={{ 
                      fontFamily: "Inter, sans-serif",
                      fontWeight: isCurrent ? 600 : 400
                    }}
                  >
                    {step.label}
                  </span>
                </div>

                {/* Connector line */}
                {index < steps.length - 1 && (
                  <div
                    className={`
                      h-0.5 w-8 sm:w-16 mx-1
                      ${isCompleted ? "bg-[#2BA84A]" : "bg-gray-200"}
                    `}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
