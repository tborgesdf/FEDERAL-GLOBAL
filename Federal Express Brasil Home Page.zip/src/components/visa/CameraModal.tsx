import { useState, useRef, useEffect } from "react";
import { X, Camera, RotateCcw, AlertCircle } from "lucide-react";

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (file: File) => void;
  title?: string;
  facingMode?: "user" | "environment";
}

export default function CameraModal({
  isOpen,
  onClose,
  onCapture,
  title = "Capturar foto",
  facingMode = "environment"
}: CameraModalProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [permissionStatus, setPermissionStatus] = useState<"prompt" | "granted" | "denied" | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (isOpen) {
      checkPermissions();
    } else {
      stopCamera();
      setCapturedImage(null);
      setError(null);
      setPermissionStatus(null);
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const checkPermissions = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Check if Permissions API is available
      if ('permissions' in navigator) {
        try {
          const result = await navigator.permissions.query({ name: 'camera' as PermissionName });
          setPermissionStatus(result.state);
          
          if (result.state === 'granted') {
            // Permission already granted, start camera
            startCamera();
          } else if (result.state === 'denied') {
            // Permission denied, show error
            setError("Permissão para acessar a câmera foi negada anteriormente. Clique no ícone de câmera na barra de endereços do navegador e permita o acesso, depois recarregue a página.");
            setIsLoading(false);
          } else {
            // Permission prompt - will ask when we try to access
            startCamera();
          }
        } catch (permError) {
          // Permissions API failed, try to start camera anyway
          console.warn("Permissions API not supported, trying to start camera directly");
          startCamera();
        }
      } else {
        // Permissions API not available, try to start camera
        startCamera();
      }
    } catch (err) {
      console.warn("Error checking permissions:", err);
      startCamera();
    }
  };

  const startCamera = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Check if we're in a secure context
      if (!window.isSecureContext) {
        throw new Error("SecurityError: Camera access requires HTTPS");
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setIsLoading(false);
    } catch (err: any) {
      // Only log warning instead of error to avoid console clutter
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        console.warn("Camera permission denied by user");
      } else {
        console.warn("Camera access failed:", err.name);
      }
      
      // Provide specific error messages based on error type
      let errorMessage = "Não foi possível acessar a câmera.";
      
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        errorMessage = "Permissão negada. Por favor, clique em 'Permitir' quando o navegador solicitar acesso à câmera.";
      } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
        errorMessage = "Nenhuma câmera encontrada. Verifique se seu dispositivo possui uma câmera conectada.";
      } else if (err.name === "NotReadableError" || err.name === "TrackStartError") {
        errorMessage = "A câmera está sendo usada por outro aplicativo. Feche outros aplicativos que possam estar usando a câmera.";
      } else if (err.name === "OverconstrainedError" || err.name === "ConstraintNotSatisfiedError") {
        errorMessage = "Não foi possível iniciar a câmera com as configurações solicitadas. Tente usar o upload de arquivo.";
      } else if (err.name === "SecurityError" || err.message.includes("SecurityError")) {
        errorMessage = "Acesso à câmera bloqueado por questões de segurança. A página precisa usar HTTPS para acessar a câmera.";
      } else if (err.message.includes("Permission") || err.message.includes("policy")) {
        errorMessage = "O acesso à câmera foi bloqueado pelas configurações de segurança do navegador ou do site. Use o botão 'Fechar e usar upload' para enviar uma foto do seu dispositivo.";
      }
      
      setError(errorMessage);
      setIsLoading(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");

    if (!context) return;

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw the current video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Convert canvas to blob
    canvas.toBlob((blob) => {
      if (blob) {
        const imageUrl = canvas.toDataURL("image/jpeg", 0.9);
        setCapturedImage(imageUrl);
      }
    }, "image/jpeg", 0.9);
  };

  const confirmCapture = () => {
    if (!canvasRef.current || !capturedImage) return;

    canvasRef.current.toBlob((blob) => {
      if (blob) {
        const file = new File([blob], `photo_${Date.now()}.jpg`, { type: "image/jpeg" });
        onCapture(file);
        stopCamera();
        onClose();
      }
    }, "image/jpeg", 0.9);
  };

  const retakePhoto = () => {
    setCapturedImage(null);
  };

  const handleClose = () => {
    stopCamera();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <div className="relative w-full max-w-4xl bg-white rounded-lg overflow-hidden shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-white">
          <h3
            style={{
              fontFamily: "Poppins, sans-serif",
              fontSize: "18px",
              fontWeight: 600,
              color: "#1F2937"
            }}
          >
            {title}
          </h3>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Camera View */}
        <div className="relative bg-black" style={{ minHeight: "400px" }}>
          {error ? (
            <div className="flex flex-col items-center justify-center h-96 p-6 text-center">
              <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "16px",
                  color: "#DC2626",
                  marginBottom: "8px",
                  fontWeight: 600
                }}
              >
                Não foi possível acessar a câmera
              </p>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#6B7280",
                  marginBottom: "16px",
                  maxWidth: "400px"
                }}
              >
                {error}
              </p>
              
              {/* Instructions based on browser */}
              <div className="bg-blue-50 p-4 rounded-lg mb-4 max-w-md">
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "13px",
                    color: "#1E40AF",
                    marginBottom: "8px",
                    fontWeight: 600
                  }}
                >
                  Como permitir o acesso:
                </p>
                <ul
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "12px",
                    color: "#1E40AF",
                    textAlign: "left",
                    lineHeight: "1.6"
                  }}
                  className="space-y-1"
                >
                  <li>• Clique no ícone de cadeado/câmera na barra de endereços</li>
                  <li>• Selecione "Permitir" para a câmera</li>
                  <li>• Recarregue a página e tente novamente</li>
                </ul>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={startCamera}
                  className="px-6 py-2 bg-[#0058CC] text-white rounded-lg hover:bg-[#0A4B9E] transition-colors"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600
                  }}
                >
                  Tentar novamente
                </button>
                <button
                  onClick={handleClose}
                  className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600
                  }}
                >
                  Fechar e usar upload
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Video Preview */}
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-auto"
                style={{
                  display: capturedImage ? "none" : "block",
                  maxHeight: "70vh",
                  objectFit: "contain"
                }}
              />

              {/* Captured Image Preview */}
              {capturedImage && (
                <img
                  src={capturedImage}
                  alt="Captured"
                  className="w-full h-auto"
                  style={{
                    maxHeight: "70vh",
                    objectFit: "contain"
                  }}
                />
              )}

              {/* Hidden Canvas */}
              <canvas ref={canvasRef} className="hidden" />

              {/* Loading Overlay */}
              {isLoading && !error && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                  <div className="text-center">
                    <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                    <p
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px",
                        color: "#FFFFFF"
                      }}
                    >
                      Iniciando câmera...
                    </p>
                  </div>
                </div>
              )}

              {/* Camera Guide Overlay */}
              {!capturedImage && !isLoading && (
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute inset-4 border-2 border-white/30 rounded-lg" />
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="bg-black/50 text-white px-4 py-2 rounded-lg text-center">
                      <p
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "13px"
                        }}
                      >
                        Centralize o documento no quadro
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer / Actions */}
        {!error && (
          <div className="p-4 bg-gray-50 border-t">
            {capturedImage ? (
              <div className="flex gap-3 justify-center">
                <button
                  onClick={retakePhoto}
                  className="flex items-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "15px",
                    fontWeight: 600
                  }}
                >
                  <RotateCcw className="w-4 h-4" />
                  Tirar outra
                </button>
                <button
                  onClick={confirmCapture}
                  className="flex items-center gap-2 px-6 py-3 bg-[#2BA84A] text-white rounded-lg hover:bg-[#248a3d] transition-colors"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "15px",
                    fontWeight: 600
                  }}
                >
                  <Camera className="w-4 h-4" />
                  Usar esta foto
                </button>
              </div>
            ) : (
              <div className="flex justify-center">
                <button
                  onClick={capturePhoto}
                  disabled={isLoading}
                  className="flex items-center gap-2 px-8 py-4 bg-[#0058CC] text-white rounded-lg hover:bg-[#0A4B9E] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "16px",
                    fontWeight: 600
                  }}
                >
                  <Camera className="w-5 h-5" />
                  Capturar foto
                </button>
              </div>
            )}

            <p
              className="text-center mt-3"
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "12px",
                color: "#6B7280"
              }}
            >
              {capturedImage 
                ? "Revise a foto antes de confirmar"
                : "Certifique-se de que o documento está legível e bem iluminado"
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}