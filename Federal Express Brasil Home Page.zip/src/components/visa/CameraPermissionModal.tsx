import { Camera, FileImage, X } from "lucide-react";

interface CameraPermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export default function CameraPermissionModal({ isOpen, onClose, onConfirm }: CameraPermissionModalProps) {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-lg shadow-2xl max-w-md w-full p-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#0058CC]/10 flex items-center justify-center">
              <Camera className="w-6 h-6 text-[#0058CC]" />
            </div>
            <div>
              <h3
                style={{
                  fontFamily: "Poppins, sans-serif",
                  fontSize: "18px",
                  fontWeight: 600,
                  color: "#1F2937"
                }}
              >
                Permissões necessárias
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
            aria-label="Fechar"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4 mb-6">
          <p
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "14px",
              color: "#4B5563",
              lineHeight: "1.6"
            }}
          >
            Para prosseguir com o envio de documentos, precisamos de permissão para:
          </p>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <Camera className="w-5 h-5 text-[#0058CC] flex-shrink-0 mt-0.5" />
              <div>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "#1F2937"
                  }}
                >
                  Acessar sua câmera
                </p>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "13px",
                    color: "#6B7280",
                    lineHeight: "1.5"
                  }}
                >
                  Para capturar fotos dos seus documentos diretamente
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <FileImage className="w-5 h-5 text-[#0058CC] flex-shrink-0 mt-0.5" />
              <div>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "#1F2937"
                  }}
                >
                  Acessar seus arquivos
                </p>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "13px",
                    color: "#6B7280",
                    lineHeight: "1.5"
                  }}
                >
                  Para fazer upload de documentos salvos no dispositivo
                </p>
              </div>
            </div>
          </div>

          <div
            className="p-3 bg-blue-50 border border-blue-200 rounded-lg"
          >
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "13px",
                color: "#1E40AF",
                lineHeight: "1.5"
              }}
            >
              <strong>Importante:</strong> Suas informações são criptografadas e protegidas. Utilizamos esses dados apenas para processar sua solicitação de visto.
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "14px",
              fontWeight: 600,
              color: "#374151"
            }}
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 px-4 py-3 rounded-lg transition-colors"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "14px",
              fontWeight: 600,
              backgroundColor: "#0058CC",
              color: "#FFFFFF"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "#0A4B9E";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "#0058CC";
            }}
          >
            Permitir acesso
          </button>
        </div>
      </div>
    </div>
  );
}
