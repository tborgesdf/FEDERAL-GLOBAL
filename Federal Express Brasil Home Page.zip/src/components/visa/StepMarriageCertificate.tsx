import { useState } from "react";
import { Heart, Eye } from "lucide-react";
import DocumentUpload from "./DocumentUpload";
import OCRPreviewCard from "./OCRPreviewCard";

interface StepMarriageCertificateProps {
  onNext: (data: any) => void;
}

export default function StepMarriageCertificate({ onNext }: StepMarriageCertificateProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showExample, setShowExample] = useState(false);

  const handleFileSelected = (file: File) => {
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    setShowPreview(true);
    setIsProcessing(true);

    // Simular OCR (2 segundos)
    setTimeout(() => {
      setIsProcessing(false);
    }, 2000);
  };

  const handleConfirm = (fields: any) => {
    const data = {
      file: selectedFile,
      fields: fields
    };
    onNext(data);
  };

  const handleCancel = () => {
    setShowPreview(false);
    setSelectedFile(null);
    setPreviewUrl("");
  };

  const mockOCRFields = [
    { label: "Nome do cônjuge 1", value: "JOÃO DA SILVA SANTOS", editable: true },
    { label: "Nome do cônjuge 2", value: "MARIA OLIVEIRA SANTOS", editable: true },
    { label: "Data do casamento", value: "20/05/2018", editable: true },
    { label: "Cartório", value: "1º Ofício de São Paulo", editable: true },
    { label: "Livro", value: "123", editable: true },
    { label: "Folha", value: "45", editable: true }
  ];

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#7C6EE4]/10 flex items-center justify-center flex-shrink-0">
            <Heart className="w-6 h-6 text-[#7C6EE4]" />
          </div>
          <div className="flex-1">
            <h2
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "24px",
                fontWeight: 600,
                color: "#1F2937",
                marginBottom: "8px"
              }}
            >
              Certidão de casamento
            </h2>
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#6B7280",
                lineHeight: "1.6"
              }}
            >
              Envie uma cópia da sua certidão de casamento atualizada, emitida há menos de 90 dias.
            </p>
          </div>
        </div>

        {/* Example Link */}
        <div className="mb-6">
          <button
            onClick={() => setShowExample(!showExample)}
            className="flex items-center gap-2 text-[#0058CC] hover:text-[#0A4B9E] transition-colors"
          >
            <Eye className="w-4 h-4" />
            <span
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                fontWeight: 500
              }}
            >
              {showExample ? "Ocultar exemplo" : "Ver exemplo de certidão"}
            </span>
          </button>

          {showExample && (
            <div className="mt-3 p-4 bg-gray-50 rounded-lg border">
              <img
                src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&q=80"
                alt="Exemplo de certidão"
                className="w-full rounded-lg"
              />
              <p
                className="mt-2"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#6B7280",
                  lineHeight: "1.5"
                }}
              >
                Certidão atualizada com todos os dados legíveis
              </p>
            </div>
          )}
        </div>

        {/* Important Notice */}
        <div className="mb-6 space-y-3">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "13px",
                color: "#1E40AF",
                lineHeight: "1.6"
              }}
            >
              <strong>Atenção:</strong> A certidão deve ser atualizada (emitida há menos de 90 dias). 
              Você pode solicitar uma segunda via atualizada no cartório onde foi registrado o casamento ou pelo site do cartório.
            </p>
          </div>

          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "13px",
                color: "#92400E",
                lineHeight: "1.6"
              }}
            >
              <strong>Importante:</strong> Certifique-se de que a certidão está completa e todos os dados estão legíveis, 
              incluindo o nome completo de ambos os cônjuges e a data do casamento.
            </p>
          </div>
        </div>

        {/* Upload or Preview */}
        {!showPreview ? (
          <DocumentUpload
            documentType="Certidão de Casamento"
            onFileSelected={handleFileSelected}
            showCameraOption={true}
          />
        ) : (
          <OCRPreviewCard
            imageUrl={previewUrl}
            fields={mockOCRFields}
            isProcessing={isProcessing}
            onConfirm={handleConfirm}
            onCancel={handleCancel}
          />
        )}
      </div>
    </div>
  );
}
