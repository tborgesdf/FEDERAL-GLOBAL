import { Check } from "lucide-react";

interface Step {
  id: string;
  label: string;
  shortLabel?: string;
}

interface FlowProgressBarProps {
  currentStep: number;
  steps: Step[];
}

export default function FlowProgressBar({ currentStep, steps }: FlowProgressBarProps) {
  return (
    <div className="sticky top-[100px] z-30 bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-200">
      <div className="mx-auto max-w-[1200px] px-6 py-4">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => {
            const stepNumber = index + 1;
            const isCompleted = stepNumber < currentStep;
            const isCurrent = stepNumber === currentStep;
            const isPending = stepNumber > currentStep;

            return (
              <div key={step.id} className="flex flex-1 items-center">
                {/* Step Circle */}
                <div className="flex flex-col items-center gap-2">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all duration-300 ${
                      isCompleted
                        ? "border-[#2BA84A] bg-[#2BA84A] text-white"
                        : isCurrent
                        ? "border-[#0058CC] bg-[#0058CC] text-white shadow-lg shadow-[#0058CC]/30"
                        : "border-gray-300 bg-white text-gray-400"
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="h-5 w-5" />
                    ) : (
                      <span
                        style={{
                          fontFamily: "Poppins, sans-serif",
                          fontSize: "14px",
                          fontWeight: 600
                        }}
                      >
                        {stepNumber}
                      </span>
                    )}
                  </div>

                  {/* Label */}
                  <div className="text-center">
                    <p
                      className="hidden md:block"
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "11px",
                        fontWeight: isCurrent ? 600 : 400,
                        color: isCurrent ? "#0058CC" : isCompleted ? "#2BA84A" : "#999",
                        whiteSpace: "nowrap"
                      }}
                    >
                      {step.label}
                    </p>
                    {step.shortLabel && (
                      <p
                        className="block md:hidden"
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "10px",
                          fontWeight: isCurrent ? 600 : 400,
                          color: isCurrent ? "#0058CC" : isCompleted ? "#2BA84A" : "#999"
                        }}
                      >
                        {step.shortLabel}
                      </p>
                    )}
                  </div>
                </div>

                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className="mx-2 h-0.5 flex-1">
                    <div
                      className="h-full transition-all duration-500"
                      style={{
                        backgroundColor: isCompleted ? "#2BA84A" : "#E5E7EB"
                      }}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
