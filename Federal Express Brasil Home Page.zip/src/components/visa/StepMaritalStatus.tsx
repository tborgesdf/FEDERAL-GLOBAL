import { useState } from "react";
import { Heart, HelpCircle } from "lucide-react";

interface StepMaritalStatusProps {
  onNext: (maritalStatus: "single" | "married" | "stable-union") => void;
}

export default function StepMaritalStatus({ onNext }: StepMaritalStatusProps) {
  const [maritalStatus, setMaritalStatus] = useState<"single" | "married" | "stable-union" | null>(null);
  const [showHelp, setShowHelp] = useState(false);

  const handleNext = () => {
    if (maritalStatus !== null) {
      onNext(maritalStatus);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#7C6EE4]/10 flex items-center justify-center flex-shrink-0">
            <Heart className="w-6 h-6 text-[#7C6EE4]" />
          </div>
          <div className="flex-1">
            <h2
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "24px",
                fontWeight: 600,
                color: "#1F2937",
                marginBottom: "8px"
              }}
            >
              Informe seu estado civil
            </h2>
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#6B7280",
                lineHeight: "1.6"
              }}
            >
              Esta informação é importante para determinar os documentos necessários para sua solicitação de visto.
            </p>
          </div>
        </div>

        {/* Options */}
        <div className="space-y-3">
          {/* Não sou casado oficialmente */}
          <label 
            className="flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all hover:border-[#0058CC] hover:bg-blue-50"
            style={{
              borderColor: maritalStatus === "single" ? "#0058CC" : "#E5E7EB",
              backgroundColor: maritalStatus === "single" ? "#EFF6FF" : "#FFFFFF"
            }}
          >
            <input
              type="radio"
              name="maritalStatus"
              value="single"
              checked={maritalStatus === "single"}
              onChange={() => setMaritalStatus("single")}
              className="w-5 h-5 mt-0.5 accent-[#0058CC]"
              style={{
                minWidth: "20px"
              }}
            />
            <div className="flex-1">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "#1F2937",
                  marginBottom: "4px"
                }}
              >
                Não sou casado oficialmente
              </p>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#6B7280",
                  lineHeight: "1.5"
                }}
              >
                Solteiro(a), divorciado(a) ou viúvo(a)
              </p>
            </div>
          </label>

          {/* Sou casado oficialmente */}
          <label 
            className="flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all hover:border-[#0058CC] hover:bg-blue-50"
            style={{
              borderColor: maritalStatus === "married" ? "#0058CC" : "#E5E7EB",
              backgroundColor: maritalStatus === "married" ? "#EFF6FF" : "#FFFFFF"
            }}
          >
            <input
              type="radio"
              name="maritalStatus"
              value="married"
              checked={maritalStatus === "married"}
              onChange={() => setMaritalStatus("married")}
              className="w-5 h-5 mt-0.5 accent-[#0058CC]"
              style={{
                minWidth: "20px"
              }}
            />
            <div className="flex-1">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "#1F2937",
                  marginBottom: "4px"
                }}
              >
                Sou casado(a) oficialmente
              </p>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#6B7280",
                  lineHeight: "1.5"
                }}
              >
                Possuo certidão de casamento emitida por cartório brasileiro
              </p>
            </div>
          </label>

          {/* União estável */}
          <label 
            className="flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all hover:border-[#0058CC] hover:bg-blue-50"
            style={{
              borderColor: maritalStatus === "stable-union" ? "#0058CC" : "#E5E7EB",
              backgroundColor: maritalStatus === "stable-union" ? "#EFF6FF" : "#FFFFFF"
            }}
          >
            <input
              type="radio"
              name="maritalStatus"
              value="stable-union"
              checked={maritalStatus === "stable-union"}
              onChange={() => setMaritalStatus("stable-union")}
              className="w-5 h-5 mt-0.5 accent-[#0058CC]"
              style={{
                minWidth: "20px"
              }}
            />
            <div className="flex-1">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "#1F2937",
                  marginBottom: "4px"
                }}
              >
                União estável
              </p>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#6B7280",
                  lineHeight: "1.5"
                }}
              >
                Possuo declaração de união estável registrada em cartório
              </p>
            </div>
          </label>

          {/* Help text */}
          {maritalStatus === "married" && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#1E40AF",
                  lineHeight: "1.5"
                }}
              >
                <strong>Documento necessário:</strong> Você precisará enviar sua certidão de casamento em uma etapa posterior.
              </p>
            </div>
          )}

          {maritalStatus === "stable-union" && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#1E40AF",
                  lineHeight: "1.5"
                }}
              >
                <strong>Documento necessário:</strong> Você precisará enviar sua declaração de união estável em uma etapa posterior.
              </p>
            </div>
          )}

          {maritalStatus === "single" && (
            <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#374151",
                  lineHeight: "1.5"
                }}
              >
                <strong>Entendido:</strong> Você não precisará enviar certidão de casamento ou declaração de união estável.
              </p>
            </div>
          )}
        </div>

        {/* FAQ */}
        <div className="mt-6">
          <button
            onClick={() => setShowHelp(!showHelp)}
            className="flex items-center gap-2 text-[#0058CC] hover:text-[#0A4B9E] transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
            <span
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                fontWeight: 500
              }}
            >
              {showHelp ? "Ocultar ajuda" : "Precisa de ajuda?"}
            </span>
          </button>

          {showHelp && (
            <div className="mt-3 p-4 bg-gray-50 rounded-lg border">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#374151",
                  lineHeight: "1.6"
                }}
              >
                <strong>Por que precisamos desta informação?</strong><br />
                O estado civil pode influenciar na documentação exigida pelos consulados. 
                Casamentos oficializados e uniões estáveis registradas requerem a apresentação de documentação comprobatória atualizada.
              </p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="mt-8 flex justify-end">
          <button
            onClick={handleNext}
            disabled={maritalStatus === null}
            className="px-6 py-3 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "16px",
              fontWeight: 600,
              backgroundColor: maritalStatus !== null ? "#0058CC" : "#D1D5DB",
              color: "#FFFFFF",
              minWidth: "140px"
            }}
            onMouseEnter={(e) => {
              if (maritalStatus !== null) {
                e.currentTarget.style.backgroundColor = "#0A4B9E";
              }
            }}
            onMouseLeave={(e) => {
              if (maritalStatus !== null) {
                e.currentTarget.style.backgroundColor = "#0058CC";
              }
            }}
          >
            Próximo
          </button>
        </div>
      </div>
    </div>
  );
}