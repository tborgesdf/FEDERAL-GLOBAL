import { useState } from "react";
import { FileText, Eye } from "lucide-react";
import DocumentUpload from "./DocumentUpload";
import OCRPreviewCard from "./OCRPreviewCard";

interface StepPreviousVisaProps {
  onNext: (data: any) => void;
}

export default function StepPreviousVisa({ onNext }: StepPreviousVisaProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showExample, setShowExample] = useState(false);

  const handleFileSelected = (file: File) => {
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    setShowPreview(true);
    setIsProcessing(true);

    // Simular OCR (2 segundos)
    setTimeout(() => {
      setIsProcessing(false);
    }, 2000);
  };

  const handleConfirm = (fields: any) => {
    const data = {
      file: selectedFile,
      fields: fields
    };
    onNext(data);
  };

  const handleCancel = () => {
    setShowPreview(false);
    setSelectedFile(null);
    setPreviewUrl("");
  };

  const mockOCRFields = [
    { label: "Tipo de visto", value: "B1/B2 - TURISMO", editable: true },
    { label: "Número do visto", value: "123456789", editable: true },
    { label: "Data de emissão", value: "15/03/2020", editable: true },
    { label: "Data de validade", value: "15/03/2025", editable: true },
    { label: "País de emissão", value: "ESTADOS UNIDOS", editable: false },
    { label: "Número de entradas", value: "MÚLTIPLAS", editable: true }
  ];

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#7C6EE4]/10 flex items-center justify-center flex-shrink-0">
            <FileText className="w-6 h-6 text-[#7C6EE4]" />
          </div>
          <div className="flex-1">
            <h2
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "24px",
                fontWeight: 600,
                color: "#1F2937",
                marginBottom: "8px"
              }}
            >
              Visto anterior
            </h2>
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#6B7280",
                lineHeight: "1.6"
              }}
            >
              Para renovação de visto, precisamos da página do seu passaporte que contém o visto anterior. 
              Certifique-se de que todos os dados estejam visíveis.
            </p>
          </div>
        </div>

        {/* Example Link */}
        <div className="mb-6">
          <button
            onClick={() => setShowExample(!showExample)}
            className="flex items-center gap-2 text-[#0058CC] hover:text-[#0A4B9E] transition-colors"
          >
            <Eye className="w-4 h-4" />
            <span
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                fontWeight: 500
              }}
            >
              {showExample ? "Ocultar exemplo" : "Ver exemplo de visto"}
            </span>
          </button>

          {showExample && (
            <div className="mt-3 p-4 bg-gray-50 rounded-lg border">
              <img
                src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80"
                alt="Exemplo de visto"
                className="w-full rounded-lg"
              />
              <p
                className="mt-2"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#6B7280",
                  lineHeight: "1.5"
                }}
              >
                Foto com boa iluminação e todos os dados do visto visíveis
              </p>
            </div>
          )}
        </div>

        {/* Important Notice */}
        <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <p
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "13px",
              color: "#92400E",
              lineHeight: "1.6"
            }}
          >
            <strong>Importante:</strong> Para renovação, é necessário que seu visto anterior ainda esteja válido ou tenha expirado há menos de 48 meses. 
            Se o visto estiver muito antigo, você precisará solicitar um novo visto ao invés de renovação.
          </p>
        </div>

        {/* Upload or Preview */}
        {!showPreview ? (
          <DocumentUpload
            documentType="Visto Anterior"
            onFileSelected={handleFileSelected}
            showCameraOption={true}
          />
        ) : (
          <OCRPreviewCard
            imageUrl={previewUrl}
            fields={mockOCRFields}
            isProcessing={isProcessing}
            onConfirm={handleConfirm}
            onCancel={handleCancel}
          />
        )}
      </div>
    </div>
  );
}
