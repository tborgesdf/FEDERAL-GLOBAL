import { useState, useRef, useEffect } from "react";
import { Camera, Eye, CheckCircle, XCircle } from "lucide-react";
import CameraModal from "./CameraModal";

interface StepSelfieProps {
  onNext: (selfieFile: File) => void;
}

// ErrorBanner Component
function ErrorBanner({ type, message }: { type: "success" | "error"; message: string }) {
  const isSuccess = type === "success";
  const Icon = isSuccess ? CheckCircle : XCircle;
  
  return (
    <div 
      className={`p-4 rounded-lg border ${isSuccess ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}
    >
      <div className="flex items-start gap-3">
        <Icon className={`w-5 h-5 flex-shrink-0 ${isSuccess ? 'text-[#2BA84A]' : 'text-[#DC2626]'}`} />
        <p
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "14px",
            color: isSuccess ? "#15803D" : "#991B1B",
            lineHeight: "1.5"
          }}
        >
          {message}
        </p>
      </div>
    </div>
  );
}

export default function StepSelfie({ onNext }: StepSelfieProps) {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<"approved" | "rejected" | null>(null);
  const [rejectionReason, setRejectionReason] = useState<string>("");
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [showExample, setShowExample] = useState(false);
  const [capturedFile, setCapturedFile] = useState<File | null>(null);

  const handleCameraCapture = (file: File) => {
    setCapturedFile(file);
    const url = URL.createObjectURL(file);
    setCapturedImage(url);
    setIsAnalyzing(true);
    setAnalysisResult(null);
    setShowCameraModal(false);

    // Simulate quality analysis (2 seconds)
    setTimeout(() => {
      setIsAnalyzing(false);
      // Random result for demo (70% approval rate)
      const isApproved = Math.random() > 0.3;
      setAnalysisResult(isApproved ? "approved" : "rejected");
      
      if (!isApproved) {
        const reasons = [
          "Iluminação insuficiente. Tente em um local mais claro.",
          "Rosto parcialmente coberto. Remova óculos escuros ou máscaras.",
          "Imagem desfocada. Mantenha a câmera estável.",
          "Rosto não detectado. Centralize seu rosto na imagem."
        ];
        setRejectionReason(reasons[Math.floor(Math.random() * reasons.length)]);
      }
    }, 2000);
  };

  const handleTryAgain = () => {
    setCapturedImage(null);
    setAnalysisResult(null);
    setRejectionReason("");
  };

  const handleNext = () => {
    if (analysisResult === "approved" && capturedFile) {
      onNext(capturedFile);
    }
  };

  return (
    <>
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
          {/* Header */}
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 rounded-full bg-[#7C6EE4]/10 flex items-center justify-center flex-shrink-0">
              <Camera className="w-6 h-6 text-[#7C6EE4]" />
            </div>
            <div className="flex-1">
              <h2
                style={{
                  fontFamily: "Poppins, sans-serif",
                  fontSize: "24px",
                  fontWeight: 600,
                  color: "#1F2937",
                  marginBottom: "8px"
                }}
              >
                Selfie de verificação
              </h2>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#6B7280",
                  lineHeight: "1.6"
                }}
              >
                Tire uma selfie para validar sua identidade. Esta foto será comparada com seu passaporte.
              </p>
            </div>
          </div>

          {/* Instructions */}
          <div className="mb-6">
            <h3
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "16px",
                fontWeight: 600,
                color: "#1F2937",
                marginBottom: "12px"
              }}
            >
              Instruções importantes
            </h3>
            <ul className="space-y-2">
              {[
                "Use boa iluminação, de preferência luz natural",
                "Remova óculos escuros, bonés ou máscaras",
                "Olhe diretamente para a câmera",
                "Centralize seu rosto na imagem",
                "Mantenha uma expressão neutra"
              ].map((instruction, index) => (
                <li
                  key={index}
                  className="flex items-start gap-2"
                >
                  <CheckCircle className="w-5 h-5 text-[#2BA84A] flex-shrink-0 mt-0.5" />
                  <span
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "#374151",
                      lineHeight: "1.6"
                    }}
                  >
                    {instruction}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Example Link */}
          <div className="mb-6">
            <button
              onClick={() => setShowExample(!showExample)}
              className="flex items-center gap-2 text-[#0058CC] hover:text-[#0A4B9E] transition-colors"
            >
              <Eye className="w-4 h-4" />
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 500
                }}
              >
                {showExample ? "Ocultar exemplo" : "Ver exemplo de selfie"}
              </span>
            </button>

            {showExample && (
              <div className="mt-3 p-4 bg-gray-50 rounded-lg border">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&q=80"
                      alt="Selfie correta"
                      className="w-full rounded-lg"
                    />
                    <p
                      className="mt-2 text-center"
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "13px",
                        color: "#2BA84A",
                        fontWeight: 600
                      }}
                    >
                      ✓ Correto
                    </p>
                  </div>
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80"
                      alt="Selfie incorreta"
                      className="w-full rounded-lg opacity-50"
                    />
                    <p
                      className="mt-2 text-center"
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "13px",
                        color: "#DC2626",
                        fontWeight: 600
                      }}
                    >
                      ✗ Com óculos
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Capture Section */}
          {!capturedImage ? (
            <div>
              <button
                onClick={() => setShowCameraModal(true)}
                className="w-full flex flex-col items-center justify-center gap-4 p-8 border-2 border-dashed border-gray-300 rounded-lg hover:border-[#0058CC] hover:bg-blue-50 transition-all group"
              >
                <div className="w-16 h-16 rounded-full bg-[#0058CC]/10 group-hover:bg-[#0058CC]/20 flex items-center justify-center transition-colors">
                  <Camera className="w-8 h-8 text-[#0058CC]" />
                </div>
                <div className="text-center">
                  <p
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "16px",
                      fontWeight: 600,
                      color: "#1F2937",
                      marginBottom: "4px"
                    }}
                  >
                    Capturar selfie
                  </p>
                  <p
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      color: "#6B7280"
                    }}
                  >
                    Toque para abrir a câmera
                  </p>
                </div>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Preview */}
              <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden max-w-sm mx-auto">
                <img
                  src={capturedImage}
                  alt="Selfie capturada"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Analysis */}
              {isAnalyzing && (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 border-2 border-[#0058CC] border-t-transparent rounded-full animate-spin" />
                    <p
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px",
                        color: "#1E40AF"
                      }}
                    >
                      Analisando qualidade da imagem...
                    </p>
                  </div>
                </div>
              )}

              {/* Approved */}
              {analysisResult === "approved" && (
                <ErrorBanner
                  type="success"
                  message="Selfie aprovada! A qualidade da imagem está excelente."
                />
              )}

              {/* Rejected */}
              {analysisResult === "rejected" && (
                <div>
                  <ErrorBanner
                    type="error"
                    message={rejectionReason}
                  />
                  <button
                    onClick={handleTryAgain}
                    className="w-full mt-3 px-4 py-3 rounded-lg border-2 border-[#DC2626] text-[#DC2626] hover:bg-red-50 transition-colors"
                    style={{
                      fontFamily: "Inter, sans-serif",
                      fontSize: "14px",
                      fontWeight: 600
                    }}
                  >
                    Tentar novamente
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="mt-8 flex justify-end">
            <button
              onClick={handleNext}
              disabled={analysisResult !== "approved"}
              className="px-6 py-3 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "16px",
                fontWeight: 600,
                backgroundColor: analysisResult === "approved" ? "#0058CC" : "#D1D5DB",
                color: "#FFFFFF",
                minWidth: "140px"
              }}
              onMouseEnter={(e) => {
                if (analysisResult === "approved") {
                  e.currentTarget.style.backgroundColor = "#0A4B9E";
                }
              }}
              onMouseLeave={(e) => {
                if (analysisResult === "approved") {
                  e.currentTarget.style.backgroundColor = "#0058CC";
                }
              }}
            >
              Próximo
            </button>
          </div>
        </div>
      </div>

      {/* Camera Modal */}
      <CameraModal
        isOpen={showCameraModal}
        onClose={() => setShowCameraModal(false)}
        onCapture={handleCameraCapture}
        title="Capturar selfie"
        facingMode="user"
      />
    </>
  );
}
