import { useState, useRef, useEffect } from "react";
import { Camera, Upload, FileImage, Loader2 } from "lucide-react";
import CameraModal from "./CameraModal";

interface DocumentUploadProps {
  documentType: string;
  onFileSelected: (file: File) => void;
  accept?: string;
  showCameraOption?: boolean;
}

export default function DocumentUpload({
  documentType,
  onFileSelected,
  accept = "image/jpeg,image/png,image/jpg,application/pdf",
  showCameraOption = true
}: DocumentUploadProps) {
  const [isCapturing, setIsCapturing] = useState(false);
  const [hasCameraAccess, setHasCameraAccess] = useState(false);
  const [isCheckingCamera, setIsCheckingCamera] = useState(true);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    checkCameraAvailability();
  }, []);

  const checkCameraAvailability = async () => {
    try {
      // Check if mediaDevices API is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
        setHasCameraAccess(false);
        setIsCheckingCamera(false);
        return;
      }

      // Check if we're in a secure context (HTTPS or localhost)
      if (!window.isSecureContext) {
        setHasCameraAccess(false);
        setIsCheckingCamera(false);
        return;
      }

      // Enumerate devices to check for camera
      const devices = await navigator.mediaDevices.enumerateDevices();
      const hasCamera = devices.some(device => device.kind === 'videoinput');
      
      setHasCameraAccess(hasCamera);
      setIsCheckingCamera(false);
    } catch (error) {
      // Silently fail - just don't show camera option
      setHasCameraAccess(false);
      setIsCheckingCamera(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelected(file);
    }
    // Reset input value to allow selecting the same file again
    e.target.value = '';
  };

  const handleCameraClick = () => {
    // Try to open modal, but if it fails, fallback to file input
    setShowCameraModal(true);
  };

  const handleCameraCapture = (file: File) => {
    onFileSelected(file);
    setShowCameraModal(false);
  };

  const handleUploadClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    fileInputRef.current?.click();
  };

  return (
    <>
      <div className="space-y-3">
        {/* Hidden file input - moved outside buttons */}
        <input
          ref={fileInputRef}
          type="file"
          accept={accept}
          onChange={handleFileChange}
          className="hidden"
          aria-label="Enviar arquivo"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Camera Button - Only show if camera is available */}
          {showCameraOption && hasCameraAccess && !isCheckingCamera && (
            <button
              type="button"
              onClick={handleCameraClick}
              className="flex items-center justify-center gap-3 p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-[#0058CC] hover:bg-blue-50 transition-all group"
              style={{
                minHeight: "120px"
              }}
            >
              <div className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-full bg-[#0058CC]/10 group-hover:bg-[#0058CC]/20 flex items-center justify-center transition-colors">
                  <Camera className="w-6 h-6 text-[#0058CC]" />
                </div>
                <span
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "#1F2937"
                  }}
                >
                  Capturar com câmera
                </span>
                <span
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "12px",
                    color: "#6B7280"
                  }}
                >
                  Tire uma foto agora
                </span>
              </div>
            </button>
          )}

          {/* Upload Button */}
          <button
            type="button"
            onClick={handleUploadClick}
            className={`flex items-center justify-center gap-3 p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-[#0058CC] hover:bg-blue-50 transition-all group ${!showCameraOption || !hasCameraAccess ? 'sm:col-span-2' : ''}`}
            style={{
              minHeight: "120px"
            }}
          >
            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 rounded-full bg-[#2BA84A]/10 group-hover:bg-[#2BA84A]/20 flex items-center justify-center transition-colors">
                <Upload className="w-6 h-6 text-[#2BA84A]" />
              </div>
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "#1F2937"
                }}
              >
                Enviar arquivo
              </span>
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "12px",
                  color: "#6B7280"
                }}
              >
                JPG, PNG ou PDF
              </span>
            </div>
          </button>
        </div>

        {/* Helper text */}
        <p
          className="text-center"
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "13px",
            color: "#6B7280",
            lineHeight: "1.5"
          }}
        >
          Certifique-se de que o documento está legível e bem iluminado
        </p>
      </div>

      {/* Camera Modal */}
      <CameraModal
        isOpen={showCameraModal}
        onClose={() => setShowCameraModal(false)}
        onCapture={handleCameraCapture}
        title={`Capturar ${documentType}`}
        facingMode="environment"
      />
    </>
  );
}