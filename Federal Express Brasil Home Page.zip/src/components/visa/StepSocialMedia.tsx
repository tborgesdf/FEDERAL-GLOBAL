import { useState } from "react";
import { Share2, Facebook, Instagram, Twitter, Youtube, Linkedin, Music, MessageCircle, Send } from "lucide-react";

interface SocialMediaData {
  platform: string;
  username: string;
  icon: any;
}

interface StepSocialMediaProps {
  onNext: (hasSocial: boolean, platforms: SocialMediaData[]) => void;
}

export default function StepSocialMedia({ onNext }: StepSocialMediaProps) {
  const [hasSocial, setHasSocial] = useState<boolean | null>(null);
  const [platforms, setPlatforms] = useState<SocialMediaData[]>([
    { platform: "Facebook", username: "", icon: Facebook },
    { platform: "Instagram", username: "", icon: Instagram },
    { platform: "X (Twitter)", username: "", icon: Twitter },
    { platform: "YouTube", username: "", icon: Youtube },
    { platform: "LinkedIn", username: "", icon: Linkedin },
    { platform: "TikTok", username: "", icon: Music },
    { platform: "Snapchat", username: "", icon: MessageCircle },
    { platform: "Pinterest", username: "", icon: Share2 },
    { platform: "Kwai", username: "", icon: Music },
    { platform: "Facebook Messenger", username: "", icon: Send },
    { platform: "Telegram", username: "", icon: Send },
    { platform: "Outra", username: "", icon: Share2 }
  ]);

  const handleUsernameChange = (index: number, value: string) => {
    const newPlatforms = [...platforms];
    newPlatforms[index].username = value;
    setPlatforms(newPlatforms);
  };

  const handleNext = () => {
    if (hasSocial === false) {
      onNext(false, []);
    } else if (hasSocial === true) {
      const filledPlatforms = platforms.filter(p => p.username.trim() !== "");
      if (filledPlatforms.length > 0) {
        onNext(true, filledPlatforms);
      }
    }
  };

  const canProceed = () => {
    if (hasSocial === false) return true;
    if (hasSocial === true) {
      return platforms.some(p => p.username.trim() !== "");
    }
    return false;
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
        {/* Header */}
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#0058CC]/10 flex items-center justify-center flex-shrink-0">
            <Share2 className="w-6 h-6 text-[#0058CC]" />
          </div>
          <div className="flex-1">
            <h2
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "24px",
                fontWeight: 600,
                color: "#1F2937",
                marginBottom: "8px"
              }}
            >
              Redes sociais
            </h2>
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#6B7280",
                lineHeight: "1.6"
              }}
            >
              Alguns consulados solicitam informações sobre presença em redes sociais. 
              Isso ajuda no processo de verificação de identidade.
            </p>
          </div>
        </div>

        {/* Question */}
        <div className="space-y-4 mb-6">
          <p
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "15px",
              fontWeight: 600,
              color: "#1F2937"
            }}
          >
            Você possui redes sociais?
          </p>

          <div className="flex gap-3">
            <button
              onClick={() => setHasSocial(true)}
              className="flex-1 px-4 py-3 rounded-lg border-2 transition-all"
              style={{
                borderColor: hasSocial === true ? "#0058CC" : "#E5E7EB",
                backgroundColor: hasSocial === true ? "#EFF6FF" : "#FFFFFF",
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                fontWeight: 600,
                color: hasSocial === true ? "#0058CC" : "#374151"
              }}
            >
              Sim
            </button>
            <button
              onClick={() => setHasSocial(false)}
              className="flex-1 px-4 py-3 rounded-lg border-2 transition-all"
              style={{
                borderColor: hasSocial === false ? "#0058CC" : "#E5E7EB",
                backgroundColor: hasSocial === false ? "#EFF6FF" : "#FFFFFF",
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                fontWeight: 600,
                color: hasSocial === false ? "#0058CC" : "#374151"
              }}
            >
              Não
            </button>
          </div>

          {hasSocial === false && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#1E40AF",
                  lineHeight: "1.5"
                }}
              >
                Sem problemas! Você poderá adicionar essas informações depois, se necessário.
              </p>
            </div>
          )}
        </div>

        {/* Social Media List */}
        {hasSocial === true && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "15px",
                  fontWeight: 600,
                  color: "#1F2937"
                }}
              >
                Preencha suas redes sociais
              </p>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#6B7280"
                }}
              >
                Preencha apenas as que você possui
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {platforms.map((platform, index) => {
                const Icon = platform.icon;
                return (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <label
                        htmlFor={`social-${index}`}
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "13px",
                          fontWeight: 500,
                          color: "#374151"
                        }}
                      >
                        {platform.platform}
                      </label>
                      <input
                        id={`social-${index}`}
                        type="text"
                        value={platform.username}
                        onChange={(e) => handleUsernameChange(index, e.target.value)}
                        placeholder="@usuario"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0058CC] focus:border-transparent mt-1"
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px"
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {!canProceed() && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "13px",
                    color: "#92400E",
                    lineHeight: "1.5"
                  }}
                >
                  Por favor, preencha pelo menos uma rede social para continuar.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="mt-8 flex justify-end">
          <button
            onClick={handleNext}
            disabled={!canProceed()}
            className="px-6 py-3 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "16px",
              fontWeight: 600,
              backgroundColor: canProceed() ? "#0058CC" : "#D1D5DB",
              color: "#FFFFFF",
              minWidth: "140px"
            }}
            onMouseEnter={(e) => {
              if (canProceed()) {
                e.currentTarget.style.backgroundColor = "#0A4B9E";
              }
            }}
            onMouseLeave={(e) => {
              if (canProceed()) {
                e.currentTarget.style.backgroundColor = "#0058CC";
              }
            }}
          >
            Próximo
          </button>
        </div>
      </div>
    </div>
  );
}
