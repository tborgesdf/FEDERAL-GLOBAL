import { useState } from "react";
import { FileCheck, Edit2, X, Loader2 } from "lucide-react";

interface OCRField {
  label: string;
  value: string;
  editable: boolean;
}

interface OCRPreviewCardProps {
  imageUrl: string;
  fields: OCRField[];
  isProcessing: boolean;
  onConfirm: (fields: OCRField[]) => void;
  onCancel: () => void;
}

export default function OCRPreviewCard({
  imageUrl,
  fields: initialFields,
  isProcessing,
  onConfirm,
  onCancel
}: OCRPreviewCardProps) {
  const [fields, setFields] = useState(initialFields);
  const [isEditing, setIsEditing] = useState(false);

  const handleFieldChange = (index: number, value: string) => {
    const newFields = [...fields];
    newFields[index].value = value;
    setFields(newFields);
  };

  const handleConfirm = () => {
    onConfirm(fields);
  };

  return (
    <div className="bg-white border rounded-lg shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <FileCheck className="w-5 h-5 text-[#2BA84A]" />
          <h3
            style={{
              fontFamily: "Poppins, sans-serif",
              fontSize: "16px",
              fontWeight: 600,
              color: "#1F2937"
            }}
          >
            {isProcessing ? "Processando documento..." : "Confirme os dados extraídos"}
          </h3>
        </div>
        <button
          onClick={onCancel}
          className="p-1 hover:bg-gray-200 rounded transition-colors"
          aria-label="Cancelar"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Image Preview */}
        <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
          <img
            src={imageUrl}
            alt="Documento capturado"
            className="w-full h-full object-contain"
          />
        </div>

        {/* Processing State */}
        {isProcessing ? (
          <div className="flex flex-col items-center justify-center py-8 gap-3">
            <Loader2 className="w-8 h-8 text-[#0058CC] animate-spin" />
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "14px",
                color: "#6B7280"
              }}
            >
              Extraindo dados do documento...
            </p>
          </div>
        ) : (
          <>
            {/* Fields */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 600,
                    color: "#1F2937"
                  }}
                >
                  Dados extraídos
                </p>
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="flex items-center gap-1 px-3 py-1.5 text-sm hover:bg-gray-100 rounded transition-colors"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "13px",
                    color: "#0058CC"
                  }}
                >
                  <Edit2 className="w-4 h-4" />
                  {isEditing ? "Concluir edição" : "Editar"}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {fields.map((field, index) => (
                  <div key={index} className="space-y-1">
                    <label
                      htmlFor={`field-${index}`}
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "13px",
                        fontWeight: 500,
                        color: "#374151"
                      }}
                    >
                      {field.label}
                    </label>
                    {isEditing && field.editable ? (
                      <input
                        id={`field-${index}`}
                        type="text"
                        value={field.value}
                        onChange={(e) => handleFieldChange(index, e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0058CC] focus:border-transparent"
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px"
                        }}
                      />
                    ) : (
                      <p
                        className="px-3 py-2 bg-gray-50 rounded-lg border border-gray-200"
                        style={{
                          fontFamily: "Inter, sans-serif",
                          fontSize: "14px",
                          color: "#1F2937"
                        }}
                      >
                        {field.value || "—"}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Warning */}
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "13px",
                  color: "#92400E",
                  lineHeight: "1.5"
                }}
              >
                <strong>Atenção:</strong> Verifique se todos os dados estão corretos. Informações incorretas podem atrasar sua solicitação.
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <button
                onClick={onCancel}
                className="flex-1 px-4 py-3 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "#374151"
                }}
              >
                Tentar novamente
              </button>
              <button
                onClick={handleConfirm}
                className="flex-1 px-4 py-3 rounded-lg transition-colors"
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 600,
                  backgroundColor: "#2BA84A",
                  color: "#FFFFFF"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "#248A3D";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "#2BA84A";
                }}
              >
                Confirmar e salvar
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
