import { useState } from "react";
import { BookOpen, Eye } from "lucide-react";
import DocumentUpload from "./DocumentUpload";
import OCRPreviewCard from "./OCRPreviewCard";
import CameraPermissionModal from "./CameraPermissionModal";
import ErrorBanner from "./ErrorBanner";

interface StepPassportProps {
  onNext: (data: any) => void;
}

export default function StepPassport({ onNext }: StepPassportProps) {
  const [showPermissionModal, setShowPermissionModal] = useState(true);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showExample, setShowExample] = useState(false);

  const handlePermissionConfirm = () => {
    setShowPermissionModal(false);
  };

  const handleFileSelected = (file: File) => {
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    setShowPreview(true);
    setIsProcessing(true);

    // Simular OCR (2 segundos)
    setTimeout(() => {
      setIsProcessing(false);
    }, 2000);
  };

  const handleConfirm = (fields: any) => {
    const data = {
      file: selectedFile,
      fields: fields
    };
    onNext(data);
  };

  const handleCancel = () => {
    setShowPreview(false);
    setSelectedFile(null);
    setPreviewUrl("");
  };

  const mockOCRFields = [
    { label: "Nome completo", value: "JOÃO DA SILVA SANTOS", editable: true },
    { label: "Número do passaporte", value: "BR123456", editable: true },
    { label: "Data de nascimento", value: "15/03/1990", editable: true },
    { label: "Data de emissão", value: "10/01/2020", editable: true },
    { label: "Data de validade", value: "10/01/2030", editable: true },
    { label: "País de emissão", value: "BRASIL", editable: false },
    { label: "Nacionalidade", value: "BRASILEIRA", editable: false }
  ];

  return (
    <>
      <CameraPermissionModal
        isOpen={showPermissionModal}
        onClose={() => setShowPermissionModal(false)}
        onConfirm={handlePermissionConfirm}
      />

      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm border p-6 sm:p-8">
          {/* Header */}
          <div className="flex items-start gap-4 mb-6">
            <div className="w-12 h-12 rounded-full bg-[#2BA84A]/10 flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-6 h-6 text-[#2BA84A]" />
            </div>
            <div className="flex-1">
              <h2
                style={{
                  fontFamily: "Poppins, sans-serif",
                  fontSize: "24px",
                  fontWeight: 600,
                  color: "#1F2937",
                  marginBottom: "8px"
                }}
              >
                Passaporte
              </h2>
              <p
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  color: "#6B7280",
                  lineHeight: "1.6"
                }}
              >
                Envie uma foto clara da página de identificação do seu passaporte. 
                Certifique-se de que todos os dados estejam legíveis.
              </p>
            </div>
          </div>

          {/* Example Link */}
          <div className="mb-6">
            <button
              onClick={() => setShowExample(!showExample)}
              className="flex items-center gap-2 text-[#0058CC] hover:text-[#0A4B9E] transition-colors"
            >
              <Eye className="w-4 h-4" />
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "14px",
                  fontWeight: 500
                }}
              >
                {showExample ? "Ocultar exemplo" : "Ver exemplo de foto"}
              </span>
            </button>

            {showExample && (
              <div className="mt-3 p-4 bg-gray-50 rounded-lg border">
                <img
                  src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80"
                  alt="Exemplo de passaporte"
                  className="w-full rounded-lg"
                />
                <p
                  className="mt-2"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "13px",
                    color: "#6B7280",
                    lineHeight: "1.5"
                  }}
                >
                  Foto com boa iluminação, sem reflexos e com todos os dados visíveis
                </p>
              </div>
            )}
          </div>

          {/* Info Banner */}
          <div className="mb-6">
            <ErrorBanner
              type="info"
              message="Guarde seu passaporte à mão. Você precisará conferir os dados extraídos automaticamente."
            />
          </div>

          {/* Upload or Preview */}
          {!showPreview ? (
            <DocumentUpload
              documentType="Passaporte"
              onFileSelected={handleFileSelected}
              showCameraOption={true}
            />
          ) : (
            <OCRPreviewCard
              imageUrl={previewUrl}
              fields={mockOCRFields}
              isProcessing={isProcessing}
              onConfirm={handleConfirm}
              onCancel={handleCancel}
            />
          )}
        </div>
      </div>
    </>
  );
}
