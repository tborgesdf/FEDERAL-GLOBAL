import { useState } from "react";
import { Check, ArrowRight, X } from "lucide-react";
import { toast } from "sonner@2.0.3";
import Header from "./Header";

interface SelectCountryPageProps {
  onNext: (country: string) => void;
  onCancel: () => void;
  onLogout: () => void;
  userEmail: string;
}

export default function SelectCountryPage({ onNext, onCancel, onLogout, userEmail }: SelectCountryPageProps) {
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);

  const countries = [
    {
      id: "canada",
      name: "CANADÁ",
      flag: "🇨🇦",
      servicesCount: 1,
      available: true,
      color: "#DC2626"
    },
    {
      id: "usa",
      name: "ESTADOS UNIDOS",
      flag: "🇺🇸",
      servicesCount: 3,
      available: true,
      color: "#0A4B9E" // Usando cor institucional
    },
    {
      id: "mexico",
      name: "MÉXICO",
      flag: "🇲🇽",
      servicesCount: 0,
      available: false,
      color: "#2BA84A" // Usando cor institucional verde
    }
  ];

  const handleNext = () => {
    if (!selectedCountry) {
      toast.error("Por favor, selecione um país antes de continuar");
      return;
    }
    onNext(selectedCountry);
  };

  // Extrair iniciais do email para avatar
  const getInitials = (email: string) => {
    return email.substring(0, 2).toUpperCase();
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: "var(--color-background-light)" }}>
      {/* Header */}
      <Header 
        isLoggedIn={true}
        userEmail={userEmail}
        onLogout={onLogout}
        onNavigateToHome={onCancel}
      />

      {/* Breadcrumb Progress */}
      <div className="bg-white border-b" style={{ borderColor: "var(--color-border)" }}>
        <div className="mx-auto px-4" 
          style={{ 
            maxWidth: "1024px",
            paddingTop: "var(--space-md)",
            paddingBottom: "var(--space-md)"
          }}>
          <div className="flex items-center justify-between">
            {/* Step 1 - Active */}
            <div className="flex items-center gap-3 flex-1" key="step-1">
              <div className="rounded-full flex items-center justify-center text-white" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "var(--color-brand-blue)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                1
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "var(--color-brand-blue)",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  País
                </div>
                <div style={{ fontSize: "12px", color: "var(--color-text-muted)", fontFamily: "Inter, sans-serif" }}>
                  Selecione o destino
                </div>
              </div>
            </div>

            {/* Connector */}
            <div className="flex-1 mx-4" style={{ height: "2px", backgroundColor: "#E5E7EB" }} key="connector-1"></div>

            {/* Step 2 - Inactive */}
            <div className="flex items-center gap-3 flex-1" key="step-2">
              <div className="rounded-full flex items-center justify-center" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "#E5E7EB",
                  color: "#9CA3AF",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                2
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "#9CA3AF",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  Serviços
                </div>
                <div style={{ fontSize: "12px", color: "#9CA3AF", fontFamily: "Inter, sans-serif" }}>
                  Escolha os serviços
                </div>
              </div>
            </div>

            {/* Connector */}
            <div className="flex-1 mx-4" style={{ height: "2px", backgroundColor: "#E5E7EB" }} key="connector-2"></div>

            {/* Step 3 - Inactive */}
            <div className="flex items-center gap-3 flex-1" key="step-3">
              <div className="rounded-full flex items-center justify-center" 
                style={{ 
                  width: "40px", 
                  height: "40px",
                  backgroundColor: "#E5E7EB",
                  color: "#9CA3AF",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 700
                }}>
                3
              </div>
              <div>
                <div style={{ 
                  fontSize: "14px", 
                  color: "#9CA3AF",
                  fontFamily: "Poppins, sans-serif",
                  fontWeight: 600
                }}>
                  Pagamento
                </div>
                <div style={{ fontSize: "12px", color: "#9CA3AF", fontFamily: "Inter, sans-serif" }}>
                  Finalize a compra
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="mx-auto px-4" 
        style={{ 
          maxWidth: "var(--container-desktop)",
          paddingTop: "var(--space-lg)",
          paddingBottom: "var(--space-lg)",
          paddingLeft: "var(--grid-margin-mobile)",
          paddingRight: "var(--grid-margin-mobile)"
        }}>
        {/* Title Section */}
        <div className="text-center" style={{ marginBottom: "var(--space-lg)" }}>
          <h1 style={{ 
            fontFamily: "Poppins, sans-serif", 
            fontWeight: 700,
            fontSize: "clamp(32px, 4vw, 40px)",
            color: "var(--color-text-primary)",
            marginBottom: "var(--space-sm)"
          }}>
            Selecione o país de destino
          </h1>
          <p style={{ 
            fontSize: "18px", 
            color: "var(--color-text-secondary)",
            fontFamily: "Inter, sans-serif"
          }}>
            Escolha o país para o qual você precisa do visto
          </p>
        </div>

        {/* Country Cards Grid - Responsivo nos breakpoints corretos */}
        <div 
          className="grid gap-6"
          style={{ 
            gridTemplateColumns: "repeat(1, 1fr)",
            gap: "var(--space-md)",
            marginBottom: "var(--space-lg)"
          }}>
          <style>{`
            @media (min-width: 768px) {
              .country-grid {
                grid-template-columns: repeat(3, 1fr) !important;
              }
            }
          `}</style>
          <div className="country-grid grid gap-6">
            {countries.map((country) => (
              <button
                key={country.id}
                onClick={() => country.available && setSelectedCountry(country.id)}
                disabled={!country.available}
                className={`
                  relative bg-white rounded-xl p-6 border-2 transition-all duration-150
                  ${!country.available 
                    ? "opacity-50 cursor-not-allowed" 
                    : selectedCountry === country.id
                      ? "shadow-lg"
                      : "hover:shadow-lg cursor-pointer"
                  }
                `}
                style={{ 
                  minHeight: "320px",
                  borderRadius: "var(--radius-md)",
                  borderColor: selectedCountry === country.id ? "var(--color-brand-blue)" : "#E5E7EB",
                  borderWidth: selectedCountry === country.id ? "3px" : "1px",
                  backgroundColor: selectedCountry === country.id ? "rgba(10, 75, 158, 0.05)" : "white",
                  boxShadow: selectedCountry === country.id ? "var(--shadow-hover)" : "var(--shadow-card)",
                  padding: "var(--space-md)"
                }}
              >
                {/* Check Mark */}
                {selectedCountry === country.id && (
                  <div className="absolute rounded-full flex items-center justify-center" 
                    style={{ 
                      top: "16px", 
                      right: "16px",
                      width: "32px",
                      height: "32px",
                      backgroundColor: "var(--color-brand-blue)"
                    }}>
                    <Check size={18} className="text-white" />
                  </div>
                )}

                {/* Coming Soon Badge */}
                {!country.available && (
                  <div className="absolute px-3 py-1 rounded-full" 
                    style={{ 
                      top: "16px", 
                      right: "16px",
                      backgroundColor: "#6B7280",
                      color: "white",
                      fontSize: "12px",
                      fontFamily: "Poppins, sans-serif",
                      fontWeight: 600
                    }}>
                    EM BREVE
                  </div>
                )}

                {/* Country Content */}
                <div className="flex flex-col items-center justify-center h-full" style={{ gap: "var(--space-md)" }}>
                  {/* Flag Icon */}
                  <div style={{ fontSize: "72px", marginBottom: "8px" }}>
                    {country.flag}
                  </div>

                  {/* Country Name */}
                  <h3 style={{ 
                    fontFamily: "Poppins, sans-serif",
                    fontWeight: 700,
                    fontSize: "24px",
                    color: "var(--color-text-primary)"
                  }}>
                    {country.name}
                  </h3>

                  {/* Visual Icon */}
                  <div className="rounded-full flex items-center justify-center" 
                    style={{ 
                      width: "64px", 
                      height: "64px",
                      backgroundColor: `${country.color}20`
                    }}>
                    <div className="rounded-full" 
                      style={{ 
                        width: "48px", 
                        height: "48px",
                        backgroundColor: country.color
                      }}></div>
                  </div>

                  {/* Services Count */}
                  <div style={{ 
                    fontSize: "14px", 
                    color: country.available ? "var(--color-text-secondary)" : "#9CA3AF",
                    fontFamily: "Inter, sans-serif"
                  }}>
                    {country.available 
                      ? `${country.servicesCount} ${country.servicesCount === 1 ? "serviço disponível" : "serviços disponíveis"}`
                      : "Serviços em breve"
                    }
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-8 border-t" style={{ borderColor: "var(--color-border)" }}>
          <button
            onClick={onCancel}
            className="flex items-center gap-2 px-6 py-3 border-2 rounded-lg hover:bg-gray-50 transition-colors"
            style={{ 
              borderColor: "#D1D5DB",
              color: "var(--color-text-secondary)",
              borderRadius: "var(--radius-sm)",
              fontFamily: "Poppins, sans-serif",
              fontWeight: 600
            }}
          >
            <X size={20} />
            Cancelar
          </button>

          <button
            onClick={handleNext}
            disabled={!selectedCountry}
            className="flex items-center gap-2 px-8 py-3 rounded-lg transition-all"
            style={{ 
              backgroundColor: selectedCountry ? "var(--color-brand-blue)" : "#D1D5DB",
              color: selectedCountry ? "white" : "#6B7280",
              cursor: selectedCountry ? "pointer" : "not-allowed",
              borderRadius: "var(--radius-sm)",
              fontFamily: "Poppins, sans-serif",
              fontWeight: 600,
              boxShadow: selectedCountry ? "var(--shadow-button)" : "none"
            }}
          >
            Próximo
            <ArrowRight size={20} />
          </button>
        </div>

        {/* Helper Text */}
        {!selectedCountry && (
          <div className="text-center mt-6" 
            style={{ 
              fontSize: "14px", 
              color: "var(--color-text-muted)",
              fontFamily: "Inter, sans-serif"
            }}>
            💡 Selecione um país para continuar com a contratação
          </div>
        )}
      </main>
    </div>
  );
}