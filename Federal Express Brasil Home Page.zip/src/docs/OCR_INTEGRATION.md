# 📋 Guia de Integração OCR - Federal Express Brasil

## 🎯 Visão Geral

Sistema completo de revisão OCR com **100% dos campos** necessários para processamento de documentos em processos de visto e imigração.

## 📦 Componentes Criados

### 1. Componentes Principais

#### `OcrReviewCard` (Base Universal)
- **Localização:** `/components/ocr/OcrReviewCard.tsx`
- **Uso:** Componente base que renderiza qualquer tipo de documento
- **Props:**
  - `config`: Configuração do documento (via `lib/ocr/fields.ts`)
  - `imageUrl`: Preview do documento capturado
  - `initialData`: Dados OCR pré-preenchidos
  - `onSave`: Callback ao salvar dados
  - `onReprocess`: Callback para reprocessar OCR
  - `isProcessing`: Estado de processamento

#### `CameraCapture` (Modal Profissional)
- **Localização:** `/components/ocr/CameraCapture.tsx`
- **Recursos:**
  - Preview ao vivo em 720p (16:9)
  - Seleção de múltiplas câmeras
  - Captura, recaptura, trocar câmera
  - Fallback para upload de arquivo
  - Tratamento de erros de permissão
  - Transformação de espelhamento para câmera frontal

### 2. Componentes Específicos (Prontos para Uso)

Todos localizados em `/components/ocr/`:

- ✅ `OcrReviewCard_Passport.tsx` - Passaporte
- ✅ `OcrReviewCard_BRID.tsx` - Documentos BR (RG, CNH, CIN)
- ✅ `OcrReviewCard_Visa.tsx` - Visto
- ✅ `OcrReviewCard_MarriageCert.tsx` - Certidão de Casamento
- ✅ `OcrReviewCard_CivilUnion.tsx` - União Estável
- ✅ `OcrReviewCard_BirthCert.tsx` - Certidão de Nascimento

### 3. Configuração de Campos OCR

**Arquivo:** `/lib/ocr/fields.ts`

Contém **TODAS** as definições de campos para cada tipo de documento:

```typescript
import { getOcrConfig } from './lib/ocr/fields';

// Obter configuração de um documento
const passportConfig = getOcrConfig('passport');
const visaConfig = getOcrConfig('visa');
const rgConfig = getOcrConfig('rg');
```

#### Tipos de Documento Suportados:

- `passport` - Passaporte (13 campos principais + 6 filiação + 5 MRZ)
- `cnh` - CNH (12 campos principais + 2 filiação)
- `rg` - RG (8 campos principais + 5 filiação)
- `cin` - CIN (10 campos principais + 6 filiação)
- `visa` - Visto (12 campos principais + 2 MRZ)
- `marriage` - Certidão de Casamento (6 dados principais + 7 registro)
- `civilUnion` - União Estável (8 dados parceiros + 9 registro)
- `birth` - Certidão de Nascimento (8 principais + 6 pais + 4 avós + 8 registro)

## 🚀 Como Usar

### Exemplo 1: Componente Individual

```tsx
import { OcrReviewCard_Passport } from './components/ocr';

function MyPage() {
  const handleSave = (data: Record<string, string>) => {
    console.log('Dados salvos:', data);
    // Salvar no Supabase
  };

  return (
    <OcrReviewCard_Passport
      imageUrl="/path/to/document.jpg"
      initialData={{
        fullName: "JOÃO SILVA",
        passportNumber: "BR123456"
      }}
      onSave={handleSave}
    />
  );
}
```

### Exemplo 2: Com Modal de Câmera

```tsx
import { useState } from 'react';
import { CameraCapture, OcrReviewCard_Passport } from './components/ocr';

function DocumentCapturePage() {
  const [showCamera, setShowCamera] = useState(false);
  const [documentImage, setDocumentImage] = useState<string | null>(null);

  const handleCapture = (file: File) => {
    const imageUrl = URL.createObjectURL(file);
    setDocumentImage(imageUrl);
    setShowCamera(false);
    
    // Enviar para OCR backend aqui
  };

  return (
    <>
      <button onClick={() => setShowCamera(true)}>
        Capturar Documento
      </button>

      {documentImage && (
        <OcrReviewCard_Passport
          imageUrl={documentImage}
          initialData={{}}
          onSave={(data) => console.log(data)}
        />
      )}

      <CameraCapture
        isOpen={showCamera}
        onClose={() => setShowCamera(false)}
        onCapture={handleCapture}
        title="Capturar Passaporte"
      />
    </>
  );
}
```

### Exemplo 3: Página Completa (Demo)

```tsx
import OcrDemo from './pages/OcrDemo';

// Página de demonstração completa com todos os componentes integrados
```

## 🔗 Integração com Backend

### 1. Estrutura de Dados no Supabase

Crie uma tabela `ocr_documents` com os seguintes campos:

```sql
CREATE TABLE ocr_documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id),
  document_type TEXT NOT NULL, -- 'passport', 'visa', 'rg', etc.
  image_url TEXT, -- URL da imagem no Storage
  ocr_data JSONB NOT NULL, -- Dados extraídos pelo OCR
  is_reviewed BOOLEAN DEFAULT false,
  is_approved BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### 2. Fluxo de Integração OCR

```typescript
// 1. Upload da imagem
const handleCapture = async (file: File) => {
  // Upload para Supabase Storage
  const { data: uploadData, error } = await supabase.storage
    .from('documents')
    .upload(`${userId}/${file.name}`, file);

  if (error) throw error;

  // 2. Chamar API de OCR (backend)
  const response = await fetch('/api/ocr/process', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    },
    body: JSON.stringify({
      imageUrl: uploadData.path,
      documentType: 'passport'
    })
  });

  const ocrData = await response.json();

  // 3. Salvar dados preliminares no banco
  await supabase.from('ocr_documents').insert({
    user_id: userId,
    document_type: 'passport',
    image_url: uploadData.path,
    ocr_data: ocrData,
    is_reviewed: false
  });
};

// 4. Salvar revisão do usuário
const handleSave = async (reviewedData: Record<string, string>) => {
  await supabase.from('ocr_documents')
    .update({
      ocr_data: reviewedData,
      is_reviewed: true,
      updated_at: new Date().toISOString()
    })
    .eq('id', documentId);
};
```

### 3. Backend - Endpoint de OCR

```typescript
// /supabase/functions/server/index.tsx

app.post('/make-server-d805caa8/ocr/process', async (c) => {
  const { imageUrl, documentType } = await c.req.json();
  
  // Integração com serviço de OCR (ex: Google Vision, AWS Textract, etc.)
  const ocrResult = await processOCR(imageUrl, documentType);
  
  return c.json({
    success: true,
    data: ocrResult
  });
});
```

## 🎨 Customização Visual

Todos os componentes seguem o **Design System** do Federal Express:

- **Cores:**
  - Primária: `#0A4B9E`, `#0058CC`
  - Sucesso: `#2BA84A`
  - Atenção: `#D97706`, `#FCD34D`
  
- **Fontes:**
  - Títulos: `Poppins, sans-serif`
  - Corpo: `Inter, sans-serif`

- **Responsividade:**
  - Mobile: 360px
  - Tablet: 768px
  - Desktop: 1024px, 1440px

## 📱 Recursos Implementados

### ✅ Campos OCR Completos

- [x] Passaporte (24 campos)
- [x] CNH (14 campos)
- [x] RG (13 campos)
- [x] CIN (16 campos)
- [x] Visto (14 campos)
- [x] Certidão Casamento (13 campos)
- [x] União Estável (17 campos)
- [x] Certidão Nascimento (26 campos)

### ✅ Funcionalidades UX

- [x] Seções colapsáveis
- [x] Campos obrigatórios destacados
- [x] Validação em tempo real
- [x] Estados: Idle | Editing | Confirmed
- [x] Preview de imagem
- [x] Botão "Reprocessar OCR"
- [x] Botão "Editar manualmente"
- [x] Feedback visual (border amarela em campos vazios)
- [x] Animação de salvamento

### ✅ Modal de Câmera

- [x] Preview ao vivo 720p
- [x] Seleção de múltiplas câmeras
- [x] Trocar entre frontal/traseira
- [x] Capturar / Recapturar
- [x] Upload alternativo
- [x] Tratamento de erros de permissão
- [x] Espelhamento automático (câmera frontal)

## 🧪 Testes Recomendados

1. **Teste de Captura:**
   - Testar em diferentes dispositivos (mobile/desktop)
   - Verificar permissões de câmera
   - Testar fallback para upload

2. **Teste de Validação:**
   - Campos obrigatórios vazios
   - Formato de data
   - CPF/Passaporte

3. **Teste de Performance:**
   - Upload de imagens grandes
   - Processamento OCR assíncrono
   - Navegação entre seções

## 📊 Próximos Passos

1. **Integrar com API de OCR real** (Google Vision, Textract, etc.)
2. **Implementar validações específicas** (CPF, data, etc.)
3. **Adicionar suporte a PDF**
4. **Criar histórico de revisões**
5. **Implementar assinatura digital**
6. **Adicionar exportação para PDF preenchido**

## 🆘 Suporte

Para questões técnicas ou dúvidas sobre integração:
- Consulte os componentes em `/components/ocr/`
- Veja a página de demonstração em `/pages/OcrDemo.tsx`
- Revise as configurações em `/lib/ocr/fields.ts`

---

**Desenvolvido para Federal Express Brasil** | Sistema de Visto e Imigração
