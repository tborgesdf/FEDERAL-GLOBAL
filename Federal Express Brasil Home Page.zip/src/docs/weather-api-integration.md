# 🌦️ Weather Panel - Integração de APIs

## 📦 Componente
**Localização:** `/components/WeatherPanel.tsx`

## 🔑 Configuração de API Key

### OpenWeatherMap (Principal)
1. Obtenha sua API Key em: https://openweathermap.org/api
2. Crie um arquivo `.env` na raiz do projeto:
   ```env
   VITE_WEATHER_API_KEY=sua_api_key_aqui
   ```

### Open-Meteo (Fallback - Não requer chave)
- Endpoint: https://api.open-meteo.com/v1/forecast
- Funciona automaticamente quando OpenWeatherMap não está disponível

## 🎯 Funcionalidades Implementadas

✅ **Dual API Integration:**
- OpenWeatherMap como API principal (mais dados e precisão)
- Open-Meteo como fallback automático (não requer chave)

✅ **Geolocalização:**
- Detecta localização do usuário automaticamente
- Fallback para São Paulo (-22.9068, -43.1729) caso negado

✅ **Atualização Automática:**
- Atualiza a cada 5 minutos
- Timestamp de última atualização visível

✅ **Dados Exibidos:**
- Temperatura atual
- Condição do clima (traduzida para PT-BR)
- Cidade
- Umidade (quando disponível)
- Velocidade do vento
- Visibilidade (quando disponível)

✅ **Design Responsivo:**
- Mobile-first (min: 320px, max: 600px)
- Fundo translúcido com backdrop-blur
- Sombras suaves e animações
- Ícones dinâmicos baseados na condição

## 📡 Exemplos de Resposta das APIs

### OpenWeatherMap Response:
```json
{
  "coord": {
    "lon": -43.1729,
    "lat": -22.9068
  },
  "weather": [
    {
      "id": 800,
      "main": "Clear",
      "description": "céu limpo",
      "icon": "01d"
    }
  ],
  "main": {
    "temp": 24.5,
    "feels_like": 24.8,
    "temp_min": 23.2,
    "temp_max": 26.1,
    "pressure": 1013,
    "humidity": 65
  },
  "visibility": 10000,
  "wind": {
    "speed": 3.5,
    "deg": 180
  },
  "name": "São Paulo"
}
```

### Open-Meteo Response:
```json
{
  "latitude": -22.9,
  "longitude": -43.2,
  "timezone": "America/Sao_Paulo",
  "current_weather": {
    "temperature": 24.5,
    "windspeed": 12.6,
    "winddirection": 180,
    "weathercode": 0,
    "time": "2025-11-11T14:00"
  }
}
```

## 🎨 Ícones e Estados

### Mapeamento de Condições:
| Condição | Ícone | Cor |
|----------|-------|-----|
| Céu limpo / Sol | ☀️ Sun | #F59E0B |
| Nuvens | ☁️ Cloud | #6B7280 |
| Chuva / Garoa | 🌧️ CloudRain | #2563EB |
| Neve | ❄️ CloudSnow | #60A5FA |
| Vento | 💨 Wind | #6B7280 |

### Weather Codes (Open-Meteo):
- `0`: Céu limpo
- `1-3`: Parcialmente nublado / Nublado
- `51-67`: Garoa / Chuva
- `71-77`: Neve
- `80-82`: Pancadas de chuva

## 🚀 Uso no Dashboard

```tsx
import WeatherPanel from "./WeatherPanel";

// No componente Dashboard:
<WeatherPanel />
```

## 🧪 Testando sem API Key

O componente funciona perfeitamente **sem API key** usando Open-Meteo:
- Apenas defina `VITE_WEATHER_API_KEY` como vazio ou não configure
- O sistema detectará automaticamente e usará Open-Meteo

## 🔄 Fluxo de Fallback

```
1. Verificar se VITE_WEATHER_API_KEY existe
   ├─ SIM → Tentar OpenWeatherMap
   │   ├─ Sucesso → Exibir dados ✅
   │   └─ Falha → Tentar Open-Meteo
   │       ├─ Sucesso → Exibir dados ✅
   │       └─ Falha → Exibir erro ❌
   └─ NÃO → Usar Open-Meteo diretamente
       ├─ Sucesso → Exibir dados ✅
       └─ Falha → Exibir erro ❌
```

## 📱 Responsividade

### Breakpoints:
- **Mobile:** 320px - 767px (1 coluna)
- **Tablet:** 768px - 1023px (centralizado)
- **Desktop:** 1024px+ (centralizado, max-width: 600px)

## 🎨 Estilos Aplicados

```css
/* Container principal */
bg-white/80              /* Fundo branco 80% opacidade */
backdrop-blur-sm         /* Blur no fundo */
rounded-2xl              /* Bordas arredondadas 2xl */
shadow-md                /* Sombra média */
hover:shadow-lg          /* Sombra grande no hover */

/* Tipografia */
font-family: Poppins     /* Fonte padrão */
font-weight: 600         /* Semibold para títulos */
color: #2563EB           /* Azul para temperatura */
```

## 🔧 Customização

### Alterar localização padrão:
```tsx
// Em WeatherPanel.tsx, linha ~158
let lat = -22.9068;  // Latitude de São Paulo
let lon = -43.1729;  // Longitude de São Paulo
```

### Alterar intervalo de atualização:
```tsx
// Em WeatherPanel.tsx, linha ~191
const interval = setInterval(fetchWeather, 5 * 60 * 1000); // 5 minutos
```

## 📊 Performance

- **Carregamento inicial:** ~500ms
- **Tamanho do componente:** ~15KB
- **Requisições de API:** Máximo 12/hora (5 min cada)
- **Cache:** Não implementado (futuro enhancement)

## 🛡️ Segurança

✅ API Key armazenada em variáveis de ambiente
✅ Não exposta no código cliente
✅ HTTPS obrigatório para ambas as APIs
✅ Rate limiting respeitado (12 requisições/hora)

## 🔮 Melhorias Futuras

- [ ] Cache de dados (5 minutos)
- [ ] Previsão de 7 dias
- [ ] Gráfico de temperatura
- [ ] Alertas meteorológicos
- [ ] Escolha manual de cidade
- [ ] Modo escuro
- [ ] Animações de transição entre estados

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique se `.env` está configurado corretamente
2. Confira o console do navegador para logs
3. Teste sem API key (modo Open-Meteo)

---

**Última atualização:** 11 de novembro de 2025
**Versão:** 1.0.0
