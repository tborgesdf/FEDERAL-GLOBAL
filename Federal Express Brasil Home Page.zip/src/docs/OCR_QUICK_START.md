# 🚀 Quick Start - Sistema OCR

## 🎯 Como Testar AGORA

### Opção 1: Console do Navegador (Mais Rápido)

1. Abra o projeto no navegador
2. Pressione `F12` para abrir o DevTools
3. Vá para a aba **Console**
4. Digite e execute:

```javascript
window.location.hash = '#ocr-demo'
window.location.reload()
```

---

### Opção 2: Modificar App.tsx (Temporário)

Edite o arquivo `/App.tsx` na linha 18:

```typescript
// ENCONTRE ESTA LINHA:
const [currentPage, setCurrentPage] = useState<...>("home");

// ALTERE PARA:
const [currentPage, setCurrentPage] = useState<...>("ocr-demo");
```

Salve e recarregue a página.

---

### Opção 3: Adicionar Botão de Acesso (Permanente)

No arquivo `/App.tsx`, adicione após a linha 45:

```typescript
// APÓS handleTestDashboard, ADICIONE:
const handleTestOCR = () => {
  setCurrentPage("ocr-demo");
};
```

E no JSX do header, adicione um botão:

```tsx
<button onClick={handleTestOCR}>
  🔍 Testar OCR
</button>
```

---

## 🧪 Fluxo de Teste Completo

### 1. Teste de Captura de Câmera

1. Clique em **"Capturar Documento"**
2. Permita acesso à câmera quando solicitado
3. Se houver múltiplas câmeras, selecione uma no dropdown
4. Posicione um documento no enquadramento
5. Clique em **"Capturar"**
6. Revise a imagem capturada
7. Clique em **"Confirmar e enviar"** OU **"Recapturar"**

**Se a câmera não funcionar:**
- Clique em **"Enviar arquivo"** para fazer upload de uma imagem

---

### 2. Teste de Revisão OCR

Após capturar ou fazer upload:

1. Veja o card de revisão aparecer
2. Observe os dados pré-preenchidos (exemplo)
3. Note os campos vazios destacados em **amarelo**
4. Clique em **"Editar manualmente"**
5. Preencha alguns campos
6. Expanda/recolha seções clicando nos títulos
7. Clique em **"Confirmar e salvar"**
8. Veja a animação verde de "Salvo!"

---

### 3. Teste de Múltiplos Documentos

Use as **tabs** no topo para alternar entre:

- 📕 Passaporte
- 🪪 Doc. BR (RG/CNH/CIN)
- ✈️ Visto
- 💍 Casamento
- 👶 Nascimento

Cada um mostra campos diferentes!

---

### 4. Teste de Validação

1. Deixe campos obrigatórios vazios
2. Tente salvar
3. Veja o **banner amarelo de erro** aparecer
4. Preencha os campos obrigatórios (*)
5. Agora o botão "Salvar" deve funcionar

---

### 5. Teste de Progresso

No **checklist lateral**, observe:
- ⚪ Passo não iniciado (número cinza)
- 🔵 Passo atual (número azul)
- ✅ Passo completo (check verde)

---

## 📋 Campos para Testar

### Passaporte (24 campos)

**Dados Principais:**
- Nome completo
- Número do passaporte
- CPF
- Nacionalidade
- Sexo (dropdown)
- Data de nascimento
- Data de emissão
- Data de validade
- País emissor
- Autoridade emissora

**Filiação:**
- Nome da mãe
- Nome do pai
- Cidade de nascimento
- UF de nascimento
- País de nascimento

**MRZ:**
- Linha 1 MRZ (textarea)
- Linha 2 MRZ (textarea)
- Tipo de documento
- Código de verificação

---

### Visto (14 campos)

- Número do visto
- Tipo/Classe
- Quantidade de entradas (dropdown)
- Posto emissor
- País emissor
- MRZ lines

---

### Certidão de Nascimento (26 campos!)

**Principais:**
- Nome completo
- CPF
- Data de nascimento
- Hora de nascimento
- Sexo
- Local de nascimento

**Pais:**
- Nome da mãe
- CPF da mãe
- Nome do pai
- CPF do pai

**Avós:**
- Avó materna
- Avô materno
- Avó paterna
- Avô paterno

**Registro:**
- Cartório
- Livro
- Folha
- Termo
- Data do registro

---

## 🎨 Recursos Visuais para Verificar

### ✅ Elementos Implementados

- [ ] **Header sticky** com título "Sistema de Revisão OCR"
- [ ] **Sidebar de progresso** com checklist
- [ ] **Card de upload** com área tracejada
- [ ] **Thumbnail do documento** capturado
- [ ] **Botões de ação:** Reprocessar | Editar | Salvar
- [ ] **Seções colapsáveis** com ícones (📋, 👨‍👩‍👧, 🔖)
- [ ] **Campos obrigatórios** marcados com *
- [ ] **Campos vazios** com borda amarela
- [ ] **Banner de alerta** quando campos obrigatórios estão vazios
- [ ] **Animação verde** ao salvar
- [ ] **Tabs** para alternar documentos
- [ ] **Grid responsivo** (1 coluna mobile / 2 desktop)

---

## 🐛 Problemas Comuns e Soluções

### Câmera não abre
✅ **Solução:** Use HTTPS ou localhost. Câmera não funciona em HTTP.

### Permissão negada
✅ **Solução:** Vá em Configurações do navegador → Privacidade → Permissões → Câmera → Permitir

### Nenhuma câmera encontrada
✅ **Solução:** Use o botão "Enviar arquivo" como fallback

### Campos não aparecem
✅ **Solução:** Verifique se o tipo de documento está selecionado corretamente nas tabs

### Botão "Salvar" desabilitado
✅ **Solução:** Preencha todos os campos obrigatórios (marcados com *)

---

## 📊 Checklist de Teste

### Básico
- [ ] Página carrega sem erros
- [ ] Botão "Capturar Documento" abre modal
- [ ] Modal de câmera funciona
- [ ] Upload de arquivo funciona
- [ ] Imagem aparece no thumbnail
- [ ] Card de revisão OCR aparece

### Interação
- [ ] Seções expandem/recolhem ao clicar
- [ ] Campos ficam editáveis ao clicar "Editar"
- [ ] Dropdown de Select funciona
- [ ] Input de data funciona
- [ ] Textarea tem scroll
- [ ] Botão "Salvar" valida campos obrigatórios

### Visual
- [ ] Layout responsivo funciona
- [ ] Cores do Design System aplicadas
- [ ] Fontes Poppins/Inter carregadas
- [ ] Ícones Lucide aparecem
- [ ] Animações funcionam

### Navegação
- [ ] Tabs trocam de documento
- [ ] Checklist lateral atualiza
- [ ] Progresso é marcado com ✅
- [ ] "Salvar rascunho" está sempre visível

---

## 🎯 Próximo Passo: Integração Real

Depois de testar a interface, siga:
→ `/docs/OCR_INTEGRATION.md`

Para integrar com:
1. Google Vision API (OCR)
2. Supabase Storage (imagens)
3. Supabase Database (dados)
4. Backend Server (processamento)

---

## 💡 Dicas de Desenvolvimento

### Para adicionar novo tipo de documento:

1. Edite `/lib/ocr/fields.ts`
2. Crie configuração com `DocumentOcrConfig`
3. Adicione ao objeto `ocrConfigs`
4. Crie componente específico em `/components/ocr/`
5. Adicione tab em `/pages/OcrDemo.tsx`

### Para customizar campos:

```typescript
{
  key: 'meuCampo',
  label: 'Meu Campo',
  type: 'text',           // ou 'date', 'select', 'textarea'
  required: true,
  placeholder: 'Digite...',
  hint: 'Informação adicional'
}
```

---

**SISTEMA PRONTO PARA TESTE! 🚀**

Qualquer dúvida, consulte:
- `/docs/OCR_INTEGRATION.md` - Documentação completa
- `/docs/OCR_SYSTEM_SUMMARY.md` - Resumo executivo
- `/components/ocr/` - Código-fonte dos componentes
