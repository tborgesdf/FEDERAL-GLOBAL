-- Add flow progress columns to visa_applications
alter table public.visa_applications
  add column if not exists current_step text default 'civil-status',
  add column if not exists draft jsonb default '{}'::jsonb,
  add column if not exists draft_updated_at timestamptz,
  add column if not exists last_completed_step text;

-- Flow checkpoints table (histórico de progresso)
create table if not exists public.flow_checkpoints (
  id uuid primary key default gen_random_uuid(),
  application_id uuid references public.visa_applications(id) on delete cascade,
  step text not null,
  payload jsonb not null,
  created_at timestamptz default now()
);

-- Enable RLS
alter table public.flow_checkpoints enable row level security;

-- Policy: users can only see their own checkpoints
create policy "own_checkpoints" on public.flow_checkpoints
  using (exists(
    select 1 from public.visa_applications v 
    where v.id = application_id 
    and v.user_id = auth.uid()
  ));

-- Policy: users can insert their own checkpoints
create policy "insert_own_checkpoints" on public.flow_checkpoints
  for insert
  with check (exists(
    select 1 from public.visa_applications v 
    where v.id = application_id 
    and v.user_id = auth.uid()
  ));
