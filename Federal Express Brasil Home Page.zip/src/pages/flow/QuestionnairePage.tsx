import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import QuestionnaireStep from "../../components/visa/steps/QuestionnaireStep";
import { useApplication } from "../../lib/flow/useApplication";
import { QuestionnaireSchema, QuestionnaireData } from "../../lib/flow/schemas";

export default function QuestionnairePage() {
  const { application, saveDraft, completeStep, getDraftData } = useApplication();
  const [formData, setFormData] = useState<QuestionnaireData>({
    extractedData: {},
    birthCity: "",
    birthCountry: "Brasil",
    fatherName: "",
    motherName: "",
    occupation: "",
    employer: "",
    travelPurpose: "",
    stayDuration: "",
    usContact: "",
    usAddress: "",
    hasBeenDeported: false,
    hasCriminalRecord: false,
    hasInfectiousDisease: false,
    hasDrugHistory: false,
    hasBeenDeniedVisa: false
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('questionnaire');
    if (draftData) {
      setFormData(draftData);
    } else {
      // Pre-fill from previous steps
      const passportData = getDraftData('passport');
      const brIdData = getDraftData('br-id');

      if (passportData?.ocrData || brIdData?.ocrData) {
        setFormData(prev => ({
          ...prev,
          extractedData: {
            fullName: passportData?.ocrData?.fullName || brIdData?.ocrData?.fullName,
            cpf: brIdData?.ocrData?.cpf,
            birthDate: passportData?.ocrData?.birthDate || brIdData?.ocrData?.birthDate,
            passportNumber: passportData?.ocrData?.number,
            nationality: passportData?.ocrData?.nationality
          }
        }));
      }
    }
  }, []);

  useEffect(() => {
    // Validate whenever form changes
    try {
      QuestionnaireSchema.parse(formData);
      setIsValid(true);
      setErrors({});
    } catch (error: any) {
      setIsValid(false);
      if (error.errors) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err: any) => {
          if (err.path) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  }, [formData]);

  const handleNext = async () => {
    // Validate
    const data = QuestionnaireSchema.parse(formData);

    // This is the last step, so no next step
    await completeStep('questionnaire', null, data);
  };

  const handleSaveDraft = async () => {
    await saveDraft('questionnaire', formData);
  };

  return (
    <FlowLayout
      currentStepId="questionnaire"
      title="Revisão e Formulário DS-160"
      description="Revise os dados extraídos e complete as informações faltantes do formulário DS-160."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
    >
      <QuestionnaireStep
        data={formData}
        onChange={setFormData}
        errors={errors}
      />
    </FlowLayout>
  );
}
