import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { CheckCircle2, Download, FileText } from "lucide-react";
import { Button } from "../../components/ui/button";

export default function CompletedPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#F7F8FA] py-20">
      <div className="mx-auto max-w-[600px] px-6">
        <div className="rounded-xl bg-white p-8 shadow-sm" style={{ border: "1px solid #E5E7EB" }}>
          {/* Success Icon */}
          <div className="mb-6 text-center">
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-[#2BA84A]/10">
              <CheckCircle2 className="h-12 w-12 text-[#2BA84A]" />
            </div>

            <h1
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "32px",
                fontWeight: 700,
                color: "#0A4B9E",
                marginBottom: "12px"
              }}
            >
              Aplicação Concluída!
            </h1>

            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "16px",
                fontWeight: 400,
                color: "#666",
                lineHeight: "1.6"
              }}
            >
              Parabéns! Você completou todas as etapas da sua aplicação de visto.
            </p>
          </div>

          {/* Next Steps */}
          <div className="mb-8 space-y-4">
            <h2
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "20px",
                fontWeight: 600,
                color: "#0A4B9E",
                marginBottom: "12px"
              }}
            >
              Próximos Passos
            </h2>

            <div className="space-y-3">
              <div className="flex items-start gap-3 rounded-lg bg-blue-50 p-4">
                <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-[#0058CC] text-white">
                  <span style={{ fontFamily: "Inter, sans-serif", fontSize: "12px", fontWeight: 600 }}>
                    1
                  </span>
                </div>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 400,
                    color: "#333",
                    lineHeight: "1.5"
                  }}
                >
                  Nossa equipe irá revisar sua aplicação em até 48 horas úteis.
                </p>
              </div>

              <div className="flex items-start gap-3 rounded-lg bg-blue-50 p-4">
                <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-[#0058CC] text-white">
                  <span style={{ fontFamily: "Inter, sans-serif", fontSize: "12px", fontWeight: 600 }}>
                    2
                  </span>
                </div>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 400,
                    color: "#333",
                    lineHeight: "1.5"
                  }}
                >
                  Você receberá um e-mail com o formulário DS-160 preenchido para revisão.
                </p>
              </div>

              <div className="flex items-start gap-3 rounded-lg bg-blue-50 p-4">
                <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-[#0058CC] text-white">
                  <span style={{ fontFamily: "Inter, sans-serif", fontSize: "12px", fontWeight: 600 }}>
                    3
                  </span>
                </div>
                <p
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    fontWeight: 400,
                    color: "#333",
                    lineHeight: "1.5"
                  }}
                >
                  Após sua aprovação, agendaremos sua entrevista no consulado.
                </p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              onClick={() => navigate('/dashboard')}
              className="w-full bg-[#0058CC] hover:bg-[#0A4B9E]"
            >
              <FileText className="mr-2 h-4 w-4" />
              Voltar ao Dashboard
            </Button>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                // TODO: Implement download functionality
                console.log("Download summary");
              }}
            >
              <Download className="mr-2 h-4 w-4" />
              Baixar Resumo da Aplicação
            </Button>
          </div>

          {/* Support */}
          <div className="mt-6 rounded-lg border border-gray-200 bg-gray-50 p-4">
            <p
              style={{
                fontFamily: "Inter, sans-serif",
                fontSize: "13px",
                fontWeight: 500,
                color: "#666",
                textAlign: "center"
              }}
            >
              Dúvidas? Entre em contato com nossa equipe pelo e-mail{" "}
              <a
                href="mailto:suporte@federalexpress.com.br"
                className="text-[#0058CC] hover:underline"
              >
                suporte@federalexpress.com.br
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
