import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import StepMaritalStatus from "../../components/visa/StepMaritalStatus";
import { useApplication } from "../../lib/flow/useApplication";
import { CivilStatusSchema } from "../../lib/flow/schemas";

type CivilStatusValue = "single" | "married" | "stable_union";

export default function CivilStatusPage() {
  const { application, updateCivilStatus, completeStep, getDraftData } = useApplication();
  const [selectedStatus, setSelectedStatus] = useState<CivilStatusValue | null>(null);
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('civil-status');
    if (draftData?.civilStatus) {
      setSelectedStatus(draftData.civilStatus);
      setIsValid(true);
    } else if (application?.civil_status) {
      setSelectedStatus(application.civil_status);
      setIsValid(true);
    }
  }, [application]);

  useEffect(() => {
    // Validate whenever selection changes
    if (selectedStatus) {
      try {
        CivilStatusSchema.parse({ civilStatus: selectedStatus });
        setIsValid(true);
      } catch {
        setIsValid(false);
      }
    } else {
      setIsValid(false);
    }
  }, [selectedStatus]);

  const handleNext = async () => {
    if (!selectedStatus) {
      throw new Error("Selecione seu estado civil");
    }

    // Validate
    const data = CivilStatusSchema.parse({ civilStatus: selectedStatus });

    // Update civil status in application
    await updateCivilStatus(selectedStatus);

    // Complete step
    await completeStep('civil-status', 'socials', data);
  };

  const handleSaveDraft = async () => {
    if (!selectedStatus) return;

    await updateCivilStatus(selectedStatus);
  };

  return (
    <FlowLayout
      currentStepId="civil-status"
      title="Estado Civil"
      description="Informe seu estado civil atual para determinar os documentos necessários."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
    >
      <StepMaritalStatus
        selectedStatus={selectedStatus}
        onStatusChange={setSelectedStatus}
      />
    </FlowLayout>
  );
}
