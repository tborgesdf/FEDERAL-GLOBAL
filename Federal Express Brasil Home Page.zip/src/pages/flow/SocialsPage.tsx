import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import SocialsStep from "../../components/visa/steps/SocialsStep";
import { useApplication } from "../../lib/flow/useApplication";
import { SocialsSchema, SocialsData } from "../../lib/flow/schemas";
import { getNextStep } from "../../lib/flow/steps";

export default function SocialsPage() {
  const { application, context, saveDraft, completeStep, getDraftData } = useApplication();
  const [formData, setFormData] = useState<SocialsData>({
    hasSocials: false,
    handles: []
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('socials');
    if (draftData) {
      setFormData(draftData);
    }
  }, []);

  useEffect(() => {
    // Validate whenever form changes
    try {
      SocialsSchema.parse(formData);
      setIsValid(true);
      setErrors({});
    } catch (error: any) {
      setIsValid(false);
      if (error.errors) {
        const newErrors: Record<string, string> = {};
        error.errors.forEach((err: any) => {
          if (err.path) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  }, [formData]);

  const handleNext = async () => {
    // Validate
    const data = SocialsSchema.parse(formData);

    // Get next step
    if (!context) throw new Error("Context not available");
    const nextStepId = getNextStep('socials', context);

    // Complete step
    await completeStep('socials', nextStepId!, data);
  };

  const handleSaveDraft = async () => {
    await saveDraft('socials', formData);
  };

  return (
    <FlowLayout
      currentStepId="socials"
      title="Redes Sociais"
      description="Informe suas redes sociais. Esta informação é solicitada pelo formulário DS-160."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
    >
      <SocialsStep
        data={formData}
        onChange={setFormData}
        errors={errors}
      />
    </FlowLayout>
  );
}
