import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import BrazilianIDStep from "../../components/visa/steps/BrazilianIDStep";
import { useApplication } from "../../lib/flow/useApplication";
import { BrazilianIDSchema, BrazilianIDData } from "../../lib/flow/schemas";
import { getNextStep } from "../../lib/flow/steps";

export default function BrazilianIDPage() {
  const { context, saveDraft, completeStep, getDraftData } = useApplication();
  const [formData, setFormData] = useState<BrazilianIDData>({
    type: 'rg',
    frontFile: null,
    backFile: null,
    pdfFile: null,
    ocrData: null
  });
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('br-id');
    if (draftData) {
      setFormData(draftData);
    }
  }, []);

  useEffect(() => {
    // Validate whenever form changes
    try {
      BrazilianIDSchema.parse(formData);
      setIsValid(true);
    } catch {
      setIsValid(false);
    }
  }, [formData]);

  const handleNext = async () => {
    // Validate
    const data = BrazilianIDSchema.parse(formData);

    // Get next step
    if (!context) throw new Error("Context not available");
    const nextStepId = getNextStep('br-id', context);

    // Complete step
    await completeStep('br-id', nextStepId!, data);
  };

  const handleSaveDraft = async () => {
    if (formData.frontFile || formData.pdfFile) {
      await saveDraft('br-id', formData);
    }
  };

  return (
    <FlowLayout
      currentStepId="br-id"
      title="Documento Brasileiro"
      description="Envie seu RG, CNH ou CNH Digital. Os dados serão extraídos automaticamente."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
    >
      <BrazilianIDStep
        data={formData}
        onChange={setFormData}
      />
    </FlowLayout>
  );
}
