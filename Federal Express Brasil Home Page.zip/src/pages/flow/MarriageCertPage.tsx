import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import MarriageCertStep from "../../components/visa/steps/MarriageCertStep";
import { useApplication } from "../../lib/flow/useApplication";
import { MarriageCertSchema, MarriageCertData } from "../../lib/flow/schemas";
import { getNextStep } from "../../lib/flow/steps";

export default function MarriageCertPage() {
  const { application, context, saveDraft, completeStep, getDraftData } = useApplication();
  const [formData, setFormData] = useState<MarriageCertData>({
    file: null,
    ocrData: null
  });
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('marriage-cert');
    if (draftData?.file) {
      setFormData(draftData);
    }
  }, []);

  useEffect(() => {
    // Validate whenever form changes
    try {
      MarriageCertSchema.parse(formData);
      setIsValid(true);
    } catch {
      setIsValid(false);
    }
  }, [formData]);

  const handleNext = async () => {
    // Validate
    const data = MarriageCertSchema.parse(formData);

    // Get next step
    if (!context) throw new Error("Context not available");
    const nextStepId = getNextStep('marriage-cert', context);

    // Complete step
    await completeStep('marriage-cert', nextStepId!, data);
  };

  const handleSaveDraft = async () => {
    if (formData.file) {
      await saveDraft('marriage-cert', formData);
    }
  };

  // Determine civil status for display
  const civilStatus = application?.civil_status === 'married' ? 'married' : 'common-law';

  return (
    <FlowLayout
      currentStepId="marriage-cert"
      title={civilStatus === 'married' ? "Certidão de Casamento" : "Certidão de União Estável"}
      description="Envie a certidão atualizada. Os dados serão extraídos automaticamente."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
      showConditionalBadge={true}
    >
      <MarriageCertStep
        data={formData}
        onChange={setFormData}
        civilStatus={civilStatus}
      />
    </FlowLayout>
  );
}
