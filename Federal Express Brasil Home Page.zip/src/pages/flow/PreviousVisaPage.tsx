import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import PreviousVisaStep from "../../components/visa/steps/PreviousVisaStep";
import { useApplication } from "../../lib/flow/useApplication";
import { PreviousVisaSchema, PreviousVisaData } from "../../lib/flow/schemas";
import { getNextStep } from "../../lib/flow/steps";

export default function PreviousVisaPage() {
  const { context, saveDraft, completeStep, getDraftData } = useApplication();
  const [formData, setFormData] = useState<PreviousVisaData>({
    file: null,
    ocrData: null
  });
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('previous-visa');
    if (draftData?.file) {
      setFormData(draftData);
    }
  }, []);

  useEffect(() => {
    // Validate whenever form changes
    try {
      PreviousVisaSchema.parse(formData);
      setIsValid(true);
    } catch {
      setIsValid(false);
    }
  }, [formData]);

  const handleNext = async () => {
    // Validate
    const data = PreviousVisaSchema.parse(formData);

    // Get next step
    if (!context) throw new Error("Context not available");
    const nextStepId = getNextStep('previous-visa', context);

    // Complete step
    await completeStep('previous-visa', nextStepId!, data);
  };

  const handleSaveDraft = async () => {
    if (formData.file) {
      await saveDraft('previous-visa', formData);
    }
  };

  return (
    <FlowLayout
      currentStepId="previous-visa"
      title="Visto Anterior"
      description="Envie uma foto do seu visto americano anterior para renovação."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
      showConditionalBadge={true}
    >
      <PreviousVisaStep
        data={formData}
        onChange={setFormData}
      />
    </FlowLayout>
  );
}
