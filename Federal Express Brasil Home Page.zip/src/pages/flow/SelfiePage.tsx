import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import SelfieStep from "../../components/visa/steps/SelfieStep";
import { useApplication } from "../../lib/flow/useApplication";
import { SelfieSchema, SelfieData } from "../../lib/flow/schemas";
import { getNextStep } from "../../lib/flow/steps";

export default function SelfiePage() {
  const { context, saveDraft, completeStep, getDraftData } = useApplication();
  const [formData, setFormData] = useState<SelfieData>({
    file: null,
    quality: null,
    isApproved: false
  });
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('selfie');
    if (draftData?.file) {
      setFormData(draftData);
    }
  }, []);

  useEffect(() => {
    // Validate whenever form changes
    try {
      SelfieSchema.parse(formData);
      setIsValid(true);
    } catch {
      setIsValid(false);
    }
  }, [formData]);

  const handleNext = async () => {
    // Validate
    const data = SelfieSchema.parse(formData);

    // Get next step
    if (!context) throw new Error("Context not available");
    const nextStepId = getNextStep('selfie', context);

    // Complete step
    await completeStep('selfie', nextStepId!, data);
  };

  const handleSaveDraft = async () => {
    if (formData.file && formData.isApproved) {
      await saveDraft('selfie', formData);
    }
  };

  return (
    <FlowLayout
      currentStepId="selfie"
      title="Selfie"
      description="Tire uma selfie de alta qualidade. A foto será analisada automaticamente."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
    >
      <SelfieStep
        data={formData}
        onChange={setFormData}
      />
    </FlowLayout>
  );
}
