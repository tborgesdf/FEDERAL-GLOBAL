import { useState, useEffect } from "react";
import FlowLayout from "../FlowLayout";
import PassportStep from "../../components/visa/steps/PassportStep";
import { useApplication } from "../../lib/flow/useApplication";
import { PassportSchema, PassportData } from "../../lib/flow/schemas";
import { getNextStep } from "../../lib/flow/steps";

export default function PassportPage() {
  const { context, saveDraft, completeStep, getDraftData } = useApplication();
  const [formData, setFormData] = useState<PassportData>({
    file: null,
    ocrData: null
  });
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    // Load draft data if exists
    const draftData = getDraftData('passport');
    if (draftData?.file) {
      setFormData(draftData);
    }
  }, []);

  useEffect(() => {
    // Validate whenever form changes
    try {
      PassportSchema.parse(formData);
      setIsValid(true);
    } catch {
      setIsValid(false);
    }
  }, [formData]);

  const handleNext = async () => {
    // Validate
    const data = PassportSchema.parse(formData);

    // Get next step
    if (!context) throw new Error("Context not available");
    const nextStepId = getNextStep('passport', context);

    // Complete step
    await completeStep('passport', nextStepId!, data);
  };

  const handleSaveDraft = async () => {
    if (formData.file) {
      await saveDraft('passport', formData);
    }
  };

  return (
    <FlowLayout
      currentStepId="passport"
      title="Passaporte"
      description="Envie uma foto da página de identificação do seu passaporte. Os dados serão extraídos automaticamente."
      onNext={handleNext}
      onSaveDraft={handleSaveDraft}
      isNextDisabled={!isValid}
    >
      <PassportStep
        data={formData}
        onChange={setFormData}
      />
    </FlowLayout>
  );
}
