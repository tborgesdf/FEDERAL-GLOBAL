import { useState } from "react";
import { Camera, FileText, Check } from "lucide-react";
import { Button } from "../components/ui/button";
import CameraCapture from "../components/ocr/CameraCapture";
import OcrReviewCard_Passport from "../components/ocr/OcrReviewCard_Passport";
import OcrReviewCard_BRID from "../components/ocr/OcrReviewCard_BRID";
import OcrReviewCard_Visa from "../components/ocr/OcrReviewCard_Visa";
import OcrReviewCard_MarriageCert from "../components/ocr/OcrReviewCard_MarriageCert";
import OcrReviewCard_CivilUnion from "../components/ocr/OcrReviewCard_CivilUnion";
import OcrReviewCard_BirthCert from "../components/ocr/OcrReviewCard_BirthCert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

type DocumentStep = {
  id: string;
  label: string;
  completed: boolean;
};

export default function OcrDemo() {
  const [showCamera, setShowCamera] = useState(false);
  const [currentDocument, setCurrentDocument] = useState<string>("passport");
  const [documentImage, setDocumentImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [steps, setSteps] = useState<DocumentStep[]>([
    { id: "passport", label: "Passaporte", completed: false },
    { id: "brid", label: "Documento BR", completed: false },
    { id: "visa", label: "Visto", completed: false },
    { id: "marriage", label: "Certidão", completed: false },
    { id: "selfie", label: "Selfie", completed: false }
  ]);

  const handleCapture = async (file: File) => {
    setShowCamera(false);
    const imageUrl = URL.createObjectURL(file);
    setDocumentImage(imageUrl);

    // Simulate OCR processing
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsProcessing(false);
  };

  const handleSave = (data: Record<string, string>) => {
    console.log("Dados salvos:", data);
    
    // Mark step as completed
    setSteps(prev => prev.map(step =>
      step.id === currentDocument ? { ...step, completed: true } : step
    ));

    // Show success message
    alert("✅ Dados confirmados com sucesso!");
  };

  const handleReprocess = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsProcessing(false);
    alert("OCR reprocessado!");
  };

  // Dados de exemplo para demonstração
  const exampleData: Record<string, Record<string, string>> = {
    passport: {
      documentType: "P",
      passportNumber: "BR123456",
      issuingCountry: "BRA",
      fullName: "JOÃO DA SILVA SANTOS",
      surname: "SANTOS",
      givenName: "JOÃO DA SILVA",
      sex: "M",
      nationality: "Brasileira",
      birthDate: "1990-05-15",
      birthPlace: "São Paulo, Brasil",
      issueDate: "2020-01-10",
      expiryDate: "2030-01-10",
      issuingAuthority: "DPF",
      cpf: "123.456.789-00",
      motherName: "MARIA DA SILVA",
      fatherName: "JOSÉ SANTOS",
      mrz1: "P<BRASANTOS<<JOAO<DA<SILVA<<<<<<<<<<<<<<<<",
      mrz2: "BR1234567<BRA9005155M3001103<<<<<<<<<<<<<<06",
      checkDigitMRZ: "6",
      icaoCountryCode: "BRA"
    },
    visa: {
      fullName: "JOÃO DA SILVA SANTOS",
      visaNumber: "BR2024123456",
      visaType: "VITEM IV",
      passportNumber: "BR123456",
      nationality: "Brasileira",
      sex: "M",
      birthDate: "1990-05-15",
      issueDate: "2024-01-15",
      expiryDate: "2025-01-15",
      entries: "Múltiplas",
      issuingCountry: "Brasil"
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - mantendo o existente */}
      <div className="sticky top-0 z-50 border-b border-gray-200 bg-white shadow-sm">
        <div className="mx-auto max-w-7xl px-4 py-4">
          <h1
            style={{
              fontFamily: "Poppins, sans-serif",
              fontSize: "24px",
              fontWeight: 600,
              color: "#0A4B9E"
            }}
          >
            Sistema de Revisão OCR
          </h1>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[280px_1fr]">
          {/* Sidebar - Progress Checklist */}
          <div className="lg:sticky lg:top-24 lg:h-fit">
            <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
              <h3
                className="mb-4"
                style={{
                  fontFamily: "Poppins, sans-serif",
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "#0A4B9E"
                }}
              >
                Progresso do Fluxo
              </h3>

              <div className="space-y-3">
                {steps.map((step, index) => (
                  <button
                    key={step.id}
                    onClick={() => setCurrentDocument(step.id)}
                    className={`flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-all ${
                      currentDocument === step.id
                        ? "border-[#0058CC] bg-blue-50"
                        : "border-gray-200 bg-white hover:border-gray-300"
                    }`}
                  >
                    <div
                      className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full ${
                        step.completed
                          ? "bg-[#2BA84A] text-white"
                          : currentDocument === step.id
                          ? "bg-[#0058CC] text-white"
                          : "border-2 border-gray-300 text-gray-400"
                      }`}
                    >
                      {step.completed ? (
                        <Check className="h-4 w-4" />
                      ) : (
                        <span
                          style={{
                            fontFamily: "Inter, sans-serif",
                            fontSize: "12px",
                            fontWeight: 600
                          }}
                        >
                          {index + 1}
                        </span>
                      )}
                    </div>

                    <span
                      style={{
                        fontFamily: "Inter, sans-serif",
                        fontSize: "14px",
                        fontWeight: currentDocument === step.id ? 600 : 500,
                        color: currentDocument === step.id ? "#0058CC" : "#374151"
                      }}
                    >
                      {step.label}
                    </span>
                  </button>
                ))}
              </div>

              {/* Draft Button */}
              <Button
                type="button"
                variant="outline"
                className="mt-6 w-full"
              >
                💾 Salvar rascunho
              </Button>
            </div>
          </div>

          {/* Main Content */}
          <div className="space-y-6">
            {/* Capture Button */}
            {!documentImage && (
              <div className="rounded-xl border-2 border-dashed border-gray-300 bg-white p-12 text-center">
                <FileText className="mx-auto mb-4 h-16 w-16 text-gray-400" />
                <h3
                  className="mb-2"
                  style={{
                    fontFamily: "Poppins, sans-serif",
                    fontSize: "18px",
                    fontWeight: 600,
                    color: "#374151"
                  }}
                >
                  Nenhum documento carregado
                </h3>
                <p
                  className="mb-6"
                  style={{
                    fontFamily: "Inter, sans-serif",
                    fontSize: "14px",
                    color: "#6B7280"
                  }}
                >
                  Capture ou envie uma imagem do documento para começar
                </p>
                <Button
                  type="button"
                  onClick={() => setShowCamera(true)}
                  className="bg-[#0058CC] hover:bg-[#0A4B9E]"
                  size="lg"
                >
                  <Camera className="mr-2 h-5 w-5" />
                  Capturar Documento
                </Button>
              </div>
            )}

            {/* OCR Review Cards */}
            {documentImage && (
              <>
                <Tabs value={currentDocument} onValueChange={setCurrentDocument}>
                  <TabsList className="mb-6 grid w-full grid-cols-5 lg:grid-cols-5">
                    <TabsTrigger value="passport">Passaporte</TabsTrigger>
                    <TabsTrigger value="brid">Doc. BR</TabsTrigger>
                    <TabsTrigger value="visa">Visto</TabsTrigger>
                    <TabsTrigger value="marriage">Casamento</TabsTrigger>
                    <TabsTrigger value="birth">Nascimento</TabsTrigger>
                  </TabsList>

                  <TabsContent value="passport">
                    <OcrReviewCard_Passport
                      imageUrl={documentImage}
                      initialData={exampleData.passport}
                      onSave={handleSave}
                      onReprocess={handleReprocess}
                      isProcessing={isProcessing}
                    />
                  </TabsContent>

                  <TabsContent value="brid">
                    <OcrReviewCard_BRID
                      imageUrl={documentImage}
                      initialData={{}}
                      onSave={handleSave}
                      onReprocess={handleReprocess}
                      isProcessing={isProcessing}
                    />
                  </TabsContent>

                  <TabsContent value="visa">
                    <OcrReviewCard_Visa
                      imageUrl={documentImage}
                      initialData={exampleData.visa}
                      onSave={handleSave}
                      onReprocess={handleReprocess}
                      isProcessing={isProcessing}
                    />
                  </TabsContent>

                  <TabsContent value="marriage">
                    <OcrReviewCard_MarriageCert
                      imageUrl={documentImage}
                      initialData={{}}
                      onSave={handleSave}
                      onReprocess={handleReprocess}
                      isProcessing={isProcessing}
                    />
                  </TabsContent>

                  <TabsContent value="birth">
                    <OcrReviewCard_BirthCert
                      imageUrl={documentImage}
                      initialData={{}}
                      onSave={handleSave}
                      onReprocess={handleReprocess}
                      isProcessing={isProcessing}
                    />
                  </TabsContent>
                </Tabs>

                {/* Recapture Button */}
                <div className="text-center">
                  <Button
                    type="button"
                    onClick={() => setShowCamera(true)}
                    variant="outline"
                  >
                    <Camera className="mr-2 h-4 w-4" />
                    Capturar Novo Documento
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Camera Modal */}
      <CameraCapture
        isOpen={showCamera}
        onClose={() => setShowCamera(false)}
        onCapture={handleCapture}
        title="Capturar Documento"
        facingMode="environment"
      />
    </div>
  );
}
