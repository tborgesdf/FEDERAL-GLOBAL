import { ReactNode, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Save, Loader2 } from "lucide-react";
import { Button } from "../components/ui/button";
import { toast } from "sonner@2.0.3";
import FlowProgressBar from "../components/visa/FlowProgressBar";
import { useApplication } from "../lib/flow/useApplication";
import { getNextStep, getPreviousStep, getStepSequence, ALL_STEPS, StepId } from "../lib/flow/steps";

interface FlowLayoutProps {
  currentStepId: StepId;
  title: string;
  description: string;
  children: ReactNode;
  onNext: () => Promise<void>;
  onSaveDraft?: () => Promise<void>;
  isNextDisabled?: boolean;
  showConditionalBadge?: boolean;
}

export default function FlowLayout({
  currentStepId,
  title,
  description,
  children,
  onNext,
  onSaveDraft,
  isNextDisabled = false,
  showConditionalBadge = false
}: FlowLayoutProps) {
  const navigate = useNavigate();
  const { application, context, saveDraft } = useApplication();
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!application || !context) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#0058CC]" />
      </div>
    );
  }

  const stepSequence = getStepSequence(context);
  const currentStepIndex = stepSequence.indexOf(currentStepId);
  const previousStepId = getPreviousStep(currentStepId, context);

  // Map step IDs to progress bar format
  const progressSteps = stepSequence.map(stepId => {
    const step = ALL_STEPS.find(s => s.id === stepId);
    return {
      id: stepId,
      label: step?.label || stepId,
      shortLabel: step?.shortLabel
    };
  });

  const handleBack = () => {
    if (previousStepId) {
      navigate(`/flow/${previousStepId}`);
    } else {
      navigate('/dashboard');
    }
  };

  const handleSaveDraft = async () => {
    if (!onSaveDraft) return;

    setIsSavingDraft(true);
    try {
      await onSaveDraft();
      toast.success("Rascunho salvo com sucesso");
    } catch (error: any) {
      console.error("Error saving draft:", error);
      toast.error("Falha ao salvar rascunho. Tente novamente.");
    } finally {
      setIsSavingDraft(false);
    }
  };

  const handleNext = async () => {
    setIsSubmitting(true);
    try {
      await onNext();
      toast.success("Etapa concluída com sucesso");
      
      // Navigate to next step
      const nextStepId = getNextStep(currentStepId, context);
      if (nextStepId) {
        navigate(`/flow/${nextStepId}`);
      } else {
        // Flow completed
        navigate('/flow/completed');
      }
    } catch (error: any) {
      console.error("Error completing step:", error);
      toast.error(error.message || "Erro ao avançar. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F8FA]">
      {/* Progress Bar */}
      <FlowProgressBar
        currentStep={currentStepIndex + 1}
        steps={progressSteps}
      />

      {/* Content Area */}
      <div className="mx-auto max-w-[960px] px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          {showConditionalBadge && (
            <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-blue-100 px-3 py-1">
              <span
                style={{
                  fontFamily: "Inter, sans-serif",
                  fontSize: "12px",
                  fontWeight: 600,
                  color: "#0058CC"
                }}
              >
                📌 Etapa condicional
              </span>
            </div>
          )}

          <h1
            style={{
              fontFamily: "Poppins, sans-serif",
              fontSize: "32px",
              fontWeight: 700,
              color: "#0A4B9E",
              marginBottom: "8px"
            }}
          >
            {title}
          </h1>

          <p
            style={{
              fontFamily: "Inter, sans-serif",
              fontSize: "16px",
              fontWeight: 400,
              color: "#666",
              lineHeight: "1.5"
            }}
          >
            {description}
          </p>
        </div>

        {/* Card Container */}
        <div
          className="rounded-xl bg-white shadow-sm"
          style={{
            border: "1px solid #E5E7EB",
            padding: "32px"
          }}
        >
          {/* Content (children) */}
          <div className="mb-8">{children}</div>

          {/* Footer */}
          <div className="flex items-center justify-between border-t border-gray-200 pt-6">
            <Button
              type="button"
              variant="ghost"
              onClick={handleBack}
              disabled={isSubmitting}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>

            <div className="flex gap-3">
              {onSaveDraft && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleSaveDraft}
                  disabled={isSavingDraft || isSubmitting}
                >
                  {isSavingDraft ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Salvar rascunho
                    </>
                  )}
                </Button>
              )}

              <Button
                type="button"
                onClick={handleNext}
                disabled={isNextDisabled || isSubmitting}
                className="bg-[#0058CC] hover:bg-[#0A4B9E]"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  "Próximo"
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
