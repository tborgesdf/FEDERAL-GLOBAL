import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { useApplication } from "../lib/flow/useApplication";

export default function FlowIndex() {
  const navigate = useNavigate();
  const { application, isLoading, error } = useApplication();

  useEffect(() => {
    if (isLoading) return;

    if (error || !application) {
      // No active application, redirect to dashboard
      navigate('/dashboard', { replace: true });
      return;
    }

    // Redirect to current step
    navigate(`/flow/${application.current_step}`, { replace: true });
  }, [application, isLoading, error, navigate]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F7F8FA]">
      <div className="text-center">
        <Loader2 className="mx-auto mb-4 h-12 w-12 animate-spin text-[#0058CC]" />
        <p
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: "16px",
            fontWeight: 500,
            color: "#666"
          }}
        >
          Carregando sua aplicação...
        </p>
      </div>
    </div>
  );
}
